"""Task-preference  ->  parameter-level merge weight  mapping.

``lambda_k`` is the preference weight of *task* k and multiplies the residual of
the model that was fine-tuned for that same task.  Attaching the weights
positionally (task order vs. model order) silently mis-assigns them, so this
module makes the correspondence explicit and refuses to guess.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np


class TaskModelMappingError(ValueError):
    """Raised when the task/model correspondence cannot be established."""


def parse_task_model_map(raw: str) -> Dict[str, int]:
    """Parse ``"xnli=1,gsm8k=2,mbpp=0"`` into ``{"xnli": 1, ...}``."""
    mapping: Dict[str, int] = {}
    if not raw:
        return mapping
    for chunk in str(raw).split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "=" not in chunk:
            raise TaskModelMappingError(f"expected task=model_index, got {chunk!r}")
        task, idx = chunk.split("=", 1)
        try:
            mapping[task.strip()] = int(idx)
        except ValueError as exc:  # pragma: no cover - defensive
            raise TaskModelMappingError(f"model index must be an int in {chunk!r}") from exc
    return mapping


@dataclass
class MergeWeightPlan:
    """Model-level merge weights derived from the task preference vector."""

    model_weights: Dict[str, float]
    task_to_model: Dict[str, int]
    tasks: Tuple[str, ...]
    models: Tuple[str, ...]
    task_weights: Dict[str, float]

    def as_dict(self) -> Dict[str, object]:
        return {
            "model_weights": dict(self.model_weights),
            "task_to_model": dict(self.task_to_model),
            "tasks": list(self.tasks),
            "models": list(self.models),
            "task_weights": dict(self.task_weights),
        }


def build_merge_weight_plan(
    tasks: Sequence[str],
    task_weights: Mapping[str, float],
    models: Sequence[str],
    task_to_model: Optional[Mapping[str, int]] = None,
) -> MergeWeightPlan:
    """Map task preferences onto candidate models.

    Rules
    -----
    1. If ``task_to_model`` is given, it must cover every task and every index
       must be a valid candidate index.
    2. Otherwise the mapping is inferred only when ``len(tasks) == len(models)``,
       by *order*; this is the legacy behaviour and is reported back so the run
       manifest can be audited.
    3. If the counts differ and no explicit mapping is given, we raise instead of
       silently falling back to uniform weights (old behaviour).
    """
    tasks = [str(t) for t in tasks]
    models = [str(m) for m in models]
    if not tasks:
        raise TaskModelMappingError("at least one task is required")
    if not models:
        raise TaskModelMappingError("at least one candidate model is required")

    if task_to_model:
        mapping = {str(k): int(v) for k, v in task_to_model.items()}
        missing = [t for t in tasks if t not in mapping]
        if missing:
            raise TaskModelMappingError(f"task_to_model is missing entries for {missing}")
        for task, idx in mapping.items():
            if not 0 <= idx < len(models):
                raise TaskModelMappingError(
                    f"task {task!r} maps to model index {idx}, but only "
                    f"{len(models)} candidates are configured"
                )
    else:
        if len(tasks) != len(models):
            raise TaskModelMappingError(
                f"{len(tasks)} tasks but {len(models)} candidate models: pass an explicit "
                "task_to_model mapping (--task-to-model xnli=0,gsm8k=1,mbpp=2) instead of "
                "relying on positional alignment."
            )
        mapping = {task: idx for idx, task in enumerate(tasks)}

    weights = np.array([float(task_weights.get(t, 0.0)) for t in tasks], dtype=float)
    if not np.all(np.isfinite(weights)):
        raise TaskModelMappingError(f"non-finite task weights: {task_weights}")
    if np.any(weights < 0):
        raise TaskModelMappingError(f"negative task weights are not allowed: {task_weights}")
    total = float(weights.sum())
    if total <= 0:
        raise TaskModelMappingError(f"task weights must sum to a positive value, got {task_weights}")
    weights = weights / total

    model_weights = {m: 0.0 for m in models}
    for task, w in zip(tasks, weights):
        model_weights[models[mapping[task]]] += float(w)

    return MergeWeightPlan(
        model_weights=model_weights,
        task_to_model=mapping,
        tasks=tuple(tasks),
        models=tuple(models),
        task_weights={t: float(w) for t, w in zip(tasks, weights)},
    )


def model_weight_vector(plan: MergeWeightPlan) -> List[float]:
    """Weights in ``models`` order, ready for a mergekit config."""
    return [float(plan.model_weights[m]) for m in plan.models]


def validate_model_order(models: Sequence[str], base_model: str) -> None:
    """Sanity check on the candidate list (no silent duplicates)."""
    models = [str(m) for m in models]
    if len(set(models)) != len(models):
        raise TaskModelMappingError(f"duplicate candidates in the pool: {models}")
    if str(base_model) in models:
        raise TaskModelMappingError(
            "the base model must not be part of the fine-tuned candidate pool "
            "(residuals are computed against it)"
        )
