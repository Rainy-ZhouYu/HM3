"""Dimension / distribution alignment via statistical matching.

Each junction between two layers gets an affine map that matches the activation
statistics of the destination layer:

* the scaling is produced by an MLP that takes the layer index pair and the
  current timestep, and is optimised together with the actor-critic networks;
* the analytic optimum under Gaussian assumptions is the whitening + colouring
  transform ``A_opt = Sigma_tgt^{1/2} Sigma_src^{-1/2}``,
  ``b = mu_tgt - A_opt mu_src``;
* the training objective is ``L_Deep-CORAL + lambda * L_mu`` applied to
  ``z' = W (z - mu_src) / sqrt(diag(Sigma_src)) + b``.

Implementation notes
--------------------
* A full ``d x d`` map per junction is infeasible for d = 1536 (2.4M parameters
  per site, times every junction), so the default is the diagonal (per-channel)
  version of the same whitening/colouring transform, i.e. ``z' = a * z + b``
  with ``a, b in R^d``.  This matches the first moment exactly and the variance
  (diagonal of the covariance) exactly.
* ``a, b`` are initialised at the analytic solution obtained from calibration
  activations and are then refined by a zero-initialised MLP.
* ``--alignment-rank R`` adds a low-rank term ``U V^T`` on top, which is what
  lets the map also reduce the off-diagonal covariance mismatch.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn


@dataclass
class ActivationStats:
    """Per-(model, layer) activation statistics collected on a calibration set."""

    mean: np.ndarray   # [num_slots, d]
    std: np.ndarray    # [num_slots, d]
    num_layers: int

    @staticmethod
    def zeros(num_slots: int, dim: int, num_layers: int) -> "ActivationStats":
        return ActivationStats(
            mean=np.zeros((num_slots, dim), dtype=np.float32),
            std=np.ones((num_slots, dim), dtype=np.float32),
            num_layers=int(num_layers),
        )

    def slot(self, model_idx: int, layer_idx: int) -> int:
        return int(model_idx) * int(self.num_layers) + int(layer_idx)

    def save(self, path: str) -> None:
        np.savez(
            path,
            mean=self.mean.astype(np.float32),
            std=self.std.astype(np.float32),
            num_layers=np.asarray([self.num_layers], dtype=np.int64),
        )

    @staticmethod
    def load(path: str) -> "ActivationStats":
        data = np.load(path)
        return ActivationStats(
            mean=data["mean"].astype(np.float32),
            std=data["std"].astype(np.float32),
            num_layers=int(data["num_layers"][0]),
        )


class AlignmentMLP(nn.Module):
    """``W_{m,l} = MLP_mu(m, l, t)`` implemented as a diagonal affine map.

    ``forward(src_slot, dst_slot, step)`` returns ``(a, b)`` such that
    ``z_aligned = a * (z - mu_src) / sigma_src + b``.
    """

    def __init__(
        self,
        stats: ActivationStats,
        hidden_dim: int = 128,
        max_layers: Optional[int] = None,
        num_models: Optional[int] = None,
        learnable: bool = True,
        rank: int = 0,
    ) -> None:
        super().__init__()
        self.num_slots, self.dim = stats.mean.shape
        self.num_layers = int(stats.num_layers)
        self.num_models = int(num_models or (self.num_slots // max(1, self.num_layers)))
        self.max_layers = int(max_layers or self.num_layers)
        self.learnable = bool(learnable)
        self.rank = int(rank)

        mean = torch.as_tensor(stats.mean, dtype=torch.float32)
        std = torch.as_tensor(stats.std, dtype=torch.float32).clamp_min(1e-3)
        self.register_buffer("act_mean", mean)
        self.register_buffer("act_std", std)

        d = self.dim
        self.src_emb = nn.Embedding(self.num_slots, 32)
        self.step_emb = nn.Embedding(self.max_layers + 1, 32)
        self.net = nn.Sequential(
            nn.Linear(64, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 2 * d),
        )
        nn.init.normal_(self.src_emb.weight, std=0.02)
        nn.init.normal_(self.step_emb.weight, std=0.02)
        nn.init.zeros_(self.net[-1].weight)
        nn.init.zeros_(self.net[-1].bias)

        if self.rank > 0:
            # Low-rank correction of the off-diagonal structure: the diagonal map
            # can match means and per-channel variances but cannot change the
            # correlation structure, which is exactly what the Deep-CORAL term measures.
            # ``z' = diag(z_norm) + (z_norm V) U^T`` with U, V initialised at zero
            # so the map starts at the analytic (diagonal) solution.
            #
            # NOTE: both factors must NOT be zero: the gradient of a bilinear
            # term U V^T vanishes when both factors are zero, so the correction
            # would never move.  U starts at zero (so the map still equals the
            # analytic solution) while V gets a tiny random value to carry the
            # gradient into U.
            self.U = nn.Parameter(torch.zeros(self.dim, self.rank))
            self.V = nn.Parameter(torch.randn(self.dim, self.rank) * 1e-3)

    # ------------------------------------------------------------------ maths
    def analytic_affine(self, src_slot: torch.Tensor, dst_slot: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Diagonal special case of the whitening/colouring solution."""
        mu_src = self.act_mean[src_slot]
        sd_src = self.act_std[src_slot]
        mu_dst = self.act_mean[dst_slot]
        sd_dst = self.act_std[dst_slot]
        z_src = (0.0 - mu_src) / sd_src
        gain = sd_dst
        intercept = mu_dst - gain * z_src
        return gain, intercept

    def forward(
        self,
        src_slot: torch.Tensor,
        dst_slot: torch.Tensor,
        step: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Return per-sample ``(gain, intercept)`` for ``z' = gain * z / sd_src + intercept``."""
        if int(src_slot.max()) >= self.num_slots or int(dst_slot.max()) >= self.num_slots:
            raise IndexError(
                f"alignment slot out of range: src={int(src_slot.max())}, dst={int(dst_slot.max())}, "
                f"but the statistics table has {self.num_slots} slots "
                f"({self.num_models} models x {self.num_layers} layers). "
                "Fit the alignment maps on the same candidate pool that the search uses "
                "(i.e. including the parameter-level merged model K+1)."
            )
        gain0, intercept0 = self.analytic_affine(src_slot, dst_slot)
        if not self.learnable:
            return gain0, intercept0
        step = step.clamp(min=0, max=self.max_layers)
        feat = torch.cat([self.src_emb(src_slot), self.step_emb(step)], dim=-1)
        delta = self.net(feat)
        delta_gain, delta_bias = delta[:, : self.dim], delta[:, self.dim :]
        return gain0 + delta_gain, intercept0 + delta_bias

    def transform(
        self,
        z: torch.Tensor,
        src_slot: torch.Tensor,
        dst_slot: torch.Tensor,
        step: torch.Tensor,
    ) -> torch.Tensor:
        """Apply ``z' = gain * (z - mu_src) / sigma_src + intercept``.

        The map is evaluated in float32 (the statistics and the MLP live in
        float32) and the result is cast back to the dtype of the hidden states, so
        the alignment layer works inside a bfloat16/float16 model.
        """
        out_dtype = z.dtype
        z32 = z.float()
        gain, intercept = self.forward(src_slot, dst_slot, step)
        gain = gain.float()
        intercept = intercept.float()
        sd_src = self.act_std[src_slot].float()
        mu_src = self.act_mean[src_slot].float()
        if z.dim() == 3:
            # hidden states are [batch, seq, dim] while the statistics are
            # per-sample: broadcast over the sequence axis.
            gain = gain.unsqueeze(1)
            intercept = intercept.unsqueeze(1)
            sd_src = sd_src.unsqueeze(1)
            mu_src = mu_src.unsqueeze(1)
        normalised = (z32 - mu_src) / sd_src
        out = gain * normalised + intercept
        if self.rank > 0:
            out = out + (normalised @ self.V.to(intercept.dtype)) @ self.U.to(intercept.dtype).T
        return out.to(out_dtype)

    def extra_parameters(self) -> Dict[str, int]:
        return {"rank": self.rank, "low_rank_params": 2 * self.dim * self.rank}


class AlignmentWrapper(nn.Module):
    """Wraps a decoder block and aligns its output distribution.

    ``call`` sites are described by ``(src_model, src_layer, dst_model, dst_layer, step)``.
    """

    def __init__(
        self,
        block: nn.Module,
        aligner: AlignmentMLP,
        src_model: int,
        src_layer: int,
        dst_model: int,
        dst_layer: int,
        step: int,
    ) -> None:
        super().__init__()
        self.block = block
        self.aligner = aligner
        self.src_slot = int(src_model) * aligner.num_layers + int(src_layer)
        self.dst_slot = int(dst_model) * aligner.num_layers + int(dst_layer)
        self.step = int(step)

    def __getattr__(self, name: str):
        """Delegate block-specific attributes (e.g. ``attention_type``).

        Transformers >= 4.5x inspects ``decoder_layer.attention_type`` when it
        builds the causal mask, so a wrapper that hides the block would break the
        forward pass.
        """
        try:
            return super().__getattr__(name)
        except AttributeError:
            modules = self.__dict__.get("_modules") or {}
            block = modules.get("block")
            if block is not None:
                return getattr(block, name)
            raise

    def forward(self, hidden_states, *args, **kwargs):
        out = self.block(hidden_states, *args, **kwargs)
        is_tuple = isinstance(out, tuple)
        hidden = out[0] if is_tuple else out
        src_slot = torch.full((hidden.shape[0],), self.src_slot, dtype=torch.long, device=hidden.device)
        dst_slot = torch.full((hidden.shape[0],), self.dst_slot, dtype=torch.long, device=hidden.device)
        step = torch.full((hidden.shape[0],), self.step, dtype=torch.long, device=hidden.device)
        aligned = self.aligner.transform(hidden, src_slot, dst_slot, step)
        if is_tuple:
            return (aligned,) + tuple(out[1:])
        return aligned


def deep_coral_loss(src: torch.Tensor, tgt: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    """Deep-CORAL term: ||C(H'_src) - C(H_tgt)||_F^2 / (4 d^2)."""
    if src.shape[0] < 2 or tgt.shape[0] < 2:
        return torch.zeros((), device=src.device)
    d = src.shape[1]
    src_c = src - src.mean(dim=0, keepdim=True)
    tgt_c = tgt - tgt.mean(dim=0, keepdim=True)
    cov_src = src_c.t() @ src_c / (src.shape[0] - 1)
    cov_tgt = tgt_c.t() @ tgt_c / (tgt.shape[0] - 1)
    return ((cov_src - cov_tgt) ** 2).sum() / (4.0 * d * d + eps)


def mean_alignment_loss(src: torch.Tensor, tgt: torch.Tensor) -> torch.Tensor:
    """Mean-matching term: ||mu_src - mu_tgt||_2^2."""
    if src.shape[0] == 0 or tgt.shape[0] == 0:
        return torch.zeros((), device=src.device)
    return ((src.mean(dim=0) - tgt.mean(dim=0)) ** 2).sum()


@dataclass
class AlignmentFitReport:
    steps: int
    coral: float
    mean: float
    initial_coral: float
    initial_mean: float

    def as_dict(self) -> Dict[str, float]:
        return {
            "steps": self.steps,
            "coral": self.coral,
            "mean_loss": self.mean,
            "initial_coral": self.initial_coral,
            "initial_mean_loss": self.initial_mean,
        }


def fit_alignment(
    aligner: AlignmentMLP,
    src_slot: int,
    dst_slot: int,
    src_acts: torch.Tensor,
    tgt_acts: torch.Tensor,
    steps: int = 200,
    lr: float = 1e-3,
    coral_weight: float = 1.0,
    mean_weight: float = 1.0,
    step_index: int = 0,
    verbose: bool = False,
) -> AlignmentFitReport:
    """Fit one junction's alignment map on calibration activations.

    This optimises ``L_Deep-CORAL + lambda * L_mu`` on stored activations, which is
    cheap and reproducible: no forward pass through the merged model is required.
    """
    device = next(aligner.parameters()).device
    src_acts = src_acts.to(device).float()
    tgt_acts = tgt_acts.to(device).float()
    src_idx = torch.full((src_acts.shape[0],), int(src_slot), dtype=torch.long, device=device)
    dst_idx = torch.full((src_acts.shape[0],), int(dst_slot), dtype=torch.long, device=device)
    step = torch.full((src_acts.shape[0],), int(step_index), dtype=torch.long, device=device)

    def loss_fn() -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        mapped = aligner.transform(src_acts, src_idx, dst_idx, step)
        coral = deep_coral_loss(mapped, tgt_acts)
        mean = mean_alignment_loss(mapped, tgt_acts)
        return coral_weight * coral + mean_weight * mean, coral, mean

    with torch.no_grad():
        _, init_coral, init_mean = loss_fn()

    params = [p for p in aligner.parameters() if p.requires_grad]
    if not params or steps <= 0:
        return AlignmentFitReport(0, float(init_coral), float(init_mean), float(init_coral), float(init_mean))

    opt = torch.optim.Adam(params, lr=lr)
    for _ in range(int(steps)):
        opt.zero_grad(set_to_none=True)
        loss, coral, mean = loss_fn()
        loss.backward()
        opt.step()
        if verbose:
            print(f"[alignment] coral={float(coral):.6f} mean={float(mean):.6f}", flush=True)

    with torch.no_grad():
        _, coral, mean = loss_fn()
    return AlignmentFitReport(int(steps), float(coral), float(mean), float(init_coral), float(init_mean))


@torch.no_grad()
def collect_activation_stats(
    models: Sequence[nn.Module],
    batch: Dict[str, torch.Tensor],
    num_layers: int,
    device: torch.device,
) -> ActivationStats:
    """Per-(model, layer) mean/std of the hidden states on a calibration batch.

    Used to initialise the alignment maps at the analytic optimum.
    """
    if not models:
        raise ValueError("no models provided")
    dim = int(getattr(models[0].config, "hidden_size"))
    table = ActivationStats.zeros(len(models) * num_layers, dim, num_layers)
    for m, model in enumerate(models):
        model = model.to(device)
        model.eval()
        outputs = model(**{k: v.to(device) for k, v in batch.items()}, output_hidden_states=True)
        hidden_states = outputs.hidden_states  # tuple of len num_layers + 1
        for l in range(min(num_layers, len(hidden_states) - 1)):
            h = hidden_states[l].float()
            flat = h.reshape(-1, h.shape[-1])
            table.mean[m * num_layers + l] = flat.mean(dim=0).cpu().numpy()
            table.std[m * num_layers + l] = flat.std(dim=0).clamp_min(1e-3).cpu().numpy()
    return table
