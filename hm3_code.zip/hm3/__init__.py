"""HM3: hierarchical model merging with architecture-level search.

Design rule for this package:
    * modules that only need numpy must stay importable without torch, so the
      action space / reward / metrics / weight-mapping logic can be unit tested
      on a CPU-only machine;
    * torch-dependent modules (policy, alignment, ppo, assemble, train) import
      torch at module level and are only imported by the training entry point.

"""

__version__ = "1.0.0"

__all__ = [
    "actions",
    "reward",
    "metrics",
    "weights",
]
