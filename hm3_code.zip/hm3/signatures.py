"""Fixed-size layer-parameter sketches used by the state encoder ``phi``.

The selected layer parameters have to be encoded into a fixed-size vector.  A
memory-safe, deterministic sketch is used so the dimension does not depend on the
layer size:

    * 4 aggregate statistics of the layer (mean / std / L2 norm / mean |w|);
    * the L2 norm of up to ``max_tensors`` parameter tensors (padded with zeros);
    * a ``proj_dim``-dimensional block-mean sketch of the flattened parameters
      (a deterministic, memory-safe stand-in for a random projection: a full
      dense projection of a 50M-parameter layer would need a ~13 GB (fp32) matrix).

The sketch is computed once per (model, layer) and then projected by the
*learnable* part of ``phi`` inside the policy network, so gradients still flow
through a trainable encoder.
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np

STATS_PER_LAYER = 4


def _tensor_sketch(tensor, proj_dim: int) -> np.ndarray:
    flat = tensor.detach().to("cpu", dtype=None).float().reshape(-1).numpy()
    n = flat.size
    if n == 0:
        return np.zeros(proj_dim, dtype=np.float32)
    if n >= proj_dim:
        usable = (n // proj_dim) * proj_dim
        return flat[:usable].reshape(proj_dim, -1).mean(axis=1).astype(np.float32)
    out = np.zeros(proj_dim, dtype=np.float32)
    out[:n] = flat
    return out


def layer_signature(layer, proj_dim: int = 64, max_tensors: int = 12) -> np.ndarray:
    """Sketch of a single transformer block (always ``signature_dim`` long)."""
    total = 0
    acc_sum = 0.0
    acc_sq = 0.0
    acc_abs = 0.0
    norms: List[float] = []
    sketch = np.zeros(proj_dim, dtype=np.float32)
    counted = 0
    for _, param in layer.named_parameters():
        arr = param.detach().to("cpu").float().reshape(-1).numpy()
        n = arr.size
        if n == 0:
            continue
        total += int(n)
        acc_sum += float(arr.sum())
        acc_sq += float(np.square(arr).sum())
        acc_abs += float(np.abs(arr).sum())
        if counted < max_tensors:
            norms.append(float(np.sqrt(np.square(arr).sum())))
            sketch += _tensor_sketch(param, proj_dim)
            counted += 1
    if counted > 0:
        sketch /= float(counted)
    if total > 0:
        mean = acc_sum / total
        var = max(0.0, acc_sq / total - mean * mean)
        stats = [mean, float(np.sqrt(var)), float(np.sqrt(acc_sq)), acc_abs / total]
    else:
        stats = [0.0] * STATS_PER_LAYER
    padded_norms = list(norms) + [0.0] * (max_tensors - len(norms))
    return np.concatenate(
        [np.asarray(stats, dtype=np.float32), np.asarray(padded_norms, dtype=np.float32), sketch]
    )


def signature_dim(proj_dim: int = 64, max_tensors: int = 12) -> int:
    return STATS_PER_LAYER + max_tensors + proj_dim


_DECODER_LAYER_PATHS = (
    ("model", "layers"),
    ("transformer", "h"),
    ("model", "decoder", "layers"),
    ("model", "layers"),
)


def _decoder_layers(model):
    """Locate the decoder-layer container across HF architectures (torch-free)."""
    for path in _DECODER_LAYER_PATHS:
        obj = model
        for attr in path:
            obj = getattr(obj, attr, None)
            if obj is None:
                break
        if obj is not None and hasattr(obj, "__getitem__") and hasattr(obj, "__len__"):
            return obj
    raise AttributeError("could not locate the decoder layer list on this model")


def build_signature_table(
    models: Sequence,
    num_layers: int,
    proj_dim: int = 64,
    max_tensors: int = 12,
) -> Tuple[np.ndarray, int]:
    """Signature table of shape ``[num_models * num_layers + 1, sig_dim]``.

    The extra row is the STOP action, whose signature is left at zero.
    """
    dim = signature_dim(proj_dim, max_tensors)
    table = np.zeros((len(models) * num_layers + 1, dim), dtype=np.float32)
    for m, model in enumerate(models):
        layers = _decoder_layers(model)
        for l in range(min(num_layers, len(layers))):
            table[m * num_layers + l] = layer_signature(layers[l], proj_dim, max_tensors)
    return table, dim
