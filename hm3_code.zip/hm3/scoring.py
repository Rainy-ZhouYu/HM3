"""Task scoring through lm-evaluation-harness.

This module covers the lm-evaluation-harness side and keeps the metric keys
explicit:

* HumanEval is scored with **pass@1**;
* GSM8K uses ``exact_match,flexible-extract`` ("flexible match");
* translation uses chrF;
* GLUE / XNLI / MathQA use accuracy.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Mapping, Optional, Sequence

DEFAULT_METRIC_KEYS: Dict[str, List[str]] = {
    "glue": ["acc,none", "acc"],
    "xnli": ["acc,none", "acc"],
    "wmt14-en-fr": ["chrf,none", "chrf"],
    "wmt14-fr-en": ["chrf,none", "chrf"],
    "wmt16-en-de": ["chrf,none", "chrf"],
    "wmt16-de-en": ["chrf,none", "chrf"],
    "wmt16-en-ro": ["chrf,none", "chrf"],
    "wmt16-ro-en": ["chrf,none", "chrf"],
    "iwslt2017-en-ar": ["chrf,none", "chrf"],
    "iwslt2017-ar-en": ["chrf,none", "chrf"],
    "gsm8k_platinum_cot": ["exact_match,flexible-extract", "exact_match,none"],
    "gsm8k": ["exact_match,flexible-extract", "exact_match,none"],
    "mathqa": ["acc,none", "acc", "acc_norm,none", "acc_norm"],
    "mbpp": ["pass_at_1,none", "pass_at_1", "pass@1,none", "pass@1"],
    "humaneval": ["pass@1,none", "pass@1", "pass_at_1,none", "pass_at_1"],
}


@dataclass
class ScoreResult:
    scores: Dict[str, float]
    raw: Dict[str, object] = field(default_factory=dict)
    missing: List[str] = field(default_factory=list)

    def as_dict(self) -> Dict[str, object]:
        return {"scores": dict(self.scores), "missing": list(self.missing)}


class LmEvalScorer:
    """Callable ``model_path -> {task: score}``.

    ``limit`` is a fraction of each task's documents (lm-eval semantics), which is
    what the search phase uses; ``limit=None`` evaluates the full benchmark.
    """

    def __init__(
        self,
        tasks: Sequence[str],
        limit: Optional[float] = 0.005,
        batch_size: int = 4,
        device: str = "cuda",
        metric_keys: Optional[Mapping[str, Sequence[str]]] = None,
        work_dir: Optional[str] = None,
        apply_chat_template: bool = False,
        num_fewshot: Optional[int] = None,
        confirm_run_unsafe_code: bool = True,
        reuse_tasks: bool = False,
    ) -> None:
        self.tasks = [str(t) for t in tasks]
        self.limit = limit
        self.batch_size = int(batch_size)
        self.device = device
        self.metric_keys = {k: list(v) for k, v in (metric_keys or DEFAULT_METRIC_KEYS).items()}
        self.work_dir = work_dir
        self.apply_chat_template = bool(apply_chat_template)
        self.num_fewshot = num_fewshot
        self.confirm_run_unsafe_code = bool(confirm_run_unsafe_code)
        self.reuse_tasks = bool(reuse_tasks)
        self._task_dict = None
        self.last_raw: Dict[str, object] = {}
        self.calls = 0
        if work_dir:
            os.makedirs(work_dir, exist_ok=True)

    # ------------------------------------------------------------------ inner
    def _candidates(self, task: str) -> List[str]:
        return list(self.metric_keys.get(task, [])) or ["acc,none", "acc", "chrf,none"]

    def _pick(self, task: str, metrics: Mapping[str, object]) -> Optional[float]:
        for key in self._candidates(task):
            if key in metrics and metrics[key] is not None:
                return float(metrics[key])
        return None

    def _run(self, hflm) -> ScoreResult:
        import lm_eval

        if self.reuse_tasks:
            # Building the task objects once (instead of on every evaluation)
            # skips re-reading the datasets from disk for every candidate path,
            # which is the dominant cost of the search loop.
            from lm_eval.evaluator import evaluate

            if self._task_dict is None:
                from lm_eval.tasks import TaskManager

                self._task_dict = TaskManager().load_task_or_group(self.tasks)
            kwargs = dict(lm=hflm, task_dict=self._task_dict, verbosity="ERROR")
            if self.limit is not None:
                kwargs["limit"] = self.limit
            if self.num_fewshot is not None:
                kwargs["num_fewshot"] = self.num_fewshot
            results = evaluate(**kwargs)
        else:
            kwargs = dict(
                model=hflm,
                tasks=self.tasks,
                batch_size=self.batch_size,
                confirm_run_unsafe_code=self.confirm_run_unsafe_code,
                verbosity="ERROR",
            )
            if self.limit is not None:
                kwargs["limit"] = self.limit
            if self.num_fewshot is not None:
                kwargs["num_fewshot"] = self.num_fewshot
            results = lm_eval.evaluator.simple_evaluate(**kwargs)
        self.last_raw = results
        self.calls += 1

        scores: Dict[str, float] = {}
        missing: List[str] = []
        table = results.get("results", {})
        for task in self.tasks:
            metrics = table.get(task)
            if metrics is None:
                missing.append(task)
                continue
            value = self._pick(task, metrics)
            if value is None:
                missing.append(task)
            else:
                scores[task] = value

        if self.work_dir:
            os.makedirs(self.work_dir, exist_ok=True)
            tag = f"eval_{self.calls:05d}"
            with open(os.path.join(self.work_dir, f"{tag}.json"), "w", encoding="utf-8") as fh:
                json.dump(results, fh, default=str, indent=2)
        return ScoreResult(scores=scores, raw={"num_calls": self.calls}, missing=missing)

    def evaluate(self, model_path: str) -> ScoreResult:
        """Score a model directory that is already on disk."""
        import lm_eval.models.huggingface

        model_args = {}
        if self.apply_chat_template:
            model_args["apply_chat_template"] = True
        hflm = lm_eval.models.huggingface.HFLM(
            model_path,
            device=self.device,
            parallelize=(self.device.startswith("cuda")),
            batch_size=self.batch_size,
            **model_args,
        )
        return self._run(hflm)

    def evaluate_in_memory(self, model, tokenizer) -> ScoreResult:
        """Score an in-memory (assembled) model - avoids writing ~3 GB per candidate."""
        import lm_eval.models.huggingface

        model_args = {}
        if self.apply_chat_template:
            model_args["apply_chat_template"] = True
        base = lm_eval.models.huggingface.HFLM

        # An assembled model mixes layers from different checkpoints.  During
        # ``generate`` the shared ``DynamicCache`` can end up with a length that
        # disagrees with the causal mask built for the current step
        # (``size of tensor a (1534) must match tensor b (767)``).  lm-eval
        # hard-codes ``use_cache=True`` in its own ``generate`` call, so the flag
        # is forced here by wrapping ``model.generate``.  Recomputing the prefix
        # each step is slower but deterministic, and the search cost is dominated
        # by dataset loading anyway.
        import functools

        original_generate = model.generate

        @functools.wraps(original_generate)
        def _no_cache_generate(*args, **kwargs):
            kwargs["use_cache"] = False
            kwargs.pop("past_key_values", None)
            return original_generate(*args, **kwargs)

        model.generate = _no_cache_generate

        hflm = base(
            pretrained=model,
            tokenizer=tokenizer,
            device=self.device,
            parallelize=False,
            # batch 1 for assembled models: batching mixes requests with very
            # different lengths and is what triggered the cache/mask mismatch.
            batch_size=1,
            **model_args,
        )
        return self._run(hflm)

    def __call__(self, model_path: str) -> Dict[str, float]:
        return self.evaluate(model_path).scores
