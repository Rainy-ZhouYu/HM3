"""Parameter-level subproblem via mergekit.

Every preference vector lambda produces one merged model, which is then appended
to the architecture-level candidate pool as model ``K+1``.

Design notes
------------
* ``density`` is an explicit argument (``1.0`` disables the TIES trimming);
* the merge weights come from :mod:`hm3.weights`, i.e. they are attached to the
  model that was fine-tuned for the corresponding task, and the mapping is
  written to the index JSON for auditing.
"""

from __future__ import annotations

import itertools
import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Iterable, List, Optional, Sequence

from .weights import MergeWeightPlan, model_weight_vector


def slugify(text: str) -> str:
    text = re.sub(r"[^A-Za-z0-9\-.]+", "-", str(text).replace("/", "-").replace("_", "-"))
    return re.sub(r"-{2,}", "-", text).strip("-")[:80]


def resolve_model_ref(ref: str) -> str:
    """Map a HF repo id to its local snapshot so the merge can run offline.

    mergekit resolves repo ids through ``huggingface_hub``, which fails when the
    process runs with ``HF_HUB_OFFLINE=1`` even if the weights are cached.  Local
    paths bypass that lookup entirely.
    """
    if not ref or os.path.isdir(ref):
        return ref
    try:
        from huggingface_hub import snapshot_download

        return snapshot_download(ref, local_files_only=True)
    except Exception:  # pragma: no cover - depends on the local cache
        return ref


def build_merge_config(
    models: Sequence[str],
    weights: Sequence[float],
    merge_method: str = "dare_ties",
    base_model: Optional[str] = None,
    density: float = 1.0,
    dtype: str = "bfloat16",
    extra_parameters: Optional[Dict] = None,
    resolve_paths: bool = True,
) -> Dict:
    if len(models) != len(weights):
        raise ValueError("weights must have one entry per model")
    params: Dict[str, object] = {"int8_mask": True}
    if extra_parameters:
        params.update(extra_parameters)
    return {
        "models": [
            {
                "model": resolve_model_ref(m) if resolve_paths else m,
                "parameters": {"weight": float(w), "density": float(density)},
            }
            for m, w in zip(models, weights)
        ],
        "merge_method": merge_method,
        "dtype": dtype,
        "parameters": params,
        **(
            {"base_model": resolve_model_ref(base_model) if resolve_paths else base_model}
            if base_model
            else {}
        ),
    }


@dataclass
class MergeRun:
    merge_method: str
    models: List[str]
    weights: List[float]
    yml_path: str
    out_path: str
    status: str

    def as_dict(self) -> Dict[str, object]:
        return {
            "merge_method": self.merge_method,
            "models": list(self.models),
            "weights": list(self.weights),
            "yml_path": self.yml_path,
            "out_path": self.out_path,
            "status": self.status,
        }


def run_parameter_merges(
    plan: MergeWeightPlan,
    merge_methods: Sequence[str],
    output_root: str,
    setting_dir: str,
    base_model: Optional[str] = None,
    density: float = 1.0,
    dtype: str = "bfloat16",
    dry_run: bool = False,
    combination_sizes: Sequence[int] = (3,),
    merge_device: str = "cuda",
) -> Dict[str, object]:
    import yaml

    os.makedirs(output_root, exist_ok=True)
    os.makedirs(setting_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    runs: List[MergeRun] = []

    models = list(plan.models)
    weights_by_model = dict(plan.model_weights)
    for method in merge_methods:
        for size in combination_sizes:
            for group in itertools.combinations(models, int(size)):
                group_weights = [float(weights_by_model[m]) for m in group]
                config = build_merge_config(
                    models=group,
                    weights=group_weights,
                    merge_method=method,
                    base_model=base_model,
                    density=density,
                    dtype=dtype,
                )
                slug = "+".join(slugify(m) for m in group)
                yml_path = os.path.join(setting_dir, f"{method}_{size}_{slug}_{timestamp}.yml")
                with open(yml_path, "w", encoding="utf-8") as fh:
                    yaml.safe_dump(config, fh, sort_keys=False, allow_unicode=True)
                out_dir = os.path.join(output_root, method, f"{size}_{slug}", timestamp)
                os.makedirs(out_dir, exist_ok=True)
                status = "dry_run"
                if not dry_run:
                    try:
                        import torch
                        from mergekit.config import MergeConfiguration
                        from mergekit.merge import MergeOptions, run_merge

                        merge_config = MergeConfiguration.model_validate(config)
                        run_merge(
                            merge_config,
                            out_path=out_dir,
                            options=MergeOptions(
                                lora_merge_cache="/tmp",
                                cuda=bool(merge_device.startswith("cuda")),
                                copy_tokenizer=True,
                                lazy_unpickle=False,
                                low_cpu_memory=False,
                            ),
                        )
                        status = "success"
                    except Exception as exc:  # pragma: no cover - depends on mergekit
                        status = f"error: {exc}"
                runs.append(
                    MergeRun(
                        merge_method=method,
                        models=list(group),
                        weights=group_weights,
                        yml_path=yml_path,
                        out_path=out_dir,
                        status=status,
                    )
                )

    index = {
        "timestamp": timestamp,
        "task_to_model": dict(plan.task_to_model),
        "tasks": list(plan.tasks),
        "models": list(plan.models),
        "task_weights": dict(plan.task_weights),
        "model_weights": dict(plan.model_weights),
        "density": float(density),
        "merge_methods": list(merge_methods),
        "base_model": base_model,
        "runs": [r.as_dict() for r in runs],
    }
    index_path = os.path.join(output_root, f"merge_runs_{timestamp}.json")
    with open(index_path, "w", encoding="utf-8") as fh:
        json.dump(index, fh, ensure_ascii=False, indent=2)
    return {"index_path": index_path, "index": index}


def successful_paths(index: MappingLike) -> List[str]:
    return [
        str(run["out_path"])
        for run in index.get("runs", [])
        if str(run.get("status")) == "success" and run.get("out_path")
    ]


MappingLike = Dict[str, object]
