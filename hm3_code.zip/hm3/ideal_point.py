"""Ideal point z*_k: the best observed value of each objective.

If ``--ideal-point`` is left empty, the Tchebycheff scalarisation falls back to
``z* = 1.0`` for every task.  This module measures the ideal point on the
candidates instead (and optionally on the merged models) and writes it next to
the run, so the search and the report use the same reference.
"""

from __future__ import annotations

import argparse
import json
import os
from typing import Callable, Dict, Mapping, Optional, Sequence

from .metrics import ideal_point_from_scores

Scorer = Callable[[str], Mapping[str, float]]


def compute_ideal_point(
    scorer: Scorer,
    model_paths: Sequence[str],
    tasks: Sequence[str],
    out_path: Optional[str] = None,
    cache_path: Optional[str] = None,
) -> Dict[str, object]:
    cached: Dict[str, Mapping[str, float]] = {}
    if cache_path and os.path.isfile(cache_path):
        with open(cache_path, "r", encoding="utf-8") as fh:
            cached = json.load(fh)

    table: Dict[str, Mapping[str, float]] = {}
    for path in model_paths:
        if path in cached:
            table[path] = cached[path]
            continue
        scores = dict(scorer(path))
        table[path] = scores
        if cache_path:
            cached[path] = scores
            os.makedirs(os.path.dirname(cache_path), exist_ok=True)
            with open(cache_path, "w", encoding="utf-8") as fh:
                json.dump(cached, fh, ensure_ascii=False, indent=2)

    missing = [t for t in tasks if all(table[p].get(t) is None for p in table)]
    if missing:
        raise ValueError(f"no candidate produced a score for {missing}")
    ideal = ideal_point_from_scores(table, tasks)
    payload = {"ideal_point": ideal, "candidate_scores": table, "tasks": list(tasks)}
    if out_path:
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
    return payload


def main() -> None:
    from .scoring import LmEvalScorer

    ap = argparse.ArgumentParser(description="Measure the ideal point z* on candidates.")
    ap.add_argument("--models", required=True, help="comma separated model paths/repo ids")
    ap.add_argument("--tasks", required=True)
    ap.add_argument("--limit", type=float, default=None)
    ap.add_argument("--batch-size", type=int, default=4)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    tasks = [t.strip() for t in args.tasks.split(",") if t.strip()]
    models = [m.strip() for m in args.models.split(",") if m.strip()]
    scorer = LmEvalScorer(
        tasks=tasks,
        limit=args.limit,
        batch_size=args.batch_size,
        device=args.device,
        work_dir=os.path.join(os.path.dirname(args.out), "raw"),
    )
    payload = compute_ideal_point(
        scorer,
        models,
        tasks,
        out_path=args.out,
        cache_path=os.path.join(os.path.dirname(args.out), "ideal_point_cache.json"),
    )
    print(json.dumps(payload["ideal_point"], indent=2))


if __name__ == "__main__":
    main()
