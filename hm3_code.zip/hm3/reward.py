"""Architecture-level reward.

Three modes are available:

* ``weighted_sum`` (default): ``R = sum_k lambda_k * f_k - beta * T``, i.e. the
  preference-weighted task performance minus a path-length penalty;
* ``tchebycheff``: ``R = -max_k lambda_k * |f_k - z*_k|`` against an ideal point;
* ``legacy``: the Tchebycheff distance plus a small weighted-sum term.

The terminal reward is assigned to every step of the trajectory
(``R_t = R / T``), which is what keeps the actor-critic update well defined.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, Mapping, Optional, Sequence, Tuple

import numpy as np

MODES = ("weighted_sum", "tchebycheff", "legacy")

TASK_ALIASES = {
    "gsm8k": "gsm8k_platinum_cot",
    "wmt14": "wmt14-en-fr",
}


def canonical_task(task: str) -> str:
    return TASK_ALIASES.get(str(task), str(task))


def to_unit_interval(value: float, scale: str = "auto") -> float:
    """Map a raw benchmark metric onto [0, 1].

    ``auto`` keeps values in [0, 1] untouched and divides larger values by 100
    (chrF / BLEU style metrics).  This keeps the objective comparable
    across accuracy-like and score-like tasks.
    """
    value = float(value)
    if scale == "raw":
        return value
    if scale != "auto":
        raise ValueError(f"unknown scale: {scale}")
    return value / 100.0 if value > 1.0 else value


def normalize_weights(weights: Mapping[str, float], tasks: Sequence[str]) -> Dict[str, float]:
    """Project the preference vector back onto the probability simplex."""
    w = np.array([float(weights.get(canonical_task(t), weights.get(t, 0.0))) for t in tasks], dtype=float)
    if not np.all(np.isfinite(w)):
        raise ValueError(f"non-finite preference weights: {weights}")
    if np.any(w < 0):
        raise ValueError(f"negative preference weights are not allowed: {weights}")
    total = float(w.sum())
    if total <= 0.0:
        w = np.full(len(tasks), 1.0 / max(1, len(tasks)))
    else:
        w = w / total
    return {canonical_task(t): float(wi) for t, wi in zip(tasks, w)}


@dataclass
class RewardConfig:
    mode: str = "weighted_sum"
    beta: float = 0.0
    tie_break: float = 0.0           # only used by ``tchebycheff``; 0.0 = no extra term
    penalty_on_fail: float = -1e3
    ideal_point: Mapping[str, float] = field(default_factory=dict)
    default_ideal: float = 1.0
    score_scale: str = "auto"
    normalize: bool = True
    max_path_len: Optional[int] = None  # only used by ``legacy`` mode

    def __post_init__(self) -> None:
        if self.mode not in MODES:
            raise ValueError(f"reward mode must be one of {MODES}, got {self.mode!r}")
        if self.beta < 0:
            raise ValueError("beta must be >= 0")


@dataclass
class RewardBreakdown:
    reward: float
    values: np.ndarray
    weights: np.ndarray
    tasks: Tuple[str, ...]
    path_len: int
    mode: str
    penalty: float = 0.0
    failure: bool = False

    def as_dict(self) -> Dict[str, object]:
        return {
            "reward": self.reward,
            "values": self.values.tolist(),
            "weights": self.weights.tolist(),
            "tasks": list(self.tasks),
            "path_len": self.path_len,
            "mode": self.mode,
            "penalty": self.penalty,
            "failure": self.failure,
        }


class RewardFn:
    """Callable reward used by the search environment."""

    def __init__(self, config: RewardConfig, tasks: Sequence[str]) -> None:
        self.config = config
        self.tasks = tuple(canonical_task(t) for t in tasks)

    def __call__(
        self,
        scores: Mapping[str, float],
        weights: Mapping[str, float],
        path_len: int,
    ) -> RewardBreakdown:
        cfg = self.config
        missing = [t for t in self.tasks if scores.get(t) is None]
        if missing:
            return RewardBreakdown(
                reward=float(cfg.penalty_on_fail),
                values=np.zeros(len(self.tasks), dtype=np.float32),
                weights=np.zeros(len(self.tasks), dtype=np.float32),
                tasks=self.tasks,
                path_len=int(path_len),
                mode=cfg.mode,
                failure=True,
            )

        raw = np.array([float(scores[t]) for t in self.tasks], dtype=float)
        values = np.array([to_unit_interval(v, cfg.score_scale) for v in raw], dtype=float)

        if cfg.normalize:
            w_map = normalize_weights(weights, self.tasks)
        else:
            w_map = {canonical_task(k): float(v) for k, v in weights.items()}
        w = np.array([float(w_map.get(t, 0.0)) for t in self.tasks], dtype=float)

        if cfg.mode == "weighted_sum":
            # reward = sum_k lambda_k f_k - beta * T
            reward = float(np.sum(w * values))
            penalty = float(cfg.beta) * float(path_len)
            reward -= penalty
        elif cfg.mode == "tchebycheff":
            ideal = np.array(
                [
                    to_unit_interval(
                        float(cfg.ideal_point.get(t, cfg.ideal_point.get(t, cfg.default_ideal))),
                        cfg.score_scale,
                    )
                    for t in self.tasks
                ],
                dtype=float,
            )
            distance = float(np.max(w * np.abs(ideal - values)))
            reward = -distance
            if cfg.tie_break:
                reward += float(cfg.tie_break) * float(np.sum(w * values))
            penalty = float(cfg.beta) * float(path_len)
            reward -= penalty
        else:  # legacy
            ideal = np.array(
                [
                    to_unit_interval(float(cfg.ideal_point.get(t, cfg.default_ideal)), cfg.score_scale)
                    for t in self.tasks
                ],
                dtype=float,
            )
            distance = float(np.max(w * np.abs(ideal - values)))
            reward = -distance + 0.05 * float(np.sum(w * values))
            scale = float(cfg.max_path_len or max(1, path_len))
            penalty = float(cfg.beta) * float(path_len) / scale
            reward -= penalty

        return RewardBreakdown(
            reward=float(reward),
            values=values.astype(np.float32),
            weights=w.astype(np.float32),
            tasks=self.tasks,
            path_len=int(path_len),
            mode=cfg.mode,
            penalty=float(penalty),
        )


def uniform_per_step(reward: float, path_len: int) -> float:
    """The terminal reward is shared uniformly over all timesteps."""
    if path_len <= 0:
        return float(reward)
    return float(reward) / float(path_len)


def weighted_sum_reward(values: Iterable[float], weights: Iterable[float], path_len: int, beta: float = 0.0) -> float:
    """Pure-numpy reference of the weighted-sum reward, used by the unit tests."""
    v = np.asarray(list(values), dtype=float)
    w = np.asarray(list(weights), dtype=float)
    return float(np.sum(w * v) - float(beta) * float(path_len))

