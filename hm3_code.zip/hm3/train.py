"""End-to-end runner for the architecture-level search.

Example:

    python -m hm3.train --candidates Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Coder-1.5B,Qwen/Qwen2.5-Math-1.5B \
        --base-model Qwen/Qwen2.5-1.5B --tasks xnli_en,gsm8k_platinum_cot,mathqa \
        --task-to-model xnli_en=0,gsm8k_platinum_cot=1,mathqa=2 \
        --subproblems 5 --max-iters 1000 --episodes-per-iter 2 \
        --reward-mode weighted_sum --alignment-mode always \
        --search-limit 0.005 --output-root runs --run-name my_run

What the runner does:
    * parameter level: merges the candidates per preference vector with mergekit,
      and appends the merged model to the pool as model K+1;
    * architecture level: searches an inference path over {(model, layer)} with a
      Wolpertinger-mapped actor-critic (PPO), a GRU-encoded trajectory state and
      psi_m / psi_l / phi encoders;
    * any (model, layer) pair is selectable (``--ordered-actions`` restricts this
      to the structured case where position t must use layer t);
    * path length is variable through the STOP action
      (``--min-path-len`` / ``--max-path-len``);
    * reward = sum_k lambda_k f_k - beta * T (``--reward-mode weighted_sum``);
    * alignment layers between junctions, fitted on calibration activations
      (optionally with a low-rank term via ``--alignment-rank``);
    * explicit task -> model mapping for the parameter-level merge weights;
    * online PPO by default, with an optional prior pool / behaviour cloning /
      replay buffer (``--train-mode prior_bc``, ``--replay-ratio``);
    * ideal point measured on the candidates plus a Pareto / HV report.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import platform
import random
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from .actions import ModelLayerPool, PathConstraints, decode_path
from .alignment import AlignmentMLP, ActivationStats, fit_alignment, collect_activation_stats
from .assemble import build_merged_model, save_merged_model
from .env import LayerPathEnv
from .ideal_point import compute_ideal_point
from .merge_upper import run_parameter_merges
from .metrics import pareto_report
from .policy import ActorCritic, PolicyConfig
from .ppo import PPOAgent, PPOConfig
from .reward import RewardConfig, RewardFn
from .scoring import LmEvalScorer
from .signatures import build_signature_table
from .weights import build_merge_weight_plan, parse_task_model_map, validate_model_order
from .wolpertinger import ActionEmbedding, WolpertingerConfig, WolpertingerMapper


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except Exception:  # pragma: no cover
        pass


def git_revision(path: str) -> str:
    try:
        out = subprocess.run(
            ["git", "-C", path, "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            stdin=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
        return out.stdout.strip() or "n/a"
    except Exception:
        return "n/a"


@dataclass
class RunManifest:
    created: str
    host: str
    python: str
    git_revision: str
    args: Dict[str, object]
    candidates: List[str]
    base_model: str
    tasks: List[str]
    task_to_model: Dict[str, int]
    pool: Dict[str, object]
    preference_vectors: List[List[float]]
    ideal_point: Dict[str, float]
    parameter_merges: Dict[str, object]
    subproblems: List[Dict[str, object]] = field(default_factory=list)
    pareto: Optional[Dict[str, object]] = None

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(asdict(self), fh, ensure_ascii=False, indent=2)


def preference_vectors(num_tasks: int, num_vectors: int, alpha: float, seed: int) -> np.ndarray:
    """Sample lambda ~ Dirichlet(alpha, ..., alpha) on the K-simplex."""
    rng = np.random.default_rng(int(seed))
    return rng.dirichlet(np.full(int(num_tasks), float(alpha)), size=int(num_vectors))


def load_tokenizer_and_models(
    candidates: Sequence[str],
    base_model: str,
    dtype: str,
    device_map: Optional[str] = None,
):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    torch_dtype = getattr(torch, dtype)
    tokenizer = AutoTokenizer.from_pretrained(base_model, use_fast=True)
    models = []
    for path in candidates:
        kwargs = {"dtype": torch_dtype, "low_cpu_mem_usage": True}
        if device_map:
            kwargs["device_map"] = device_map
        try:
            model = AutoModelForCausalLM.from_pretrained(path, **kwargs)
        except TypeError:  # transformers < 4.56
            kwargs.pop("dtype")
            model = AutoModelForCausalLM.from_pretrained(path, torch_dtype=torch_dtype, **kwargs)
        model.eval()
        models.append(model)
    return tokenizer, models


def build_pool(models: Sequence, extra_names: Optional[Sequence[str]] = None) -> ModelLayerPool:
    names = list(extra_names or [])
    if len(names) < len(models):
        names += [f"candidate_{i}" for i in range(len(names), len(models))]
    num_layers, hidden = [], []
    for model in models:
        cfg = model.config
        num_layers.append(int(getattr(cfg, "num_hidden_layers")))
        hidden.append(int(getattr(cfg, "hidden_size")))
    return ModelLayerPool(names=names, num_layers=num_layers, hidden_dims=hidden)


def make_assembly_scorer(
    models: Sequence,
    tokenizer,
    pool: ModelLayerPool,
    scorer: LmEvalScorer,
    alignment: Optional[AlignmentMLP],
    alignment_mode: str,
    save_dir: Optional[str] = None,
):
    """Closure ``path -> {task: score}`` used by the search environment."""
    import torch

    cache: Dict[str, Dict[str, float]] = {}
    target_device = torch.device(scorer.device)

    def _score(path: Sequence[int]) -> Dict[str, float]:
        key = "-".join(str(int(a)) for a in path)
        if key in cache:
            return cache[key]
        merged = build_merged_model(models, pool, path, alignment, alignment_mode)
        # lm-eval does not move an already-initialised model, and the alignment
        # module may live on the GPU while the freshly assembled layers are on
        # the CPU: put the whole model on one device before scoring.
        merged = merged.to(target_device)
        cfg = getattr(merged, "config", None)
        print(
            f"[scorer] path={list(map(int, path))} depth={cfg.num_hidden_layers if cfg else '?'} "
            f"attn={getattr(cfg, '_attn_implementation', '?')} "
            f"use_cache={getattr(cfg, 'use_cache', '?')} dtype={next(merged.parameters()).dtype} "
            f"device={next(merged.parameters()).device}",
            flush=True,
        )
        result = scorer.evaluate_in_memory(merged, tokenizer)
        scores = dict(result.scores)
        if result.missing:
            print(f"[scorer] missing tasks {result.missing} for path {list(path)}", flush=True)
        cache[key] = scores
        if save_dir:
            os.makedirs(save_dir, exist_ok=True)
            with open(os.path.join(save_dir, f"path_eval_{len(cache):05d}.json"), "w", encoding="utf-8") as fh:
                json.dump({"path": [int(a) for a in path], "scores": scores}, fh, ensure_ascii=False, indent=2)
        return scores

    return _score


def build_calibration_batch(tokenizer, device, text: Optional[str] = None, length: int = 64):
    prompts = (text or "").strip() or (
        "Model merging combines the parameters of multiple fine-tuned models into a single "
        "model that performs well on several tasks at once."
    )
    enc = tokenizer(prompts, return_tensors="pt", truncation=True, max_length=int(length))
    return {k: v.to(device) for k, v in enc.items()}


def fit_alignment_maps(
    models: Sequence,
    tokenizer,
    pool: ModelLayerPool,
    device,
    steps: int = 200,
    coral_weight: float = 1.0,
    mean_weight: float = 1.0,
    max_junctions: int = 128,
    seed: int = 0,
    verbose: bool = False,
    rank: int = 0,
) -> Tuple[ActivationStats, List[Dict[str, object]]]:
    """Collect calibration statistics and fit the alignment maps (A6).

    The analytic part of the map (diagonal) is computed from the
    per-(model, layer) statistics on the fly, so only the trainable residual
    ``MLP_mu(m, l, t)`` needs fitting.  It is shared across junctions, hence a
    random subset of junctions (``max_junctions``) is enough to train it.
    """
    import torch

    batch = build_calibration_batch(tokenizer, device)
    stats = collect_activation_stats(models, batch, pool.max_layers, device)
    aligner = AlignmentMLP(
        stats=stats,
        hidden_dim=64,
        max_layers=pool.max_layers,
        num_models=pool.num_models,
        learnable=True,
        rank=int(rank),
    ).to(device)

    reports: List[Dict[str, object]] = []
    acts: List[torch.Tensor] = []
    with torch.no_grad():
        for model in models:
            model.to(device)
            out = model(**batch, output_hidden_states=True)
            acts.append(
                torch.stack([h.float() for h in out.hidden_states[1 : pool.max_layers + 1]]).cpu()
            )
            model.to("cpu")
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
    # acts[m] : [L, B, T, H] -> [L, tokens, H]
    flat_acts = [a.reshape(a.shape[0], -1, a.shape[-1]) for a in acts]

    junctions: List[Tuple[int, int, int, int]] = []
    for src_m in range(len(models)):
        for dst_m in range(len(models)):
            for src_l in range(int(pool.num_layers[src_m])):
                dst_l = min(src_l, pool.num_layers[dst_m] - 1)
                junctions.append((src_m, src_l, dst_m, dst_l))
    rng = np.random.default_rng(seed)
    if len(junctions) > max_junctions:
        idx = sorted(rng.choice(len(junctions), size=int(max_junctions), replace=False).tolist())
        junctions = [junctions[i] for i in idx]

    print(f"[alignment] fitting {len(junctions)} junction(s) x {steps} steps", flush=True)
    for src_m, src_l, dst_m, dst_l in junctions:
        report = fit_alignment(
            aligner,
            src_slot=stats.slot(src_m, src_l),
            dst_slot=stats.slot(dst_m, dst_l),
            src_acts=flat_acts[src_m][src_l],
            tgt_acts=flat_acts[dst_m][dst_l],
            steps=steps,
            coral_weight=coral_weight,
            mean_weight=mean_weight,
            verbose=verbose,
        )
        reports.append({"src": [src_m, src_l], "dst": [dst_m, dst_l], **report.as_dict()})
    return aligner, reports


def main(argv: Optional[Sequence[str]] = None) -> None:
    ap = argparse.ArgumentParser(description="HM3 architecture-level search.")
    # pool / tasks
    ap.add_argument(
        "--candidates",
        default="Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Coder-1.5B,Qwen/Qwen2.5-Math-1.5B",
    )
    ap.add_argument("--base-model", default="Qwen/Qwen2.5-1.5B")
    ap.add_argument("--tasks", default="xnli,gsm8k_platinum_cot,mbpp")
    ap.add_argument("--task-to-model", default="xnli=0,gsm8k_platinum_cot=1,mbpp=2")
    ap.add_argument("--apply-chat-template", action="store_true")
    # parameter level
    ap.add_argument("--subproblems", type=int, default=5)
    ap.add_argument(
        "--subproblem-indices",
        default="",
        help=(
            "comma separated subset of preference-vector indices to solve in this process, "
            "e.g. '0,2' - lets you shard the N subproblems across GPUs, since they are independent"
        ),
    )
    ap.add_argument("--dirichlet-alpha", type=float, default=1.0)
    ap.add_argument("--merge-methods", default="dare_ties")
    ap.add_argument("--density", type=float, default=1.0)
    ap.add_argument("--skip-parameter-merge", action="store_true")
    ap.add_argument("--parameter-model-paths", default="")
    ap.add_argument("--merge-combination-sizes", default="3")
    # search
    ap.add_argument("--max-iters", type=int, default=1000)
    ap.add_argument("--episodes-per-iter", type=int, default=2)
    ap.add_argument("--update-epochs", type=int, default=4)
    ap.add_argument("--minibatch-episodes", type=int, default=8)
    ap.add_argument("--gamma", type=float, default=0.99)
    ap.add_argument("--lam", type=float, default=0.95)
    ap.add_argument("--clip", type=float, default=0.2)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--ent-coef", type=float, default=0.01)
    ap.add_argument("--vf-coef", type=float, default=0.5)
    ap.add_argument("--eps-start", type=float, default=1.0)
    ap.add_argument("--eps-end", type=float, default=0.05)
    ap.add_argument("--eps-decay-iters", type=int, default=50)
    ap.add_argument(
        "--target-kl",
        type=float,
        default=0.03,
        help="early-stop the PPO epochs when the mean KL exceeds 1.5x this value (0 disables)",
    )
    ap.add_argument("--reward-assignment", default="uniform", choices=["uniform", "terminal"])
    # path constraints
    ap.add_argument("--max-path-len", type=int, default=0, help="0 = number of layers of the first candidate")
    ap.add_argument("--min-path-len", type=int, default=1)
    ap.add_argument("--no-repeat-actions", dest="no_repeat_actions", action="store_true", default=True)
    ap.add_argument("--allow-repeat-actions", dest="no_repeat_actions", action="store_false")
    ap.add_argument(
        "--ordered-actions",
        action="store_true",
        help="structured mode: position t may only use layer t of some model",
    )
    ap.add_argument("--allow-alignment", dest="allow_alignment", action="store_true", default=True)
    ap.add_argument("--no-alignment", dest="allow_alignment", action="store_false")
    # reward
    ap.add_argument("--reward-mode", default="weighted_sum", choices=["weighted_sum", "tchebycheff", "legacy"])
    ap.add_argument("--beta", type=float, default=0.0)
    ap.add_argument("--tie-break", type=float, default=0.0)
    ap.add_argument("--ideal-point", default="", help="path to an ideal-point JSON (see hm3.ideal_point)")
    ap.add_argument("--compute-ideal-point", action="store_true")
    # wolpertinger
    ap.add_argument("--wolp-k", type=int, default=64)
    ap.add_argument("--wolp-tau", type=float, default=0.1)
    ap.add_argument("--wolp-q-tau", type=float, default=0.1)
    ap.add_argument("--wolp-metric", default="cosine", choices=["cosine", "euclidean"])
    ap.add_argument("--wolp-score", default="mixed", choices=["embedding", "critic", "mixed"])
    ap.add_argument("--wolp-mix", type=float, default=1.0)
    ap.add_argument("--action-dim", type=int, default=64)
    # state encoder
    ap.add_argument("--hidden-dim", type=int, default=128)
    ap.add_argument("--token-dim", type=int, default=64)
    ap.add_argument("--gru-layers", type=int, default=1)
    ap.add_argument("--signature-proj-dim", type=int, default=64)
    # alignment
    ap.add_argument("--alignment-mode", default="always", choices=["never", "dim-mismatch", "model-change", "always"])
    ap.add_argument("--alignment-steps", type=int, default=200)
    ap.add_argument(
        "--alignment-rank",
        type=int,
        default=0,
        help=(
            "rank of the low-rank term added to the diagonal alignment map "
            "(0 = diagonal only; e.g. 16/32 to also reduce the covariance mismatch)"
        ),
    )
    ap.add_argument("--align-loss-coef", type=float, default=0.0)
    ap.add_argument("--fit-alignment", action="store_true", help="fit the alignment MLPs before the search")
    # IO
    ap.add_argument("--search-limit", type=float, default=0.005)
    ap.add_argument("--batch-size", type=int, default=4)
    ap.add_argument(
        "--reuse-tasks",
        action="store_true",
        help=(
            "build the lm-eval task objects once and reuse them for every candidate "
            "(skips re-reading the datasets each evaluation; big speed-up for the search loop)"
        ),
    )
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--dtype", default="bfloat16")
    ap.add_argument("--device-map", default="")
    ap.add_argument("--output-root", default="hm3_runs")
    ap.add_argument("--run-name", default="")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument(
        "--train-mode",
        default="online",
        choices=["online", "prior_bc"],
        help="online = online PPO only; prior_bc = add the prior pool and behaviour cloning",
    )
    ap.add_argument("--prior-bc-epochs", type=int, default=50, help="only used by --train-mode prior_bc")
    ap.add_argument("--prior-bc-lr", type=float, default=0.0, help="0 = use the PPO learning rate")
    ap.add_argument(
        "--replay-ratio",
        type=float,
        default=0.0,
        help="share of prior (K+1 pure-model) trajectories mixed into every PPO update; 0 = off",
    )
    ap.add_argument("--replay-value-coef", type=float, default=1.0, help="weight of the prior value-regression term")
    ap.add_argument("--replay-bc-coef", type=float, default=0.0, help="weight of the imitation term on prior actions")
    ap.add_argument("--eval-best", action="store_true", help="re-score the best path with the full benchmark")
    ap.add_argument(
        "--hv-margin",
        type=float,
        default=0.05,
        help="HV reference point = per-objective min - margin (0.0 makes HV degenerate)",
    )
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args(argv)

    import torch  # imported here so that --help works without the GPU stack

    torch_dtype = getattr(torch, args.dtype)

    stamp = time.strftime("%Y%m%d-%H%M%S")
    run_name = args.run_name or f"hm3_{stamp}"
    run_root = os.path.join(args.output_root, run_name)
    os.makedirs(run_root, exist_ok=True)
    seed_everything(args.seed)

    candidates = [c.strip() for c in args.candidates.split(",") if c.strip()]
    tasks = [t.strip() for t in args.tasks.split(",") if t.strip()]
    validate_model_order(candidates, args.base_model)
    task_to_model = parse_task_model_map(args.task_to_model)

    print(f"[train] candidates={candidates}")
    print(f"[train] tasks={tasks} task_to_model={task_to_model}")
    tokenizer, models = load_tokenizer_and_models(
        candidates, args.base_model, args.dtype, args.device_map or None
    )
    pool = build_pool(models, extra_names=[c.split("/")[-1] for c in candidates])
    max_path_len = int(args.max_path_len) or int(pool.num_layers[0])
    constraints = PathConstraints(
        max_path_len=max_path_len,
        min_path_len=int(args.min_path_len),
        allow_alignment=bool(args.allow_alignment),
        no_repeat_actions=bool(args.no_repeat_actions),
        ordered_actions=bool(args.ordered_actions),
    )
    print(f"[train] pool={pool.names} layers={pool.num_layers} dims={pool.hidden_dims} "
          f"max_path_len={constraints.max_path_len}")

    scorer = LmEvalScorer(
        tasks=tasks,
        limit=args.search_limit,
        batch_size=args.batch_size,
        device=args.device,
        work_dir=os.path.join(run_root, "raw_evals"),
        apply_chat_template=args.apply_chat_template,
        reuse_tasks=bool(args.reuse_tasks),
    )

    # ------------------------------------------------------------- ideal point
    ideal: Dict[str, float] = {}
    if args.ideal_point:
        with open(args.ideal_point, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
        ideal = {str(k): float(v) for k, v in payload.get("ideal_point", payload).items()}
    elif args.compute_ideal_point:
        payload = compute_ideal_point(
            scorer=scorer.evaluate,
            model_paths=candidates,
            tasks=tasks,
            out_path=os.path.join(run_root, "ideal_point.json"),
        )
        ideal = {str(k): float(v) for k, v in payload["ideal_point"].items()}
    print(f"[train] ideal_point={ideal or '(default 1.0 per task)'}")

    # ------------------------------------------------------- parameter level
    explicit_paths = [p.strip() for p in args.parameter_model_paths.split(",") if p.strip()]
    merge_methods = [m.strip() for m in args.merge_methods.split(",") if m.strip()]
    combination_sizes = [int(s) for s in args.merge_combination_sizes.split(",") if s.strip()]

    # ---------------------------------------------------------------- search
    pref = preference_vectors(len(tasks), int(args.subproblems), args.dirichlet_alpha, args.seed)
    np.savetxt(os.path.join(run_root, "preference_vectors.csv"), pref, delimiter=",")

    manifest = RunManifest(
        created=time.strftime("%Y-%m-%d %H:%M:%S"),
        host=platform.node(),
        python=sys.version.split()[0],
        git_revision=git_revision(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        args=vars(args),
        candidates=candidates,
        base_model=args.base_model,
        tasks=tasks,
        task_to_model=task_to_model,
        pool={"names": list(pool.names), "num_layers": list(map(int, pool.num_layers)),
              "hidden_dims": list(map(int, pool.hidden_dims))},
        preference_vectors=[[float(x) for x in row] for row in pref],
        ideal_point=ideal,
        parameter_merges={"per_subproblem": []},
    )
    manifest.save(os.path.join(run_root, "manifest.json"))

    wanted = [int(x) for x in args.subproblem_indices.split(",") if x.strip()] if args.subproblem_indices else None
    all_solutions: List[Dict[str, object]] = []
    all_alignment_reports: Dict[str, object] = {}
    for idx, lam in enumerate(pref):
        if wanted is not None and idx not in wanted:
            continue
        sub_root = os.path.join(run_root, f"pref_{idx:03d}")
        os.makedirs(sub_root, exist_ok=True)
        task_weights = {t: float(w) for t, w in zip(tasks, lam)}
        print(f"\n===== subproblem {idx + 1}/{len(pref)} lambda={task_weights} =====", flush=True)

        # every preference vector has its own parameter-level merged model, which
        # is appended to the pool as model K+1.
        sub_merged_paths = list(explicit_paths)
        sub_merge_info: Dict[str, object] = {}
        if not args.skip_parameter_merge:
            plan = build_merge_weight_plan(tasks, task_weights, candidates, task_to_model)
            sub_merge_info = run_parameter_merges(
                plan=plan,
                merge_methods=merge_methods,
                output_root=os.path.join(sub_root, "upper_pool"),
                setting_dir=os.path.join(sub_root, "setting"),
                base_model=args.base_model,
                density=float(args.density),
                dry_run=bool(args.dry_run),
                combination_sizes=combination_sizes,
            )
            from .merge_upper import successful_paths

            sub_merged_paths += successful_paths(sub_merge_info.get("index", {}))
            print(
                f"[subproblem {idx}] parameter merge weights={plan.model_weights} "
                f"-> {len(sub_merged_paths)} merged model(s)",
                flush=True,
            )

        sub_models = list(models)
        sub_names = list(pool.names)
        from transformers import AutoModelForCausalLM

        for path in sub_merged_paths:
            extra = AutoModelForCausalLM.from_pretrained(path, dtype=torch_dtype)
            extra.eval()
            sub_models.append(extra)
            sub_names.append(os.path.basename(path.rstrip("/")) or path)
        sub_pool = build_pool(sub_models, extra_names=sub_names)

        # the alignment maps belong to this subproblem, because the
        # candidate pool now contains the parameter-level merged model K+1 and
        # the statistics have to cover every model that a path may select.
        aligner = None
        alignment_reports: List[Dict[str, object]] = []
        if args.alignment_mode != "never":
            if args.fit_alignment and len(sub_models) > 1:
                print(f"[subproblem {idx}] fitting alignment maps on {len(sub_models)} models "
                      f"...", flush=True)
                aligner, alignment_reports = fit_alignment_maps(
                    sub_models,
                    tokenizer,
                    sub_pool,
                    args.device,
                    steps=int(args.alignment_steps),
                    seed=int(args.seed) + idx,
                    rank=int(args.alignment_rank),
                )
                all_alignment_reports[f"pref_{idx:03d}"] = alignment_reports
            else:
                # no fitting requested: fall back to an identity-initialised map
                # that still covers the full pool
                import torch as _torch

                stats = ActivationStats.zeros(
                    len(sub_models) * sub_pool.max_layers,
                    int(sub_pool.hidden_dims[0]),
                    sub_pool.max_layers,
                )
                aligner = AlignmentMLP(
                    stats,
                    hidden_dim=64,
                    max_layers=sub_pool.max_layers,
                    num_models=len(sub_models),
                    learnable=True,
                    rank=int(args.alignment_rank),
                ).to(_torch.device(args.device))

        reward_fn = RewardFn(
            RewardConfig(
                mode=args.reward_mode,
                beta=float(args.beta),
                tie_break=float(args.tie_break),
                ideal_point=ideal,
                max_path_len=constraints.max_path_len,
            ),
            tasks,
        )
        assembly_scorer = make_assembly_scorer(
            sub_models,
            tokenizer,
            sub_pool,
            scorer,
            aligner,
            args.alignment_mode,
            save_dir=os.path.join(sub_root, "path_evals"),
        )
        env = LayerPathEnv(
            pool=sub_pool,
            constraints=constraints,
            scorer=assembly_scorer,
            reward_fn=reward_fn,
            task_weights=task_weights,
        )

        signature_table, sig_dim = build_signature_table(
            sub_models, sub_pool.max_layers, proj_dim=int(args.signature_proj_dim)
        )
        net = ActorCritic(
            PolicyConfig(
                num_models=sub_pool.num_models,
                max_layers=sub_pool.max_layers,
                signature_dim=sig_dim,
                hidden_dim=int(args.hidden_dim),
                token_dim=int(args.token_dim),
                action_dim=int(args.action_dim),
                gru_layers=int(args.gru_layers),
            )
        )
        net.set_signature_table(signature_table)
        embedding = ActionEmbedding(
            num_actions=sub_pool.num_actions,
            dim=int(args.action_dim),
            num_models=sub_pool.num_models,
            max_layers=sub_pool.max_layers,
            seed=args.seed,
        )
        mapper = WolpertingerMapper(
            embedding,
            WolpertingerConfig(
                k=int(args.wolp_k),
                tau=float(args.wolp_tau),
                q_tau=float(args.wolp_q_tau),
                metric=args.wolp_metric,
                score_mode=args.wolp_score,
                mix_weight=float(args.wolp_mix),
            ),
        )
        agent = PPOAgent(
            net=net,
            mapper=mapper,
            pool=sub_pool,
            constraints=constraints,
            cfg=PPOConfig(
                gamma=args.gamma,
                lam=args.lam,
                clip_ratio=args.clip,
                lr=args.lr,
                update_epochs=args.update_epochs,
                minibatch_episodes=args.minibatch_episodes,
                ent_coef=args.ent_coef,
                vf_coef=args.vf_coef,
                reward_assignment=args.reward_assignment,
                eps_start=args.eps_start,
                eps_end=args.eps_end,
                eps_decay_iters=args.eps_decay_iters,
                seed=args.seed + idx,
                target_kl=float(args.target_kl),
                replay_ratio=float(args.replay_ratio),
                replay_value_coef=float(args.replay_value_coef),
                replay_bc_coef=float(args.replay_bc_coef),
            ),
            device=torch.device(args.device),
        )
        print(f"[train] policy params={net.count_parameters():,} "
              f"({net.count_parameters() * 4 / 1e6:.2f} MB fp32)")

        # ------------------------- prior pool: K+1 pure-model trajectories ------
        # One trajectory per candidate model (the K fine-tuned models plus the
        # parameter-level merged model K+1).  They are (a) evaluated once,
        # (b) written to ``prior_dump.jsonl``, (c) optionally used for behaviour
        # cloning and/or mixed into the PPO updates as a replay buffer.
        # Every one of these steps is recorded in solution.json / manifest.json.
        prior_info: Dict[str, object] = {}
        use_prior = args.train_mode == "prior_bc" or float(args.replay_ratio) > 0
        if use_prior:
            from .ppo import Episode

            priors = []
            for m in range(min(len(sub_models), sub_pool.num_models)):
                pure = [m * sub_pool.max_layers + l for l in range(int(sub_pool.num_layers[m]))]
                if len(pure) > constraints.max_path_len:
                    pure = pure[: constraints.max_path_len]
                if len(pure) < constraints.min_path_len:
                    continue
                scores = assembly_scorer(pure)
                breakdown = reward_fn(scores, task_weights, len(pure))
                priors.append(
                    Episode(
                        actions=list(pure),
                        path=list(pure),
                        stopped=False,
                        reward=float(breakdown.reward),
                        scores={k: float(v) for k, v in scores.items() if v is not None},
                        z=np.zeros((len(pure), net.cfg.action_dim), dtype=np.float32),
                        logp=np.zeros(len(pure), dtype=np.float32),
                        values=np.zeros(len(pure), dtype=np.float32),
                        source="prior",
                    )
                )
            if priors:
                with open(os.path.join(sub_root, "prior_dump.jsonl"), "w", encoding="utf-8") as fh:
                    for m, ep in enumerate(priors):
                        fh.write(
                            json.dumps(
                                {
                                    "model_index": m,
                                    "model": sub_pool.names[m] if m < len(sub_pool.names) else f"model_{m}",
                                    "selection": [int(a) for a in ep.actions],
                                    "path_length": len(ep.actions),
                                    "reward": float(ep.reward),
                                    "scores": ep.scores,
                                },
                                ensure_ascii=False,
                            )
                            + "\n"
                        )
            if priors and args.train_mode == "prior_bc":
                bc = agent.behavior_clone(
                    priors,
                    epochs=int(args.prior_bc_epochs),
                    lr=float(args.prior_bc_lr) or None,
                )
            else:
                bc = {"bc_loss": 0.0, "bc_entropy": 0.0, "epochs": 0}
            if priors:
                agent.set_prior_replay(priors)
                best_prior = max(priors, key=lambda ep: ep.reward)
                prior_info = {
                    "num_priors": len(priors),
                    "prior_rewards": [float(ep.reward) for ep in priors],
                    "prior_scores": [dict(ep.scores) for ep in priors],
                    "best_prior_reward": float(best_prior.reward),
                    "best_prior_path": list(best_prior.path),
                    "bc": bc,
                    "replay_ratio": float(args.replay_ratio),
                    "replay_value_coef": float(args.replay_value_coef),
                    "replay_bc_coef": float(args.replay_bc_coef),
                }
                print(
                    f"[prior] {len(priors)} pure-model trajectories, best={best_prior.reward:.6f}, "
                    f"bc_loss={bc['bc_loss']:.4f}, replay_ratio={float(args.replay_ratio):.2f} "
                    f"(-> prior_dump.jsonl)",
                    flush=True,
                )

        episode_log: List[Dict[str, object]] = []
        best = {"reward": float("-inf"), "path": None, "source": None, "scores": {}}
        if prior_info:
            best = {
                "reward": float(prior_info["best_prior_reward"]),
                "path": list(prior_info["best_prior_path"]),
                "source": "prior",
                "scores": {},
            }
        for it in range(1, int(args.max_iters) + 1):
            episodes = agent.collect_episodes(env, int(args.episodes_per_iter))
            # collect online episodes; prior replay (if enabled) is mixed inside update()
            agent.compute_gae(episodes)
            stats = agent.update(episodes)
            for ep in episodes:
                episode_log.append({"iter": it, **ep.as_dict()})
                if ep.reward > best["reward"]:
                    best = {"reward": float(ep.reward), "path": list(ep.path),
                            "source": "online", "scores": dict(ep.scores)}
            # short runs print every iteration so the curve is visible in the log
            if it % 10 == 0 or it == 1 or int(args.max_iters) <= 50:
                print(
                    f"[iter {it:04d}] eps={agent.epsilon():.3f} best={best['reward']:.4f} "
                    f"avg={np.mean([e.reward for e in episodes]):.4f} "
                    f"pi={stats.get('policy_loss', 0):.3f} v={stats.get('value_loss', 0):.3f} "
                    f"H={stats.get('entropy', 0):.3f} kl={stats.get('approx_kl', 0):.4f} "
                    f"evals={env.scorer_calls}",
                    flush=True,
                )
            with open(os.path.join(sub_root, "episodes.jsonl"), "a", encoding="utf-8") as fh:
                fh.write(json.dumps(episode_log[-len(episodes):], ensure_ascii=False) + "\n")

        greedy_ep = agent.greedy_rollout(env)
        print(f"[subproblem {idx}] greedy path={greedy_ep.path} reward={greedy_ep.reward:.6f}")
        greedy_reward = float(greedy_ep.reward)
        greedy_scores = dict(greedy_ep.scores)
        if greedy_ep.reward > best["reward"]:
            best = {"reward": float(greedy_ep.reward), "path": list(greedy_ep.path),
                    "source": "greedy", "scores": dict(greedy_ep.scores)}

        agent.save(os.path.join(sub_root, "policy.pt"))
        solution = {
            "subproblem": idx,
            "lambda": {t: float(w) for t, w in zip(tasks, lam)},
            "best_path": best["path"],
            "best_reward": best["reward"],
            "best_source": best["source"],
            "best_scores": best["scores"],
            "path_decoded": [
                {"model": sub_pool.names[m], "layer": l, "action": int(a)}
                for a, (m, l) in zip(best["path"] or [], decode_path(best["path"] or [], sub_pool.max_layers))
            ],
            "path_length": len(best["path"] or []),
            "scorer_calls": env.scorer_calls,
            "cache_hits": env.cache_hits,
            "train_mode": args.train_mode,
            "prior_info": prior_info,
            "greedy_reward": greedy_reward,
            "greedy_scores": greedy_scores,
            "alignment_mode": args.alignment_mode,
        }
        if best["path"] is not None:
            merged = build_merged_model(sub_models, sub_pool, best["path"], aligner, args.alignment_mode)
            save_merged_model(
                merged.to("cpu"),
                os.path.join(sub_root, "merged_model"),
                tokenizer=tokenizer,
                path=best["path"],
                pool=sub_pool,
                dtype=torch_dtype,
            )
            if args.eval_best:
                final_scorer = LmEvalScorer(
                    tasks=tasks, limit=None, batch_size=args.batch_size, device=args.device,
                    apply_chat_template=args.apply_chat_template,
                    work_dir=os.path.join(sub_root, "final_eval"),
                )
                final = final_scorer.evaluate(os.path.join(sub_root, "merged_model"))
                solution["final_scores"] = final.scores
                solution["final_missing"] = final.missing
            del merged
        all_solutions.append(solution)
        manifest.subproblems.append(solution)
        if sub_merge_info:
            per_sub = manifest.parameter_merges.setdefault("per_subproblem", [])
            per_sub.append(
                {
                    "subproblem": idx,
                    "task_weights": task_weights,
                    "model_weights": sub_merge_info.get("index", {}).get("model_weights", {}),
                    "index_path": sub_merge_info.get("index_path"),
                    "merged_models": sub_merged_paths,
                }
            )
        manifest.save(os.path.join(run_root, "manifest.json"))
        with open(os.path.join(sub_root, "solution.json"), "w", encoding="utf-8") as fh:
            json.dump(solution, fh, ensure_ascii=False, indent=2)

        # free the per-subproblem merged models before moving on
        del sub_models
        del agent, env, net, mapper, embedding
        import gc

        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    # ------------------------------------------------------- multi-objective
    points = []
    for sol in all_solutions:
        row = [sol["best_scores"].get(t) for t in tasks]
        if all(v is not None for v in row):
            points.append([float(v) for v in row])
    if len(points) >= 2:
        report = pareto_report(points, margin=float(args.hv_margin))
        manifest.pareto = {
            "tasks": tasks,
            "points": points,
            "hv_margin": float(args.hv_margin),
            **report.as_dict(),
        }
        print(f"[pareto] HV={report.hypervolume:.6f} front={report.indices}")
    manifest.subproblems = all_solutions
    manifest.save(os.path.join(run_root, "manifest.json"))
    if all_alignment_reports:
        with open(os.path.join(run_root, "alignment_fit.json"), "w", encoding="utf-8") as fh:
            json.dump(all_alignment_reports, fh, ensure_ascii=False, indent=2)
    print(f"[done] results in {run_root}")


if __name__ == "__main__":
    main()
