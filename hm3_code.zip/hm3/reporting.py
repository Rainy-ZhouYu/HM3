"""Reporting helpers: episode curves, Pareto/HV figures, alignment moments.

What is covered:

* first/second moment mismatch of a junction, before and after the alignment
  layer -> :func:`moment_report`;
* reward curves for one or more runs (e.g. online PPO vs prior+BC)
  -> :func:`plot_episode_rewards`;
* the approximate Pareto front with its hypervolume -> :func:`plot_pareto`.

Everything here is optional: the training pipeline does not import matplotlib.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np


def _plt():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    return plt


# --------------------------------------------------------------------- A8
def load_episodes(episodes_jsonl: str) -> List[Dict[str, object]]:
    """Read ``episodes.jsonl`` (one JSON array per line) into a flat list."""
    episodes: List[Dict[str, object]] = []
    if not os.path.isfile(episodes_jsonl):
        return episodes
    with open(episodes_jsonl, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            payload = json.loads(line)
            if isinstance(payload, list):
                episodes.extend(payload)
            else:
                episodes.append(payload)
    return episodes


def running_best(rewards: Sequence[float]) -> List[float]:
    out, best = [], float("-inf")
    for value in rewards:
        best = max(best, float(value))
        out.append(best)
    return out


def plot_episode_rewards(
    series: Dict[str, Sequence[float]],
    out_path: str,
    title: str = "Episode reward",
    xlabel: str = "episode",
    ylabel: str = "reward",
    show_running_best: bool = True,
) -> str:
    """Plot one or more reward curves (e.g. online mode vs prior+BC)."""
    plt = _plt()
    plt.figure(figsize=(8.0, 4.6))
    for label, rewards in series.items():
        if not rewards:
            continue
        plt.plot(rewards, linewidth=1.0, alpha=0.45, label=f"{label} (raw)")
        if show_running_best:
            plt.plot(running_best(rewards), linewidth=2.0, label=f"{label} (best so far)")
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(alpha=0.25)
    plt.legend(frameon=False, fontsize=8)
    plt.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    plt.savefig(out_path, dpi=200)
    plt.close()
    return out_path


# --------------------------------------------------------------------- A9
def plot_pareto(
    points: Sequence[Sequence[float]],
    tasks: Sequence[str],
    out_path: str,
    hv: Optional[float] = None,
    reference: Optional[Sequence[float]] = None,
    labels: Optional[Sequence[str]] = None,
) -> str:
    """Pareto scatter for 2 objectives, or 3D scatter for 3 objectives.

    Filled circles for the whole solution set, with the non-dominated subset
    highlighted.
    """
    from .metrics import pareto_front_indices

    pts = np.asarray(points, dtype=float)
    if pts.ndim != 2 or pts.shape[1] not in (2, 3):
        raise ValueError("plot_pareto supports 2 or 3 objectives")
    front = pareto_front_indices(pts)
    plt = _plt()
    if pts.shape[1] == 2:
        fig, ax = plt.subplots(figsize=(5.4, 5.0))
        ax.scatter(pts[:, 0], pts[:, 1], s=42, alpha=0.5, label="HM3 solutions")
        ax.scatter(pts[front, 0], pts[front, 1], s=80, facecolors="none", edgecolors="crimson",
                   linewidths=1.6, label="non-dominated")
        for i, (x, y) in enumerate(pts):
            if labels is not None and i < len(labels):
                ax.annotate(str(labels[i]), (x, y), fontsize=6, xytext=(3, 3),
                            textcoords="offset points")
        ax.set_xlabel(tasks[0])
        ax.set_ylabel(tasks[1])
    else:
        fig = plt.figure(figsize=(6.2, 5.4))
        ax = fig.add_subplot(111, projection="3d")
        ax.scatter(pts[:, 0], pts[:, 1], pts[:, 2], s=42, alpha=0.5, label="HM3 solutions")
        ax.scatter(pts[front, 0], pts[front, 1], pts[front, 2], s=80, facecolors="none",
                   edgecolors="crimson", linewidths=1.6, label="non-dominated")
        ax.set_xlabel(tasks[0])
        ax.set_ylabel(tasks[1])
        ax.set_zlabel(tasks[2])
    title = "HM3 approximate Pareto front"
    if hv is not None:
        title += f"  (HV={hv:.4f})"
    ax.set_title(title, fontsize=10)
    ax.legend(frameon=False, fontsize=8)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    return out_path


# --------------------------------------------------------------------- A6
@dataclass
class MomentReport:
    mean_l2_before: float
    mean_l2_after: float
    cov_fro_before: float
    cov_fro_after: float
    variance_ratio_before: float
    variance_ratio_after: float

    def as_dict(self) -> Dict[str, float]:
        return {
            "mean_l2_before": self.mean_l2_before,
            "mean_l2_after": self.mean_l2_after,
            "cov_fro_before": self.cov_fro_before,
            "cov_fro_after": self.cov_fro_after,
            "variance_ratio_before": self.variance_ratio_before,
            "variance_ratio_after": self.variance_ratio_after,
        }

    def improvement(self) -> Dict[str, float]:
        def ratio(before: float, after: float) -> float:
            if before <= 0:
                return float("nan")
            return float(after / before)

        return {
            "mean_l2_ratio": ratio(self.mean_l2_before, self.mean_l2_after),
            "cov_fro_ratio": ratio(self.cov_fro_before, self.cov_fro_after),
            "variance_ratio_ratio": ratio(self.variance_ratio_before, self.variance_ratio_after),
        }


def _moment_stats(src: np.ndarray, tgt: np.ndarray) -> Tuple[float, float, float]:
    mean_l2 = float(np.linalg.norm(src.mean(axis=0) - tgt.mean(axis=0)))
    src_c = src - src.mean(axis=0, keepdims=True)
    tgt_c = tgt - tgt.mean(axis=0, keepdims=True)
    cov_src = src_c.T @ src_c / max(1, src.shape[0] - 1)
    cov_tgt = tgt_c.T @ tgt_c / max(1, tgt.shape[0] - 1)
    cov_fro = float(np.linalg.norm(cov_src - cov_tgt) / max(1, cov_src.shape[0]))
    var_src = np.diag(cov_src)
    var_tgt = np.diag(cov_tgt)
    ratio = float(np.mean(np.abs(np.log((var_src + 1e-6) / (var_tgt + 1e-6)))))
    return mean_l2, cov_fro, ratio


def moment_report(
    src_acts: np.ndarray,
    tgt_acts: np.ndarray,
    align_fn=None,
) -> MomentReport:
    """First/second moment mismatch before and after the alignment map.

    ``align_fn`` maps ``[N, d] -> [N, d]`` (e.g. ``lambda z: aligner.transform(...)``);
    with ``align_fn=None`` the analytic diagonal map from the statistics is used.
    """
    src = np.asarray(src_acts, dtype=np.float64)
    tgt = np.asarray(tgt_acts, dtype=np.float64)
    mean_b, cov_b, ratio_b = _moment_stats(src, tgt)
    if align_fn is None:
        mu_src, sd_src = src.mean(axis=0), src.std(axis=0) + 1e-6
        mu_tgt, sd_tgt = tgt.mean(axis=0), tgt.std(axis=0)
        mapped = sd_tgt * (src - mu_src) / sd_src + mu_tgt
    else:
        mapped = np.asarray(align_fn(src), dtype=np.float64)
    mean_a, cov_a, ratio_a = _moment_stats(mapped, tgt)
    return MomentReport(
        mean_l2_before=mean_b,
        mean_l2_after=mean_a,
        cov_fro_before=cov_b,
        cov_fro_after=cov_a,
        variance_ratio_before=ratio_b,
        variance_ratio_after=ratio_a,
    )


def plot_moment_report(reports: Dict[str, MomentReport], out_path: str) -> str:
    """Bar chart of the moment mismatch before/after alignment."""
    plt = _plt()
    labels = list(reports.keys())
    metrics = ["mean_l2", "cov_fro"]
    before = {m: [getattr(reports[k], f"{m}_before") for k in labels] for m in metrics}
    after = {m: [getattr(reports[k], f"{m}_after") for k in labels] for m in metrics}
    fig, axes = plt.subplots(1, len(metrics), figsize=(4.2 * len(metrics), 3.8))
    if len(metrics) == 1:
        axes = [axes]
    x = np.arange(len(labels))
    for ax, metric in zip(axes, metrics):
        ax.bar(x - 0.2, before[metric], width=0.4, label="before")
        ax.bar(x + 0.2, after[metric], width=0.4, label="after")
        ax.set_yscale("log")
        ax.set_title(metric)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=7)
        ax.legend(frameon=False, fontsize=8)
        ax.grid(alpha=0.25, axis="y")
    fig.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    return out_path


# ---------------------------------------------------------------- full run
def summarize_run(run_dir: str, out_dir: Optional[str] = None) -> Dict[str, object]:
    """Collect manifest/solutions/episodes of a run and write figures + summary."""
    out_dir = out_dir or os.path.join(run_dir, "report")
    os.makedirs(out_dir, exist_ok=True)
    summary: Dict[str, object] = {"run_dir": run_dir, "figures": [], "subproblems": []}

    manifest_path = os.path.join(run_dir, "manifest.json")
    manifest = {}
    if os.path.isfile(manifest_path):
        with open(manifest_path, "r", encoding="utf-8") as fh:
            manifest = json.load(fh)
    summary["args"] = manifest.get("args", {})
    summary["tasks"] = manifest.get("tasks", [])

    for name in sorted(os.listdir(run_dir)):
        sub_dir = os.path.join(run_dir, name)
        if not name.startswith("pref_") or not os.path.isdir(sub_dir):
            continue
        episodes = load_episodes(os.path.join(sub_dir, "episodes.jsonl"))
        rewards = [float(ep.get("reward", float("nan"))) for ep in episodes]
        if rewards:
            path = plot_episode_rewards(
                {name: rewards},
                os.path.join(out_dir, f"{name}_reward.png"),
                title=f"{name}: episode reward",
            )
            summary["figures"].append(path)
        solution_path = os.path.join(sub_dir, "solution.json")
        if os.path.isfile(solution_path):
            with open(solution_path, "r", encoding="utf-8") as fh:
                solution = json.load(fh)
            summary["subproblems"].append(
                {
                    "name": name,
                    "best_reward": solution.get("best_reward"),
                    "best_source": solution.get("best_source"),
                    "path_length": solution.get("path_length"),
                    "scorer_calls": solution.get("scorer_calls"),
                    "best_scores": solution.get("best_scores"),
                }
            )

    pareto = manifest.get("pareto")
    if pareto and pareto.get("points"):
        tasks = pareto.get("tasks", [])
        try:
            path = plot_pareto(
                pareto["points"],
                tasks,
                os.path.join(out_dir, "pareto.png"),
                hv=pareto.get("hypervolume"),
            )
            summary["figures"].append(path)
        except Exception as exc:  # pragma: no cover - plotting is optional
            summary["pareto_error"] = str(exc)

    with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, ensure_ascii=False, indent=2)
    return summary
