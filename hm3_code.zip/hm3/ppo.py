"""Actor-critic / PPO training of the architecture-level search.

The objective follows the usual clipped-surrogate recipe:

* the discounted return is built from the per-step reward ``R_t``;
* the policy is updated with the clipped surrogate objective;
* the value network is trained on the returns;
* the total loss combines the clipped surrogate with a value-loss term and an
  entropy bonus;
* the action itself is drawn through the Wolpertinger mapping.

Implementation choices (documented deviations)
---------------------------------------------
1. The state is re-encoded with the GRU at every step instead of keeping an
   incremental hidden state.  Episodes are at most ``max_path_len`` (28) steps
   long, so the extra cost is negligible and the implementation cannot drift out
   of sync with the recorded trajectory.
2. The joint density that PPO differentiates is
   ``pi(z, A | S) = N(z; mu(S), sigma) * Cat(A | z, W*(z))``: the sampled
   proto-action ``z`` is stored at rollout time and reused during the update, so
   the actor's mean gets a well-defined gradient (see the note in
   ``wolpertinger.py``).
3. Rewards are assigned uniformly over the trajectory (``R_t = R / T``);
   ``reward_assignment='terminal'`` is available as an ablation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal

from .actions import ModelLayerPool, PathConstraints, decode_path, feasible_mask
from .env import LayerPathEnv
from .policy import ActorCritic
from .wolpertinger import WolpertingerMapper, q_proxy


@dataclass
class PPOConfig:
    gamma: float = 0.99
    lam: float = 0.95
    clip_ratio: float = 0.2
    lr: float = 3e-4
    update_epochs: int = 4
    minibatch_episodes: int = 8
    ent_coef: float = 0.01
    vf_coef: float = 0.5
    max_grad_norm: float = 1.0
    normalize_advantage: bool = True
    reward_assignment: str = "uniform"     # uniform | terminal
    eps_start: float = 1.0
    eps_end: float = 0.05
    eps_decay_iters: int = 50
    seed: int = 42
    align_loss_coef: float = 0.0
    target_kl: float = 0.0     # > 0 enables early stopping of the update epochs
    # --- prior replay (disclosed part of the "practical" recipe) ------------
    replay_ratio: float = 0.0        # share of prior episodes mixed into each update
    replay_value_coef: float = 1.0   # weight of the prior value-regression term
    replay_bc_coef: float = 0.0      # weight of the imitation term on prior actions

    def __post_init__(self) -> None:
        if self.reward_assignment not in {"uniform", "terminal"}:
            raise ValueError("reward_assignment must be 'uniform' or 'terminal'")


@dataclass
class Episode:
    actions: List[int]            # every action taken, including a final STOP
    path: List[int]               # the non-STOP actions, i.e. the path
    stopped: bool
    reward: float
    scores: Dict[str, float]
    z: np.ndarray                 # [T, D] proto-actions
    logp: np.ndarray              # [T]
    values: np.ndarray            # [T]
    eps: Optional[np.ndarray] = None   # [T] exploration rate used at rollout time
    source: str = "online"        # online | prior | bc
    adv: Optional[np.ndarray] = None
    ret: Optional[np.ndarray] = None

    @property
    def length(self) -> int:
        return len(self.actions)

    def as_dict(self) -> Dict[str, object]:
        return {
            "path": [int(a) for a in self.path],
            "length": len(self.path),
            "stopped": bool(self.stopped),
            "reward": float(self.reward),
            "scores": self.scores,
            "source": self.source,
        }


class PPOAgent:
    def __init__(
        self,
        net: ActorCritic,
        mapper: WolpertingerMapper,
        pool: ModelLayerPool,
        constraints: PathConstraints,
        cfg: PPOConfig,
        device: torch.device,
        extra_loss_fn: Optional[Callable[[], torch.Tensor]] = None,
    ) -> None:
        self.net = net.to(device)
        self.mapper = mapper.to(device)
        self.pool = pool
        self.constraints = constraints
        self.cfg = cfg
        self.device = device
        self.extra_loss_fn = extra_loss_fn
        params = list(self.net.parameters()) + list(self.mapper.parameters())
        self.opt = torch.optim.Adam(params, lr=cfg.lr)
        self.generator = torch.Generator(device=device).manual_seed(int(cfg.seed))
        self.rng = np.random.default_rng(int(cfg.seed))
        self.iteration = 0
        # Prior trajectories (K+1 pure-model paths) kept for replay.  This is an
        # explicit, disclosable part of the practical recipe: they are logged to
        # ``prior_dump.jsonl`` and summarised in ``solution.json``/``manifest.json``.
        self.replay_episodes: List[Episode] = []

    def set_prior_replay(self, episodes: Sequence[Episode]) -> None:
        """Install the K+1 pure-model trajectories used for replay."""
        self.replay_episodes = [ep for ep in episodes if len(ep.actions) > 0]
        for ep in self.replay_episodes:
            ep.source = "prior"
            # the terminal reward is assigned uniformly to every step.
            rewards = self.per_step_rewards(ep)
            ep.ret = np.cumsum(rewards[::-1])[::-1].astype(np.float32)
            ep.adv = np.zeros_like(ep.ret)

    def _sample_replay(self, batch_size: int) -> List[Episode]:
        if not self.replay_episodes or batch_size <= 0:
            return []
        idx = self.rng.integers(0, len(self.replay_episodes), size=int(batch_size))
        return [self.replay_episodes[int(i)] for i in idx]

    def _imitation_loss(self, episodes: Sequence[Episode]) -> torch.Tensor:
        """Mean ``-log pi(a_t | s_t)`` of the given trajectories (BC / replay BC)."""
        total = torch.zeros((), device=self.device)
        count = 0
        for ep in episodes:
            actions = ep.actions
            T = len(actions)
            prefix = actions[:-1]
            if prefix:
                pairs = [decode_path([a], self.pool.max_layers)[0] for a in prefix]
                model_idx = torch.tensor([p[0] for p in pairs], dtype=torch.long, device=self.device)
                layer_idx = torch.tensor([p[1] for p in pairs], dtype=torch.long, device=self.device)
                tokens = self.net.token_for(model_idx, layer_idx).unsqueeze(0)
                out, _ = self.net.encode_sequence(tokens)
                initial = self.net.initial_hidden(1, self.device)[-1]
                hidden_states = torch.cat([initial, out[0]], dim=0)
            else:
                hidden_states = self.net.initial_hidden(1, self.device)[-1]
            z = self.net.distribution(hidden_states).mean          # [T, D]
            for t in range(T):
                mask = feasible_mask(self.pool, actions[:t], self.constraints)
                mask_t = self._mask_tensor(mask)
                z_t = z[t : t + 1]
                dist, cand_idx, _ = self.mapper.local_policy(z_t, mask_t, None)
                local = self.mapper.local_index_of(
                    cand_idx, torch.tensor([int(actions[t])], device=self.device)
                )
                if bool((local >= cand_idx.shape[1]).any()):
                    # reference action outside the current neighbourhood: pin it to
                    # the last slot so the gradient still pulls the mean towards it
                    logits = torch.full_like(dist.logits, -1e9)
                    logits[:, -1] = 0.0
                    dist = torch.distributions.Categorical(logits=logits)
                    local = torch.full_like(local, cand_idx.shape[1] - 1)
                total = total - dist.log_prob(local).mean()
                count += 1
        return total / max(1, count)

    # ------------------------------------------------------------------ utils
    def epsilon(self) -> float:
        cfg = self.cfg
        if cfg.eps_decay_iters <= 0:
            return float(cfg.eps_end)
        frac = min(1.0, float(self.iteration) / float(cfg.eps_decay_iters))
        return float(cfg.eps_start + frac * (cfg.eps_end - cfg.eps_start))

    def _mask_tensor(self, mask: np.ndarray) -> torch.Tensor:
        return torch.as_tensor(mask, dtype=torch.bool, device=self.device).unsqueeze(0)

    def _prefix_hidden(self, actions: Sequence[int]) -> Tuple[torch.Tensor, torch.Tensor]:
        """Hidden state after consuming ``actions`` (trajectory tokens).

        Returns ``(hidden_out [1, H], hidden_seq [L, 1, H])``.
        """
        if len(actions) == 0:
            hidden = self.net.initial_hidden(1, self.device)
            return hidden[-1], hidden
        pairs = [decode_path([a], self.pool.max_layers)[0] for a in actions]
        model_idx = torch.tensor([p[0] for p in pairs], dtype=torch.long, device=self.device)
        layer_idx = torch.tensor([p[1] for p in pairs], dtype=torch.long, device=self.device)
        tokens = self.net.token_for(model_idx, layer_idx).unsqueeze(0)
        out, hidden = self.net.encode_sequence(tokens)
        return out[:, -1, :], hidden

    def _q_values(
        self, hidden_last: torch.Tensor, cand_idx: torch.Tensor, terminal_reward: float = 0.0
    ) -> torch.Tensor:
        """One-step proxy ``Q~(S, A) = r + gamma V(S')`` for a neighbourhood.

        Each neighbour is evaluated as an independent one-step lookahead from the
        same hidden state (batch of ``k`` length-1 sequences).  The STOP action has
        no successor state, so its proxy is set to 0 (neutral): the terminal reward
        is not known before the path is scored.
        """
        k = int(cand_idx.shape[1])
        if hidden_last.dim() == 1:
            hidden_last = hidden_last.unsqueeze(0)
        num_pairs = self.pool.num_models * self.pool.max_layers
        is_stop = cand_idx >= num_pairs
        safe_idx = torch.where(is_stop, torch.zeros_like(cand_idx), cand_idx)
        pairs = [decode_path([int(a)], self.pool.max_layers)[0] for a in safe_idx[0].tolist()]
        model_idx = torch.tensor([p[0] for p in pairs], dtype=torch.long, device=self.device)
        layer_idx = torch.tensor([p[1] for p in pairs], dtype=torch.long, device=self.device)
        tokens = self.net.token_for(model_idx, layer_idx).unsqueeze(1)   # [k, 1, 3d]
        hidden = (
            hidden_last.unsqueeze(0)
            .expand(self.net.cfg.gru_layers, k, -1)
            .contiguous()
        )                                                               # [L, k, H]
        out, _ = self.net.encode_sequence(tokens, hidden)               # [k, 1, H]
        next_values = self.net.value(out[:, 0, :])                      # [k]
        next_values = torch.where(
            is_stop[0], torch.zeros_like(next_values), next_values
        )
        reward = torch.full_like(next_values, float(terminal_reward))
        return q_proxy(next_values, reward, self.cfg.gamma).unsqueeze(0)  # [1, k]

    def _local_logp(
        self,
        z: torch.Tensor,
        action: int,
        mask: np.ndarray,
        terminal_reward: float = 0.0,
        eps: float = 0.0,
    ):
        mask_t = self._mask_tensor(mask)
        cand_idx, _, _, _ = self.mapper.neighbours(z, mask_t)
        q_values = self._q_values(self._hidden_last, cand_idx, terminal_reward)
        logp, entropy, cand_idx = self.mapper.log_prob(
            z, torch.tensor([int(action)], device=self.device), mask_t, q_values, return_entropy=True
        )
        if eps > 0:
            # the exploration branch samples uniformly from the neighbourhood with probability
            # eps, so the behaviour policy is the mixture
            #   pi_bar(a) = (1 - eps) * pi_loc(a) + eps / |W*(A_bar)|
            # and the PPO ratio has to use the same mixture.  Otherwise the
            # stored log-prob is inconsistent with how the action was drawn and
            # the first update gets a huge importance ratio.
            k = cand_idx.shape[1]
            log_uniform = -float(np.log(max(1, k)))
            logp = torch.logaddexp(
                logp + float(np.log(max(1e-8, 1.0 - eps))),
                torch.full_like(logp, log_uniform + float(np.log(max(1e-8, eps)))),
            )
        return logp, entropy, cand_idx

    # ------------------------------------------------------------------ acting
    @torch.no_grad()
    def act(self, obs: Dict[str, object], greedy: bool = False):
        path = list(obs["path"])
        hidden_last, _ = self._prefix_hidden(path)
        dist = self.net.distribution(hidden_last)
        value = float(self.net.value(hidden_last).item())
        if greedy:
            z = dist.mean
        else:
            z = dist.rsample()
        self._hidden_last = hidden_last
        mask = np.asarray(obs["mask"], dtype=bool)
        mask_t = self._mask_tensor(mask)
        cand_idx, _, _, _ = self.mapper.neighbours(z, mask_t)
        q_values = self._q_values(hidden_last, cand_idx)

        if greedy:
            action = int(self.mapper.greedy(z, mask_t, q_values).item())
            logp = 0.0
            used_eps = 0.0
        else:
            eps = self.epsilon()
            used_eps = float(eps)
            explored = eps > 0 and float(
                torch.rand(1, generator=self.generator, device=self.device).item()
            ) < eps
            if explored:
                action = int(self.mapper.uniform_in_neighbourhood(z, mask_t, self.generator).item())
            else:
                dist_loc, cand_idx, _ = self.mapper.local_policy(z, mask_t, q_values)
                local = dist_loc.sample()
                action = int(cand_idx.gather(1, local.view(-1, 1)).item())
            logp_local, _, _ = self._local_logp(
                z, action, mask, terminal_reward=0.0, eps=float(eps)
            )
            logp = float(dist.log_prob(z).sum().item() + logp_local.sum().item())
        return action, logp, value, z[0].detach().cpu().numpy(), used_eps

    @torch.no_grad()
    def collect_episodes(self, env: LayerPathEnv, n_episodes: int) -> List[Episode]:
        episodes: List[Episode] = []
        for _ in range(int(n_episodes)):
            obs = env.reset()
            actions: List[int] = []
            zs: List[np.ndarray] = []
            logps: List[float] = []
            values: List[float] = []
            epss: List[float] = []
            done = False
            info = None
            while not done:
                action, logp, value, z, eps = self.act(obs)
                obs, reward, done, info = env.step(action)
                actions.append(int(action))
                zs.append(z)
                logps.append(float(logp))
                values.append(float(value))
                epss.append(float(eps))
            stopped = bool(self.pool.is_stop(actions[-1])) if actions else False
            path = [a for a in actions if not self.pool.is_stop(a)]
            episodes.append(
                Episode(
                    actions=actions,
                    path=path,
                    stopped=stopped,
                    reward=float(info.reward),
                    scores=dict(info.scores),
                    z=np.asarray(zs, dtype=np.float32),
                    logp=np.asarray(logps, dtype=np.float32),
                    values=np.asarray(values, dtype=np.float32),
                    eps=np.asarray(epss, dtype=np.float32),
                )
            )
        self.iteration += 1
        return episodes

    @torch.no_grad()
    def greedy_rollout(self, env: LayerPathEnv) -> Episode:
        """Deterministic evaluation rollout: argmax-Q mapping."""
        obs = env.reset()
        actions: List[int] = []
        zs: List[np.ndarray] = []
        logps: List[float] = []
        values: List[float] = []
        done = False
        info = None
        epss: List[float] = []
        while not done:
            action, logp, value, z, eps = self.act(obs, greedy=True)
            obs, reward, done, info = env.step(action)
            actions.append(int(action))
            zs.append(z)
            logps.append(float(logp))
            values.append(float(value))
            epss.append(float(eps))
        stopped = bool(self.pool.is_stop(actions[-1])) if actions else False
        path = [a for a in actions if not self.pool.is_stop(a)]
        return Episode(
            actions=actions,
            path=path,
            stopped=stopped,
            reward=float(info.reward),
            scores=dict(info.scores),
            z=np.asarray(zs, dtype=np.float32),
            logp=np.asarray(logps, dtype=np.float32),
            values=np.asarray(values, dtype=np.float32),
            eps=np.asarray(epss, dtype=np.float32),
            source="greedy",
        )

    # ------------------------------------------------------------------- gae
    def per_step_rewards(self, episode: Episode) -> np.ndarray:
        T = episode.length
        if T == 0:
            return np.zeros(0, dtype=np.float32)
        if self.cfg.reward_assignment == "uniform":
            return np.full(T, episode.reward / float(T), dtype=np.float32)
        out = np.zeros(T, dtype=np.float32)
        out[-1] = episode.reward
        return out

    def compute_gae(self, episodes: Sequence[Episode]) -> None:
        gamma, lam = float(self.cfg.gamma), float(self.cfg.lam)
        for ep in episodes:
            rewards = self.per_step_rewards(ep)
            values = np.concatenate([ep.values, np.zeros(1, dtype=np.float32)])
            adv = np.zeros_like(rewards)
            gae = 0.0
            for t in reversed(range(len(rewards))):
                delta = rewards[t] + gamma * values[t + 1] - values[t]
                gae = delta + gamma * lam * gae
                adv[t] = gae
            ep.adv = adv
            ep.ret = adv + ep.values

    # ---------------------------------------------------------------- update
    def evaluate_episode(self, ep: Episode) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Recompute log-prob, value and entropy of the stored decisions."""
        actions = ep.actions
        T = len(actions)
        if T == 0:
            zero = torch.zeros((), device=self.device)
            return zero, zero, zero
        prefix = actions[:-1]
        if prefix:
            pairs = [decode_path([a], self.pool.max_layers)[0] for a in prefix]
            model_idx = torch.tensor([p[0] for p in pairs], dtype=torch.long, device=self.device)
            layer_idx = torch.tensor([p[1] for p in pairs], dtype=torch.long, device=self.device)
            tokens = self.net.token_for(model_idx, layer_idx).unsqueeze(0)
            out, _ = self.net.encode_sequence(tokens)
            # state at step t is the hidden state *after* consuming the first t
            # actions: prepend the initial state so that row t matches step t.
            initial = self.net.initial_hidden(1, self.device)[-1]
            hidden_states = torch.cat([initial, out[0]], dim=0)
        else:
            hidden_states = self.net.initial_hidden(1, self.device)[-1]
        if hidden_states.shape[0] != T:
            raise RuntimeError(
                f"trajectory encoding produced {hidden_states.shape[0]} states for {T} decisions"
            )

        dist = self.net.distribution(hidden_states)
        values = self.net.value(hidden_states)
        z = torch.as_tensor(ep.z[:T], dtype=torch.float32, device=self.device)
        logp = dist.log_prob(z).sum(dim=-1)
        entropy = dist.entropy().sum(dim=-1)

        for t in range(T):
            mask = feasible_mask(self.pool, actions[:t], self.constraints)
            terminal_reward = ep.reward if t == T - 1 else 0.0
            z_b = z[t : t + 1]
            self._hidden_last = hidden_states[t : t + 1]
            eps_t = float(ep.eps[t]) if ep.eps is not None and t < len(ep.eps) else 0.0
            logp_local, entropy_local, _ = self._local_logp(
                z_b, int(actions[t]), mask, terminal_reward=terminal_reward, eps=eps_t
            )
            logp[t] = logp[t] + logp_local.squeeze(0)
            entropy[t] = entropy[t] + entropy_local.squeeze(0)
        return logp, values, entropy

    def update(self, episodes: Sequence[Episode]) -> Dict[str, float]:
        cfg = self.cfg
        episodes = list(episodes)
        if not episodes:
            return {"policy_loss": 0.0, "value_loss": 0.0, "entropy": 0.0, "total_loss": 0.0, "approx_kl": 0.0}

        adv_all = np.concatenate([ep.adv for ep in episodes])
        if cfg.normalize_advantage and adv_all.size > 1:
            mu, sd = float(adv_all.mean()), float(adv_all.std() + 1e-8)
        else:
            mu, sd = 0.0, 1.0

        stats = {"policy_loss": 0.0, "value_loss": 0.0, "entropy": 0.0, "total_loss": 0.0, "approx_kl": 0.0}
        num_batches = 0
        order = np.arange(len(episodes))
        stop_early = False
        for _ in range(int(cfg.update_epochs)):
            if stop_early:
                break
            self.rng.shuffle(order)
            for start in range(0, len(order), int(cfg.minibatch_episodes)):
                batch = [episodes[i] for i in order[start : start + int(cfg.minibatch_episodes)]]
                self.opt.zero_grad(set_to_none=True)
                total = None
                for ep in batch:
                    logp_new, values, entropy = self.evaluate_episode(ep)
                    adv = torch.as_tensor((ep.adv - mu) / sd, dtype=torch.float32, device=self.device)
                    ret = torch.as_tensor(ep.ret, dtype=torch.float32, device=self.device)
                    old_logp = torch.as_tensor(ep.logp, dtype=torch.float32, device=self.device)
                    ratio = torch.exp(logp_new - old_logp)
                    surr1 = ratio * adv
                    surr2 = torch.clamp(ratio, 1.0 - cfg.clip_ratio, 1.0 + cfg.clip_ratio) * adv
                    policy_loss = -torch.min(surr1, surr2).mean()
                    value_loss = F.mse_loss(values, ret)
                    entropy_mean = entropy.mean()
                    loss = policy_loss + cfg.vf_coef * value_loss - cfg.ent_coef * entropy_mean
                    total = loss if total is None else total + loss
                    with torch.no_grad():
                        approx_kl = float((old_logp - logp_new).mean().item())
                    stats["policy_loss"] += float(policy_loss.item())
                    stats["value_loss"] += float(value_loss.item())
                    stats["entropy"] += float(entropy_mean.item())
                    stats["approx_kl"] += approx_kl
                if total is None:
                    continue
                # ---- prior replay: value regression (+ optional imitation) -----
                # The K+1 pure-model trajectories are replayed here.  They are
                # logged (``prior_dump.jsonl`` / ``solution.json``), so this is a
                # disclosed part of the practical recipe, not a hidden trick.
                if self.replay_episodes and cfg.replay_ratio > 0:
                    ratio = float(cfg.replay_ratio)
                    if ratio >= 1.0:
                        n_prior = len(self.replay_episodes)
                    else:
                        n_prior = int(round(len(batch) * ratio / max(1e-8, 1.0 - ratio)))
                    prior_batch = self._sample_replay(max(1, n_prior))
                    if prior_batch:
                        value_losses = []
                        for ep in prior_batch:
                            _, values_p, _ = self.evaluate_episode(ep)
                            ret_p = torch.as_tensor(ep.ret, dtype=torch.float32, device=self.device)
                            value_losses.append(F.mse_loss(values_p, ret_p))
                        replay_value_loss = torch.stack(value_losses).mean()
                        total = total + cfg.replay_value_coef * replay_value_loss
                        stats["replay_value_loss"] = stats.get("replay_value_loss", 0.0) + float(
                            replay_value_loss.item()
                        )
                        if cfg.replay_bc_coef > 0:
                            bc_loss = self._imitation_loss(prior_batch)
                            total = total + cfg.replay_bc_coef * bc_loss
                            stats["replay_bc_loss"] = stats.get("replay_bc_loss", 0.0) + float(
                                bc_loss.item()
                            )
                        stats["n_replay"] = stats.get("n_replay", 0.0) + float(len(prior_batch))
                if self.extra_loss_fn is not None and cfg.align_loss_coef > 0:
                    extra = self.extra_loss_fn()
                    total = total + cfg.align_loss_coef * extra
                    stats.setdefault("align_loss", 0.0)
                    stats["align_loss"] += float(extra.item())
                total.backward()
                nn.utils.clip_grad_norm_(
                    list(self.net.parameters()) + list(self.mapper.parameters()), cfg.max_grad_norm
                )
                self.opt.step()
                stats["total_loss"] += float(total.item())
                num_batches += 1
                if cfg.target_kl > 0 and num_batches > 0:
                    mean_kl = stats["approx_kl"] / max(1, num_batches * int(cfg.minibatch_episodes))
                    if mean_kl > 1.5 * float(cfg.target_kl):
                        stop_early = True
                        break

        denom = max(1, num_batches * int(cfg.minibatch_episodes))
        out = {k: v / denom for k, v in stats.items() if k != "n_replay"}
        if "n_replay" in stats:          # keep the raw count, not an average
            out["n_replay"] = stats["n_replay"]
        return out

    def state_dict(self) -> Dict[str, object]:
        return {
            "net": self.net.state_dict(),
            "mapper": self.mapper.state_dict(),
            "opt": self.opt.state_dict(),
            "iteration": self.iteration,
        }

    def save(self, path: str) -> None:
        torch.save(self.state_dict(), path)

    # ------------------------------------------------- behaviour cloning (A8)
    def behavior_clone(
        self,
        episodes: Sequence[Episode],
        epochs: int = 50,
        lr: Optional[float] = None,
        use_embedding_logits: bool = True,
    ) -> Dict[str, float]:
        """Imitate a set of reference trajectories (the ``practical`` train mode).

        Only the actor is trained: the proto-action mean is pulled towards the
        neighbourhood of the reference actions, so the stochastic policy starts
        from a region that already contains a good path.  It is off by default; it
        exists so that "prior + BC" and pure online PPO can be compared on the same
        code base.
        """
        episodes = [ep for ep in episodes if len(ep.actions) > 0]
        if not episodes or epochs <= 0:
            return {"bc_loss": 0.0, "bc_entropy": 0.0, "epochs": 0}
        opt = torch.optim.Adam(self.net.parameters(), lr=float(lr or self.cfg.lr))
        last_loss = 0.0
        last_entropy = 0.0
        for _ in range(int(epochs)):
            opt.zero_grad(set_to_none=True)
            loss = self._imitation_loss(episodes)
            loss.backward()
            nn.utils.clip_grad_norm_(self.net.parameters(), self.cfg.max_grad_norm)
            opt.step()
            last_loss = float(loss.item())
        return {"bc_loss": last_loss, "bc_entropy": last_entropy, "epochs": int(epochs)}
