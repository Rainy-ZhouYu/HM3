"""Trajectory-encoded actor-critic network.

* state: the full trajectory -- encoders ``psi_m`` (model identity), ``psi_l``
  (layer index) and ``phi`` (layer parameters), read by a GRU;
* policy: a Gaussian proto-action ``A_bar = f_pi(S) ~ N(mu(S), diag sigma^2(S))``.

The state keeps the whole trajectory: a stateless per-candidate scorer would lose
the history that the sequential-decision formulation relies on.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import torch
import torch.nn as nn
from torch.distributions import Normal


@dataclass
class PolicyConfig:
    num_models: int
    max_layers: int
    signature_dim: int
    hidden_dim: int = 128
    token_dim: int = 64
    action_dim: int = 64
    gru_layers: int = 1
    min_log_std: float = -4.0
    max_log_std: float = 0.0


class ActorCritic(nn.Module):
    """psi_m + psi_l + phi -> token, GRU over tokens, Gaussian proto-action + V."""

    def __init__(self, cfg: PolicyConfig) -> None:
        super().__init__()
        self.cfg = cfg
        d = cfg.token_dim
        self.psi_m = nn.Embedding(cfg.num_models, d)
        self.psi_l = nn.Embedding(cfg.max_layers, d)
        self.phi = nn.Sequential(
            nn.Linear(cfg.signature_dim, d),
            nn.GELU(),
            nn.Linear(d, d),
        )
        self.register_buffer(
            "signature_table",
            # +1 row for the STOP action (unused as a state token, kept so the
            # table layout matches hm3.signatures.build_signature_table).
            torch.zeros(cfg.num_models * cfg.max_layers + 1, cfg.signature_dim),
        )
        self.gru = nn.GRU(
            input_size=3 * d,
            hidden_size=cfg.hidden_dim,
            num_layers=cfg.gru_layers,
            batch_first=True,
        )
        self.actor_mu = nn.Sequential(
            nn.Linear(cfg.hidden_dim, cfg.hidden_dim),
            nn.Tanh(),
            nn.Linear(cfg.hidden_dim, cfg.action_dim),
        )
        self.log_std = nn.Parameter(torch.full((cfg.action_dim,), -1.0))
        self.value_head = nn.Sequential(
            nn.Linear(cfg.hidden_dim, cfg.hidden_dim),
            nn.ReLU(),
            nn.Linear(cfg.hidden_dim, 1),
        )
        self._init_weights()

    def _init_weights(self) -> None:
        for module in (self.psi_m, self.psi_l):
            nn.init.normal_(module.weight, std=0.02)
        for layer in self.phi:
            if isinstance(layer, nn.Linear):
                nn.init.orthogonal_(layer.weight, gain=1.0)
                nn.init.zeros_(layer.bias)
        nn.init.orthogonal_(self.actor_mu[-1].weight, gain=0.01)
        nn.init.zeros_(self.actor_mu[-1].bias)
        nn.init.orthogonal_(self.value_head[-1].weight, gain=1.0)
        nn.init.zeros_(self.value_head[-1].bias)

    # ------------------------------------------------------------------ setup
    def set_signature_table(self, table) -> None:
        """Install the pre-computed layer sketches (numpy array or tensor)."""
        table = torch.as_tensor(table, dtype=self.signature_table.dtype)
        if table.shape != self.signature_table.shape:
            raise ValueError(
                f"signature table shape {tuple(table.shape)} != expected "
                f"{tuple(self.signature_table.shape)}"
            )
        with torch.no_grad():
            self.signature_table.copy_(table)

    # ------------------------------------------------------------------ pieces
    def token_for(self, model_idx: torch.Tensor, layer_idx: torch.Tensor) -> torch.Tensor:
        """[B] x [B] -> [B, 3 * token_dim] trajectory token."""
        flat = model_idx * self.cfg.max_layers + layer_idx
        sig = self.signature_table[flat]
        return torch.cat([self.psi_m(model_idx), self.psi_l(layer_idx), self.phi(sig)], dim=-1)

    def initial_hidden(self, batch_size: int, device: torch.device) -> torch.Tensor:
        return torch.zeros(
            self.cfg.gru_layers, batch_size, self.cfg.hidden_dim, device=device
        )

    def step(
        self,
        hidden: torch.Tensor,
        model_idx: torch.Tensor,
        layer_idx: torch.Tensor,
        token: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """One GRU step. ``hidden``: [L, B, H] -> ([B, H], [L, B, H])."""
        if token is None:
            token = self.token_for(model_idx, layer_idx)
        out, hidden_next = self.gru(token.unsqueeze(1), hidden)
        return out[:, 0, :], hidden_next

    def encode_sequence(self, tokens: torch.Tensor, hidden: Optional[torch.Tensor] = None):
        """tokens: [B, T, 3d] -> hidden_states [B, T, H], final hidden."""
        out, hidden_next = self.gru(tokens, hidden)
        return out, hidden_next

    def value(self, hidden_state: torch.Tensor) -> torch.Tensor:
        return self.value_head(hidden_state).squeeze(-1)

    def distribution(self, hidden_state: torch.Tensor) -> Normal:
        mu = self.actor_mu(hidden_state)
        log_std = torch.clamp(self.log_std, self.cfg.min_log_std, self.cfg.max_log_std)
        return Normal(mu, log_std.exp().expand_as(mu))

    def forward_step(self, hidden, model_idx, layer_idx, token=None):
        hidden_state, hidden_next = self.step(hidden, model_idx, layer_idx, token)
        return self.distribution(hidden_state), self.value(hidden_state), hidden_next

    def count_parameters(self) -> int:
        return int(sum(p.numel() for p in self.parameters()))
