"""Multi-objective bookkeeping: dominance, Pareto front, hypervolume.

* Pareto dominance is computed by pooling all candidate solutions;
* the hypervolume (HV) of the approximate Pareto set is reported next to it;
* the ideal point ``z*_k = max f_k`` is estimated from the fine-tuned candidates
  (:func:`ideal_point_from_scores`).

Everything in this module is numpy-only on purpose, so the multi-objective
bookkeeping can be unit tested without a GPU.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np


def as_matrix(points: Iterable[Sequence[float]]) -> np.ndarray:
    arr = np.asarray([list(map(float, p)) for p in points], dtype=float)
    if arr.ndim != 2:
        raise ValueError("points must be a 2-D array (n_solutions, n_objectives)")
    return arr


def pareto_dominates(a: Sequence[float], b: Sequence[float], tol: float = 0.0) -> bool:
    """Maximisation dominance: ``a`` is no worse everywhere and better somewhere."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if np.any(a < b - tol):
        return False
    return bool(np.any(a > b + tol))


def dominance_matrix(points: Iterable[Sequence[float]], tol: float = 0.0) -> np.ndarray:
    """``D[i, j] = True`` iff solution ``i`` dominates solution ``j``."""
    pts = as_matrix(points)
    n = pts.shape[0]
    d = np.zeros((n, n), dtype=bool)
    for i in range(n):
        for j in range(n):
            if i != j:
                d[i, j] = pareto_dominates(pts[i], pts[j], tol)
    return d


def pareto_front_indices(points: Iterable[Sequence[float]], tol: float = 0.0) -> List[int]:
    """Indices of the non-dominated solutions."""
    d = dominance_matrix(points, tol)
    dominated = d.any(axis=0)
    return [int(i) for i in np.nonzero(~dominated)[0]]


def pareto_front(points: Iterable[Sequence[float]], tol: float = 0.0) -> np.ndarray:
    pts = as_matrix(points)
    return pts[pareto_front_indices(pts, tol)]


def hypervolume_max(points: Iterable[Sequence[float]], reference: Sequence[float]) -> float:
    """Exact hypervolume for maximisation problems.

    ``hypervolume([[3, 1], [1, 3]], reference=[0, 0]) == 5.0``

    The implementation is the classic slicing recursion: sort the points by the
    first objective, cut the space into slabs at those coordinates and recurse on
    the remaining objectives.  It is exact for any number of objectives and is
    fast enough for typical solution-set sizes (tens of solutions).
    """
    pts = [tuple(float(x) for x in p) for p in points]
    ref = tuple(float(x) for x in reference)
    if not pts:
        return 0.0
    if len(ref) == 1:
        best = max(p[0] for p in pts)
        return max(0.0, best - ref[0])
    pts = sorted(set(pts), key=lambda p: p[0], reverse=True)
    volume = 0.0
    for idx, point in enumerate(pts):
        upper = point[0]
        lower = pts[idx + 1][0] if idx + 1 < len(pts) else ref[0]
        width = upper - lower
        if width <= 0:
            continue
        subs = [p[1:] for p in pts[: idx + 1]]
        volume += width * hypervolume_max(subs, ref[1:])
    return float(volume)


def reference_point(
    points: Iterable[Sequence[float]],
    margin: float = 0.0,
    floor: Optional[Sequence[float]] = None,
) -> np.ndarray:
    """Worst corner used as HV reference point (maximisation)."""
    pts = as_matrix(points)
    ref = pts.min(axis=0) - float(margin)
    if floor is not None:
        ref = np.minimum(ref, np.asarray(floor, dtype=float))
    return ref


def ideal_point_from_scores(
    scores_by_model: Mapping[str, Mapping[str, float]],
    tasks: Sequence[str],
) -> Dict[str, float]:
    """z*_k = best observed value of objective k across candidates."""
    ideal: Dict[str, float] = {}
    for task in tasks:
        values = [
            float(row[task])
            for row in scores_by_model.values()
            if row is not None and row.get(task) is not None
        ]
        if not values:
            raise ValueError(f"no candidate provides a score for task {task!r}")
        ideal[str(task)] = float(np.max(values))
    return ideal


@dataclass
class ParetoReport:
    indices: List[int]
    dominated: List[int]
    hypervolume: float
    reference: List[float]

    def as_dict(self) -> Dict[str, object]:
        return {
            "pareto_indices": list(self.indices),
            "dominated_indices": list(self.dominated),
            "hypervolume": float(self.hypervolume),
            "reference_point": list(self.reference),
        }


def pareto_report(points: Iterable[Sequence[float]], margin: float = 0.0) -> ParetoReport:
    pts = as_matrix(points)
    idx = pareto_front_indices(pts)
    ref = reference_point(pts, margin=margin)
    hv = hypervolume_max(pts[idx], ref)
    dominated = [i for i in range(pts.shape[0]) if i not in set(idx)]
    return ParetoReport(idx, dominated, hv, ref.tolist())
