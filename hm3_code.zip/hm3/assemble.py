"""Materialise a merged model from an inference path.

The architecture level selects a sequence of (model, layer) pairs; the merged
model is the sequence of the selected blocks, so its depth equals the path
length, and the alignment layer is applied at the junctions returned by
:func:`hm3.actions.alignment_sites`.
"""

from __future__ import annotations

import copy
import json
import os
from typing import Dict, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn

from .actions import ModelLayerPool, decode_path, alignment_sites
from .alignment import AlignmentMLP, AlignmentWrapper


def find_layer_module(model) -> nn.ModuleList:
    """Locate the decoder-layer ``ModuleList`` across HF architectures."""
    candidates = (
        ("model", "layers"),
        ("transformer", "h"),
        ("model", "decoder", "layers"),
        ("model", "layers"),
    )
    for path in candidates:
        obj = model
        for attr in path:
            obj = getattr(obj, attr, None)
            if obj is None:
                break
        if isinstance(obj, nn.ModuleList):
            return obj
    raise AttributeError("could not locate the decoder layer list on this model")


def set_layer_module(model, layers: nn.ModuleList) -> None:
    for path in (("model", "layers"), ("transformer", "h"), ("model", "decoder", "layers")):
        obj = model
        ok = True
        for attr in path[:-1]:
            obj = getattr(obj, attr, None)
            if obj is None:
                ok = False
                break
        if ok and isinstance(getattr(obj, path[-1], None), nn.ModuleList):
            setattr(obj, path[-1], layers)
            return
    raise AttributeError("could not set the decoder layer list on this model")


def set_attention_implementation(model, implementation: str, use_cache: bool = False) -> int:
    """Force the attention backend / cache flag on every submodule with a config.

    The decoder layers copied from the candidate models keep a reference to
    *their* config object, so setting the flag only on the top-level config has
    no effect.  Returns the number of configs updated.

    ``use_cache=False`` matters for generation-based tasks (GSM8K, MBPP, ...):
    a model assembled from layers of *different* checkpoints reuses one shared
    ``DynamicCache``, and the cached length then disagrees with the causal mask
    built for the current step (``size of tensor a (1534) must match tensor b
    (767)``).  Disabling the cache costs time but removes that failure mode.
    """
    if not implementation:
        implementation = ""
    updated = 0
    seen = set()
    for module in model.modules():
        cfg = getattr(module, "config", None)
        if cfg is None or id(cfg) in seen:
            continue
        seen.add(id(cfg))
        try:
            if implementation:
                cfg._attn_implementation = implementation
            cfg.use_cache = bool(use_cache)
            updated += 1
        except Exception:  # pragma: no cover - read-only configs
            continue
    return updated


def build_merged_model(
    models: Sequence,
    pool: ModelLayerPool,
    path: Sequence[int],
    alignment: Optional[AlignmentMLP] = None,
    alignment_mode: str = "always",
    attn_implementation: str = "eager",
    use_cache: bool = False,
):
    """Return a model whose depth equals ``len(path)``.

    ``models[0]`` provides the template (embeddings, final norm, lm_head, rope);
    every position is then replaced by the block selected in the path.

    ``attn_implementation`` defaults to ``eager``: on CUDA the SDPA kernel of
    recent torch builds rejects the expanded (non-contiguous) causal mask that
    transformers constructs when a padded batch is evaluated, which surfaces as
    ``(*bias): last dimension must be contiguous``.  Score-setup cost is
    dominated by dataset loading, so eager attention costs little in practice.
    """
    pairs = decode_path(path, pool.max_layers)
    if not pairs:
        raise ValueError("empty path")
    template = copy.deepcopy(models[0]).cpu()
    template.eval()
    targets = find_layer_module(template)
    sites = set(alignment_sites(path, pool, alignment_mode)) if alignment is not None else set()

    new_layers: List[nn.Module] = []
    for t, (m, l) in enumerate(pairs):
        block = copy.deepcopy(find_layer_module(models[int(m)])[int(l)]).cpu()
        if alignment is not None and t in sites:
            prev_m, prev_l = pairs[t - 1]
            block = AlignmentWrapper(
                block=block,
                # NOTE: every wrapper gets its own copy of the alignment map.
                # Sharing one module across all sites makes ``save_pretrained``
                # fail ("weights ... contained shared tensors"), and each
                # junction has its own (m, l) statistics anyway.
                aligner=copy.deepcopy(alignment),
                src_model=int(prev_m),
                src_layer=int(prev_l),
                dst_model=int(m),
                dst_layer=int(l),
                step=t,
            )
        new_layers.append(block)
    set_layer_module(template, nn.ModuleList(new_layers))
    template.config.num_hidden_layers = len(new_layers)
    inner = getattr(template, "model", None)
    if inner is not None and getattr(inner, "config", None) is not None:
        inner.config.num_hidden_layers = len(new_layers)
    set_attention_implementation(template, attn_implementation, use_cache=use_cache)
    # ``generate`` reads ``generation_config.use_cache`` (a separate object that
    # was copied together with the template), so the flag has to be forced there
    # as well, otherwise the KV cache is still used during generation.
    gen_cfg = getattr(template, "generation_config", None)
    if gen_cfg is not None:
        try:
            gen_cfg.use_cache = bool(use_cache)
        except Exception:  # pragma: no cover
            pass
    return template


def save_merged_model(
    model,
    out_dir: str,
    tokenizer=None,
    path: Optional[Sequence[int]] = None,
    pool: Optional[ModelLayerPool] = None,
    dtype: Optional[torch.dtype] = torch.float16,
) -> str:
    os.makedirs(out_dir, exist_ok=True)
    if dtype is not None:
        model = model.to(dtype)
    model.save_pretrained(out_dir)
    if tokenizer is not None:
        tokenizer.save_pretrained(out_dir)
    if path is not None:
        with open(os.path.join(out_dir, "path.json"), "w", encoding="utf-8") as fh:
            json.dump(
                {
                    "path": [int(a) for a in path],
                    "length": len(path),
                    "pairs": [[int(m), int(l)] for m, l in decode_path(path, pool.max_layers)]
                    if pool is not None
                    else None,
                    "names": [f"{pool.names[m]}:L{l}" for m, l in decode_path(path, pool.max_layers)]
                    if pool is not None
                    else None,
                },
                fh,
                ensure_ascii=False,
                indent=2,
            )
    return out_dir
