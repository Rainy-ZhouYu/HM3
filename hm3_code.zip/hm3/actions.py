"""Action space, feasibility masks and path decoding.

Concepts
--------
* candidate pool    : {(m, l) | m in 0..K, l in 0..L-1} plus a STOP action
* action            : the next (model, layer) pair to append to the path
* length constraint : a path has at most ``max_path_len`` actions
* dimension match   : the output width of a layer must equal the input width of
  the layer that follows it

The layer index is a free variable (``--ordered-actions`` optionally restricts it
to the structured case ``l == t``), the dimension-match constraint is enforced
explicitly, and a STOP action implements the variable path length.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

Pair = Tuple[int, int]


def pair_to_flat(m: int, l: int, num_layers: int) -> int:
    """Flat index of the (model, layer) pair inside the (M*L) block."""
    return int(m) * int(num_layers) + int(l)


def flat_to_pair(flat: int, num_layers: int) -> Pair:
    """Inverse of :func:`pair_to_flat`."""
    return divmod(int(flat), int(num_layers))


@dataclass
class ModelLayerPool:
    """Candidate pool: K+1 models (K fine-tuned + the parameter-merged one).

    ``hidden_dims`` holds the transformer width of every candidate model.  For a
    homogeneous pool (all candidates derived from the same backbone) all entries
    are equal and the dimension constraint is satisfied everywhere; for a heterogeneous pool the
    feasibility mask starts to matter.
    """

    names: Sequence[str]
    num_layers: Sequence[int]
    hidden_dims: Sequence[int]
    max_layers: int = field(init=False)

    def __post_init__(self) -> None:
        if not (len(self.names) == len(self.num_layers) == len(self.hidden_dims)):
            raise ValueError("names/num_layers/hidden_dims must have the same length")
        if len(self.names) == 0:
            raise ValueError("candidate pool must not be empty")
        self.max_layers = int(max(self.num_layers))

    @property
    def num_models(self) -> int:
        return len(self.names)

    @property
    def num_actions(self) -> int:
        """M*L selectable pairs plus the STOP action."""
        return self.num_models * self.max_layers + 1

    @property
    def stop_index(self) -> int:
        return self.num_models * self.max_layers

    def is_stop(self, flat_action: int) -> bool:
        return int(flat_action) == self.stop_index

    def layer_available(self, m: int, l: int) -> bool:
        return 0 <= int(m) < self.num_models and 0 <= int(l) < int(self.num_layers[int(m)])

    def describe(self, flat_action: int) -> str:
        if self.is_stop(flat_action):
            return "STOP"
        m, l = flat_to_pair(flat_action, self.max_layers)
        if not self.layer_available(m, l):
            return f"INVALID(m={m},l={l})"
        return f"{self.names[m]}:L{l}"


@dataclass
class PathConstraints:
    """Length and dimension constraints of the inference-path search."""

    max_path_len: int
    min_path_len: int = 1
    allow_alignment: bool = True
    no_repeat_actions: bool = True
    ordered_actions: bool = False

    def __post_init__(self) -> None:
        if self.max_path_len < 1:
            raise ValueError("max_path_len must be >= 1")
        if self.min_path_len < 1:
            raise ValueError("min_path_len must be >= 1")
        if self.min_path_len > self.max_path_len:
            raise ValueError("min_path_len must be <= max_path_len")


def _dim_ok(pool: ModelLayerPool, prev: Pair, nxt: Pair, allow_alignment: bool) -> bool:
    """Dimension match: output width of the previous layer vs input width of the next."""
    prev_dim = int(pool.hidden_dims[prev[0]])
    next_dim = int(pool.hidden_dims[nxt[0]])
    if prev_dim == next_dim:
        return True
    # Heterogeneous widths: only allowed when the alignment MLP is enabled,
    # because otherwise the residual stream cannot be stitched together.
    return bool(allow_alignment)


def transition_feasible(
    pool: ModelLayerPool,
    path: Sequence[int],
    candidate: int,
    constraints: PathConstraints,
) -> bool:
    """Can ``candidate`` be appended to ``path``?"""
    step = len(path)
    if step >= constraints.max_path_len:
        return False
    if pool.is_stop(candidate):
        return step >= constraints.min_path_len
    m, l = flat_to_pair(candidate, pool.max_layers)
    if not pool.layer_available(m, l):
        return False
    if constraints.ordered_actions and l != step:
        # structured mode: the t-th position may only take the t-th layer of some
        # model (smaller, semantically valid action space; kept as an option).
        return False
    if constraints.no_repeat_actions and candidate in path:
        return False
    if step == 0:
        # first layer: its input width has to match the token embedding width,
        # which we take to be the width of the first candidate model.
        base_dim = int(pool.hidden_dims[0])
        if int(pool.hidden_dims[m]) != base_dim and not constraints.allow_alignment:
            return False
        return True
    prev_m, _ = flat_to_pair(path[-1], pool.max_layers)
    return _dim_ok(pool, (prev_m, 0), (m, 0), constraints.allow_alignment)


def feasible_mask(
    pool: ModelLayerPool,
    path: Sequence[int],
    constraints: PathConstraints,
) -> np.ndarray:
    """Boolean mask over the full action space for the current step."""
    mask = np.zeros(pool.num_actions, dtype=bool)
    for a in range(pool.num_actions):
        mask[a] = transition_feasible(pool, path, a, constraints)
    return mask


def decode_path(path: Sequence[int], num_layers: int) -> List[Pair]:
    """Convert a flat path into its (model, layer) sequence."""
    return [flat_to_pair(a, num_layers) for a in path]


def validate_path(
    path: Sequence[int],
    pool: ModelLayerPool,
    constraints: PathConstraints,
) -> List[Pair]:
    """Re-check every constraint along a finalised path (post-condition check)."""
    pairs = decode_path(path, pool.max_layers)
    if not (constraints.min_path_len <= len(pairs) <= constraints.max_path_len):
        raise ValueError(
            f"path length {len(pairs)} violates the length constraint "
            f"[{constraints.min_path_len}, {constraints.max_path_len}]"
        )
    if constraints.no_repeat_actions and len(set(path)) != len(path):
        raise ValueError("path reuses the same (m, l) action while no_repeat_actions is on")
    for m, l in pairs:
        if not pool.layer_available(m, l):
            raise ValueError(f"layer {l} is not available for model {m}")
    base_dim = int(pool.hidden_dims[0])
    if int(pool.hidden_dims[pairs[0][0]]) != base_dim and not constraints.allow_alignment:
        raise ValueError("first layer width does not match the embedding width")
    for prev, nxt in zip(pairs[:-1], pairs[1:]):
        if not _dim_ok(pool, prev, nxt, constraints.allow_alignment):
            raise ValueError(f"dimension mismatch between {prev} and {nxt}")
    return pairs


def alignment_sites(
    path: Sequence[int],
    pool: ModelLayerPool,
    mode: str = "always",
) -> List[int]:
    """Indices in the path where the alignment layer must be applied.

    ``mode``:
        * ``"never"``        - no alignment layer (ablation).
        * ``"dim-mismatch"`` - only when the widths differ.
        * ``"model-change"`` - whenever consecutive layers come from different
          candidates.
        * ``"always"``       - at every junction (default, because the alignment
          layer targets distributional shift rather than width mismatch).
    """
    if mode not in {"never", "dim-mismatch", "model-change", "always"}:
        raise ValueError(f"unknown alignment mode: {mode}")
    pairs = decode_path(path, pool.max_layers)
    sites: List[int] = []
    for idx in range(1, len(pairs)):
        prev, cur = pairs[idx - 1], pairs[idx]
        same_model = prev[0] == cur[0]
        same_dim = int(pool.hidden_dims[prev[0]]) == int(pool.hidden_dims[cur[0]])
        if mode == "always":
            sites.append(idx)
        elif mode == "model-change" and not same_model:
            sites.append(idx)
        elif mode == "dim-mismatch" and not same_dim:
            sites.append(idx)
    return sites


def path_signature(path: Sequence[int]) -> str:
    """Stable cache key for a path."""
    return "-".join(str(int(a)) for a in path)
