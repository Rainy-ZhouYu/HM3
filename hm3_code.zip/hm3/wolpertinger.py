"""Wolpertinger policy mapping.

The mapping restricts a continuous proto-action to a discrete one:

    A_t = argmax_{A in W*(A_bar_t)} Q(S_t, A)   with probability 1 - eps
    A_t = U(W*(A_bar_t))                        with probability eps

where ``W*(A_bar)`` is the k-nearest-neighbour set of the proto-action and the
ranking score is the one-step proxy ``Q~(S, A) = r(S, A) + gamma * V(S')``.

Design notes
-----------
The mapper is the default policy.  Three scoring modes are supported:

``embedding``  logits = sim(z, e_A) / tau, i.e. a softmax relaxation of the
               Voronoi-cell probability induced by the argmax mapping.  This is
               the differentiable surrogate used while training (it keeps a
               non-zero gradient w.r.t. the actor's mean).
``critic``     logits = Q~(S, A) / tau_q (the one-step proxy).
``mixed``      logits = sim / tau + w * standardise(Q~) / tau_q (default).
               Keeps the actor trainable while still letting the critic rank the
               neighbourhood.

``greedy()`` implements the argmax-Q branch literally and is used for evaluation,
so the reported architecture is the deterministic argmax-Q solution.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical


@dataclass
class WolpertingerConfig:
    k: int = 64
    tau: float = 0.1
    q_tau: float = 0.1
    metric: str = "cosine"          # cosine | euclidean
    score_mode: str = "mixed"       # embedding | critic | mixed
    mix_weight: float = 1.0
    standardise_q: bool = True

    def __post_init__(self) -> None:
        if self.metric not in {"cosine", "euclidean"}:
            raise ValueError(f"unknown metric {self.metric!r}")
        if self.score_mode not in {"embedding", "critic", "mixed"}:
            raise ValueError(f"unknown score_mode {self.score_mode!r}")
        if self.k < 1:
            raise ValueError("k must be >= 1")


class ActionEmbedding(nn.Module):
    """Learnable embedding of the (M*L + 1) discrete actions.

    Initialised with structured features (one-hot model id + layer position) so
    that the initial kNN neighbourhood is not arbitrary; the STOP action gets a
    small random vector.  The table stays learnable, which lets the metric adapt
    (the mapping only assumes *some* distance on the action set).
    """

    def __init__(
        self,
        num_actions: int,
        dim: int,
        num_models: int,
        max_layers: int,
        seed: int = 0,
    ) -> None:
        super().__init__()
        self.num_actions = int(num_actions)
        self.dim = int(dim)
        self.num_models = int(num_models)
        self.max_layers = int(max_layers)
        if num_actions != num_models * max_layers + 1:
            raise ValueError("num_actions must be num_models * max_layers + 1 (STOP)")
        self.embedding = nn.Embedding(num_actions, dim)
        with torch.no_grad():
            table = torch.empty(num_actions, dim)
            gen = torch.Generator().manual_seed(int(seed))
            table.normal_(mean=0.0, std=1.0, generator=gen)
            for m in range(num_models):
                for l in range(max_layers):
                    flat = m * max_layers + l
                    head = torch.zeros(dim)
                    head[m % dim] += 1.0
                    if dim > num_models:
                        frac = l / max(1, max_layers - 1)
                        head[num_models] = frac
                        if dim > num_models + 2:
                            head[num_models + 1] = float(torch.sin(torch.tensor(3.141592653589793 * frac)))
                            head[num_models + 2] = float(torch.cos(torch.tensor(3.141592653589793 * frac)))
                    table[flat] = head + 0.1 * table[flat]
            self.embedding.weight.copy_(table)

    def forward(self, index: Optional[torch.Tensor] = None) -> torch.Tensor:
        if index is None:
            return self.embedding.weight
        return self.embedding(index)


class WolpertingerMapper(nn.Module):
    """kNN restriction of the continuous proto-action to a discrete action."""

    def __init__(self, action_embedding: ActionEmbedding, cfg: WolpertingerConfig) -> None:
        super().__init__()
        self.action_embedding = action_embedding
        self.cfg = cfg

    # ------------------------------------------------------------- neighbours
    def _scores(self, z: torch.Tensor, emb: torch.Tensor) -> torch.Tensor:
        if self.cfg.metric == "cosine":
            return F.normalize(z, dim=-1) @ F.normalize(emb, dim=-1).T
        return -torch.cdist(z, emb, p=2).pow(2)

    def neighbours(
        self,
        z: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Return ``(candidate_idx, candidate_emb, similarity, feasible)``.

        ``mask`` is a boolean feasibility mask of shape [B, N]; infeasible actions
        are pushed to -inf so that the neighbourhood never contains an action that
        would violate the length or dimension constraint.
        """
        emb = self.action_embedding()                      # [N, D]
        scores = self._scores(z, emb)                      # [B, N]
        feasible = None
        if mask is not None:
            if mask.shape != scores.shape:
                raise ValueError(
                    f"feasibility mask shape {tuple(mask.shape)} != score shape {tuple(scores.shape)}"
                )
            feasible = mask.clone()
            scores = scores.masked_fill(~mask, float("-inf"))
            num_ok = mask.sum(dim=1)
            if bool((num_ok == 0).any()):
                raise RuntimeError("no feasible action available for at least one state")
        k = min(int(self.cfg.k), scores.shape[1])
        top_scores, top_idx = torch.topk(scores, k=k, dim=1, largest=True)
        cand_emb = emb[top_idx]
        cand_feasible = feasible.gather(1, top_idx) if feasible is not None else torch.ones_like(
            top_idx, dtype=torch.bool
        )
        return top_idx, cand_emb, top_scores, cand_feasible

    # ----------------------------------------------------------------- logits
    def _combined_logits(
        self,
        sim: torch.Tensor,
        q_values: Optional[torch.Tensor],
        feasible: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        cfg = self.cfg
        logits = sim / max(cfg.tau, 1e-8)
        if q_values is not None and cfg.score_mode != "embedding":
            q = q_values
            if cfg.standardise_q and q.shape[1] > 1:
                # standardise over the *feasible* candidates only, otherwise the
                # masked entries (whose proxy values are finite) would dominate
                # the mean/std and leak back into the distribution.
                if feasible is not None and bool(feasible.any()):
                    mask_f = feasible.float()
                    count = mask_f.sum(dim=1, keepdim=True).clamp_min(1.0)
                    mean = (q * mask_f).sum(dim=1, keepdim=True) / count
                    var = (((q - mean) ** 2) * mask_f).sum(dim=1, keepdim=True) / count
                    q = (q - mean) / (var.sqrt() + 1e-6)
                else:
                    q = (q - q.mean(dim=1, keepdim=True)) / (q.std(dim=1, keepdim=True) + 1e-6)
            if cfg.score_mode == "critic":
                logits = q / max(cfg.q_tau, 1e-8)
            else:
                logits = logits + float(cfg.mix_weight) * q / max(cfg.q_tau, 1e-8)
        if feasible is not None:
            # hard guard: an infeasible neighbour must never be selectable even if
            # its combined score is finite.
            logits = logits.masked_fill(~feasible, float("-inf"))
        return logits

    def local_policy(
        self,
        z: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        q_values: Optional[torch.Tensor] = None,
    ):
        """Categorical over the neighbourhood + the mapping back to global ids."""
        cand_idx, _, sim, feasible = self.neighbours(z, mask)
        logits = self._combined_logits(sim, q_values, feasible)
        return Categorical(logits=logits), cand_idx, logits

    def local_index_of(self, cand_idx: torch.Tensor, action: torch.Tensor) -> torch.Tensor:
        """Position of ``action`` inside the neighbourhood (== k means missing)."""
        matches = cand_idx.eq(action.view(-1, 1))
        found = matches.any(dim=1)
        local = matches.float().argmax(dim=1)
        local = torch.where(found, local, torch.full_like(local, cand_idx.shape[1]))
        return local

    def log_prob(
        self,
        z: torch.Tensor,
        action: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        q_values: Optional[torch.Tensor] = None,
        return_entropy: bool = False,
    ):
        dist, cand_idx, _ = self.local_policy(z, mask, q_values)
        local = self.local_index_of(cand_idx, action)
        missing = local >= cand_idx.shape[1]
        if bool(missing.any()):
            # The stored action is outside the current neighbourhood: give it a
            # vanishing probability instead of silently changing the action.
            logits = torch.full((z.shape[0], cand_idx.shape[1]), -1e9, device=z.device)
            logits[~missing] = dist.logits[~missing]
            logits[missing, -1] = 0.0
            cand_idx = cand_idx.clone()
            cand_idx[missing, -1] = action[missing]
            local = torch.where(missing, torch.full_like(local, cand_idx.shape[1] - 1), local)
            dist = Categorical(logits=logits)
        logp = dist.log_prob(local)
        if return_entropy:
            return logp, dist.entropy(), cand_idx
        return logp, cand_idx

    @torch.no_grad()
    def greedy(
        self,
        z: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        q_values: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """argmax-Q branch, with argmax-similarity as fallback."""
        cand_idx, _, sim, feasible = self.neighbours(z, mask)
        if q_values is None or self.cfg.score_mode == "embedding":
            best = sim.masked_fill(~feasible, float("-inf")).argmax(dim=1)
        else:
            best = q_values.masked_fill(~feasible, float("-inf")).argmax(dim=1)
        return cand_idx.gather(1, best.view(-1, 1)).squeeze(1)

    @torch.no_grad()
    def uniform_in_neighbourhood(
        self,
        z: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        generator: Optional[torch.Generator] = None,
    ) -> torch.Tensor:
        """Exploration branch: uniform over the *feasible* part of W*(A_bar).

        When the number of feasible actions is smaller than ``k`` the neighbourhood
        also contains infeasible entries (their similarity is -inf, so they only
        enter the top-k for lack of alternatives).  Sampling must therefore be
        restricted to the feasible entries, otherwise the environment raises
        "infeasible action" - which is exactly what happened in the ordered-action
        (structured) configuration where only K+1 actions are feasible per step.
        """
        cand_idx, _, _, feasible = self.neighbours(z, mask)
        if feasible is None or bool(feasible.all()):
            pick = torch.randint(
                low=0,
                high=cand_idx.shape[1],
                size=(cand_idx.shape[0],),
                generator=generator,
                device=cand_idx.device,
            )
        else:
            weights = feasible.float()
            if bool((weights.sum(dim=1) == 0).any()):
                raise RuntimeError("no feasible candidate in the neighbourhood")
            pick = torch.multinomial(weights, num_samples=1, generator=generator).squeeze(1)
        return cand_idx.gather(1, pick.view(-1, 1)).squeeze(1)


def q_proxy(next_values: torch.Tensor, reward: torch.Tensor, gamma: float) -> torch.Tensor:
    """One-step proxy score: Q~(S, A) = r(S, A) + gamma * V(S')."""
    return reward + float(gamma) * next_values
