"""Inference-path search environment.

The environment owns the discrete part of the search: it enforces the length
constraint (variable path length via the STOP action) and dimension
compatibility, calls the task scorer only when a path is complete, and converts
the scores into a reward.  It is numpy-only so it can be unit tested without a GPU.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np

from .actions import (
    ModelLayerPool,
    PathConstraints,
    alignment_sites,
    decode_path,
    feasible_mask,
    flat_to_pair,
    path_signature,
    transition_feasible,
    validate_path,
)
from .reward import RewardBreakdown, RewardFn

ScorerFn = Callable[[Sequence[int]], Mapping[str, float]]


@dataclass
class StepInfo:
    step: int
    action: int
    terminal: bool
    reward: float
    scores: Dict[str, float] = field(default_factory=dict)
    breakdown: Optional[RewardBreakdown] = None
    cache_hit: bool = False


class LayerPathEnv:
    """Sequential decision process over model-layer pairs."""

    def __init__(
        self,
        pool: ModelLayerPool,
        constraints: PathConstraints,
        scorer: ScorerFn,
        reward_fn: RewardFn,
        task_weights: Mapping[str, float],
        cache_size: int = 1024,
    ) -> None:
        self.pool = pool
        self.constraints = constraints
        self.scorer = scorer
        self.reward_fn = reward_fn
        self.task_weights = dict(task_weights)
        self.cache: "OrderedDict[str, Mapping[str, float]]" = OrderedDict()
        self.cache_size = int(cache_size)
        self.path: List[int] = []
        self.steps = 0
        self.scorer_calls = 0
        self.cache_hits = 0

    # ------------------------------------------------------------------ utils
    def _score(self, path: Sequence[int]) -> Tuple[Mapping[str, float], bool]:
        key = path_signature(path)
        if key in self.cache:
            value = self.cache.pop(key)
            self.cache[key] = value
            self.cache_hits += 1
            return value, True
        self.scorer_calls += 1
        scores = dict(self.scorer(path))
        self.cache[key] = scores
        if len(self.cache) > self.cache_size:
            self.cache.popitem(last=False)
        return scores, False

    # -------------------------------------------------------------------- mdp
    def reset(self) -> Dict[str, object]:
        self.path = []
        self.steps = 0
        return self.observation()

    def observation(self) -> Dict[str, object]:
        mask = feasible_mask(self.pool, self.path, self.constraints)
        return {
            "step": int(self.steps),
            "path": tuple(self.path),
            "mask": mask,
            "prev_action": (self.path[-1] if self.path else None),
            "must_stop": self.steps >= self.constraints.max_path_len,
        }

    def step(self, action: int) -> Tuple[Dict[str, object], float, bool, StepInfo]:
        action = int(action)
        if not transition_feasible(self.pool, self.path, action, self.constraints):
            raise ValueError(
                f"infeasible action {self.pool.describe(action)} at step {self.steps} "
                f"(path={self.path})"
            )
        if self.pool.is_stop(action):
            return self._terminate(action, cached=False)
        self.path.append(action)
        self.steps += 1
        if self.steps >= self.constraints.max_path_len:
            return self._terminate(action, cached=False)
        obs = self.observation()
        if not obs["mask"].any():
            # no continuation is feasible: end the episode here (only possible
            # when every remaining pair is blocked, e.g. with no_repeat_actions).
            return self._terminate(action, cached=False)
        info = StepInfo(step=self.steps, action=action, terminal=False, reward=0.0)
        return obs, 0.0, False, info

    def _terminate(self, action: int, cached: bool) -> Tuple[Dict[str, object], float, bool, StepInfo]:
        validate_path(self.path, self.pool, self.constraints)
        scores, hit = self._score(self.path)
        breakdown = self.reward_fn(scores, self.task_weights, len(self.path))
        info = StepInfo(
            step=self.steps,
            action=action,
            terminal=True,
            reward=float(breakdown.reward),
            scores={str(k): float(v) for k, v in scores.items() if v is not None},
            breakdown=breakdown,
            cache_hit=hit,
        )
        return self.observation(), float(breakdown.reward), True, info

    # --------------------------------------------------------------- helpers
    def decoded(self) -> List[Tuple[int, int]]:
        return decode_path(self.path, self.pool.max_layers)

    def alignment_sites(self, mode: str = "always") -> List[int]:
        return alignment_sites(self.path, self.pool, mode)

    def describe(self, action: int) -> str:
        return self.pool.describe(action)


def roll_path_features(pool: ModelLayerPool, path: Sequence[int]) -> Tuple[np.ndarray, np.ndarray]:
    """Model indices and layer indices of a path, as arrays (for the policy)."""
    pairs = decode_path(path, pool.max_layers)
    if not pairs:
        return np.zeros(0, dtype=np.int64), np.zeros(0, dtype=np.int64)
    models = np.asarray([p[0] for p in pairs], dtype=np.int64)
    layers = np.asarray([p[1] for p in pairs], dtype=np.int64)
    return models, layers
