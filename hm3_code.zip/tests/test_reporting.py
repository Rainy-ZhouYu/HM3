"""Unit tests for the reporting helpers (numpy only)."""

import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from hm3.reporting import load_episodes, moment_report, running_best


def test_running_best():
    assert running_best([0.1, 0.5, 0.3, 0.9, 0.2]) == [0.1, 0.5, 0.5, 0.9, 0.9]


def test_load_episodes_handles_arrays_and_objects():
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "episodes.jsonl")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(json.dumps([{"reward": 1.0}, {"reward": 2.0}]) + "\n")
            fh.write(json.dumps({"reward": 3.0}) + "\n")
        episodes = load_episodes(path)
    assert [ep["reward"] for ep in episodes] == [1.0, 2.0, 3.0]
    assert load_episodes(os.path.join(tmp, "missing.jsonl")) == []


def test_moment_report_improves_first_and_second_moments():
    rng = np.random.default_rng(0)
    src = rng.normal(loc=1.5, scale=2.0, size=(2000, 16))
    tgt = rng.normal(loc=-0.4, scale=0.5, size=(2000, 16))
    report = moment_report(src, tgt)
    assert report.mean_l2_after < report.mean_l2_before
    assert report.cov_fro_after < report.cov_fro_before
    assert report.variance_ratio_after < report.variance_ratio_before
    improvement = report.improvement()
    assert improvement["mean_l2_ratio"] < 0.05
    assert improvement["cov_fro_ratio"] < 0.05


def test_moment_report_accepts_custom_map():
    rng = np.random.default_rng(1)
    src = rng.normal(size=(500, 8))
    tgt = src * 3.0 + 2.0
    report = moment_report(src, tgt, align_fn=lambda z: z * 3.0 + 2.0)
    assert report.mean_l2_after < 1e-9
    assert report.cov_fro_after < 1e-9


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"[ok] {fn.__name__}")
    print(f"[reporting] {len(fns)} tests passed")
