"""Unit tests for the task -> model preference mapping (numpy only)."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hm3.weights import (
    TaskModelMappingError,
    build_merge_weight_plan,
    model_weight_vector,
    parse_task_model_map,
    validate_model_order,
)

MODELS = ["Qwen2.5-Coder-1.5B-Instruct", "Qwen2.5-1.5B-Instruct", "Qwen2.5-Math-1.5B-Instruct"]
TASKS = ["xnli", "gsm8k_platinum_cot", "mbpp"]
WEIGHTS = {"xnli": 0.7, "gsm8k_platinum_cot": 0.2, "mbpp": 0.1}


def test_parse_mapping():
    assert parse_task_model_map("xnli=1,gsm8k=2,mbpp=0") == {"xnli": 1, "gsm8k": 2, "mbpp": 0}
    assert parse_task_model_map("") == {}


def test_explicit_mapping_puts_the_weight_on_the_right_model():
    mapping = {"xnli": 1, "gsm8k_platinum_cot": 2, "mbpp": 0}
    plan = build_merge_weight_plan(TASKS, WEIGHTS, MODELS, mapping)
    assert abs(plan.model_weights["Qwen2.5-1.5B-Instruct"] - 0.7) < 1e-12
    assert abs(plan.model_weights["Qwen2.5-Math-1.5B-Instruct"] - 0.2) < 1e-12
    assert abs(plan.model_weights["Qwen2.5-Coder-1.5B-Instruct"] - 0.1) < 1e-12
    assert abs(sum(model_weight_vector(plan)) - 1.0) < 1e-12


def test_positional_mapping_is_used_only_when_counts_match():
    plan = build_merge_weight_plan(TASKS, WEIGHTS, MODELS)
    # positional: task i -> model i
    assert abs(plan.model_weights[MODELS[0]] - 0.7) < 1e-12
    assert plan.task_to_model == {"xnli": 0, "gsm8k_platinum_cot": 1, "mbpp": 2}


def test_mismatched_counts_raise_instead_of_silently_uniform():
    four_tasks = TASKS + ["humaneval"]
    try:
        build_merge_weight_plan(four_tasks, WEIGHTS, MODELS)
    except TaskModelMappingError as exc:
        assert "explicit" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected TaskModelMappingError")


def test_mapping_validation_errors():
    try:
        build_merge_weight_plan(TASKS, WEIGHTS, MODELS, {"xnli": 0})
    except TaskModelMappingError as exc:
        assert "missing" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected TaskModelMappingError")
    try:
        build_merge_weight_plan(TASKS, WEIGHTS, MODELS, {"xnli": 9, "gsm8k_platinum_cot": 1, "mbpp": 2})
    except TaskModelMappingError as exc:
        assert "only 3 candidates" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected TaskModelMappingError")


def test_weights_are_normalised_and_non_negative():
    plan = build_merge_weight_plan(TASKS, {"xnli": 3.0, "gsm8k_platinum_cot": 1.0, "mbpp": 0.0}, MODELS)
    assert abs(sum(plan.task_weights.values()) - 1.0) < 1e-12
    try:
        build_merge_weight_plan(TASKS, {"xnli": -1.0, "gsm8k_platinum_cot": 1.0, "mbpp": 1.0}, MODELS)
    except TaskModelMappingError:
        pass
    else:  # pragma: no cover
        raise AssertionError("expected TaskModelMappingError for negative weights")


def test_model_order_guard():
    validate_model_order(MODELS, "Qwen/Qwen2.5-1.5B")
    try:
        validate_model_order(MODELS + [MODELS[0]], "Qwen/Qwen2.5-1.5B")
    except TaskModelMappingError:
        pass
    else:  # pragma: no cover
        raise AssertionError("expected duplicate detection")
    try:
        validate_model_order(MODELS + ["Qwen/Qwen2.5-1.5B"], "Qwen/Qwen2.5-1.5B")
    except TaskModelMappingError:
        pass
    else:  # pragma: no cover
        raise AssertionError("expected base-in-pool detection")


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"[ok] {fn.__name__}")
    print(f"[weights] {len(fns)} tests passed")
