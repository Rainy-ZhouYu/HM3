"""Unit tests for the reward functions (numpy only)."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from hm3.reward import (
    RewardConfig,
    RewardFn,
    normalize_weights,
    weighted_sum_reward,
    to_unit_interval,
    uniform_per_step,
)

TASKS = ["xnli", "gsm8k_platinum_cot", "mbpp"]
SCORES = {"xnli": 0.42, "gsm8k_platinum_cot": 0.30, "mbpp": 0.18}


def test_metric_rescaling():
    assert to_unit_interval(0.42) == 0.42
    assert abs(to_unit_interval(51.095) - 0.51095) < 1e-9
    assert to_unit_interval(0.42, "raw") == 0.42


def test_weighted_sum_mode_matches_definition():
    weights = {"xnli": 0.5, "gsm8k_platinum_cot": 0.3, "mbpp": 0.2}
    fn = RewardFn(RewardConfig(mode="weighted_sum", beta=0.0), TASKS)
    out = fn(SCORES, weights, path_len=28)
    expected = weighted_sum_reward(
        [SCORES[t] for t in TASKS], [weights[t] for t in TASKS], path_len=28
    )
    assert abs(out.reward - expected) < 1e-9


def test_weighted_sum_mode_length_penalty():
    weights = {"xnli": 0.5, "gsm8k_platinum_cot": 0.3, "mbpp": 0.2}
    short = RewardFn(RewardConfig(mode="weighted_sum", beta=0.01), TASKS)(SCORES, weights, path_len=10)
    long = RewardFn(RewardConfig(mode="weighted_sum", beta=0.01), TASKS)(SCORES, weights, path_len=28)
    assert abs((long.reward - short.reward) - (-0.01 * 18)) < 1e-9
    assert short.reward > long.reward


def test_tchebycheff_has_no_hidden_tie_break():
    weights = {"xnli": 1.0, "gsm8k_platinum_cot": 0.0, "mbpp": 0.0}
    ideal = {"xnli": 1.0, "gsm8k_platinum_cot": 1.0, "mbpp": 1.0}
    out = RewardFn(RewardConfig(mode="tchebycheff", ideal_point=ideal), TASKS)(
        SCORES, weights, path_len=28
    )
    assert abs(out.reward - (-(1.0 - 0.42))) < 1e-9


def test_legacy_mode_keeps_the_old_extra_term():
    weights = {"xnli": 1.0, "gsm8k_platinum_cot": 0.0, "mbpp": 0.0}
    ideal = {"xnli": 1.0, "gsm8k_platinum_cot": 1.0, "mbpp": 1.0}
    out = RewardFn(RewardConfig(mode="legacy", ideal_point=ideal, max_path_len=28), TASKS)(
        SCORES, weights, path_len=28
    )
    assert abs(out.reward - (-(0.58) + 0.05 * 0.42)) < 1e-9


def test_missing_score_yields_penalty():
    fn = RewardFn(RewardConfig(mode="weighted_sum", penalty_on_fail=-999.0), TASKS)
    out = fn({"xnli": 0.4, "mbpp": 0.1}, {"xnli": 1.0}, path_len=28)
    assert out.failure and out.reward == -999.0


def test_weight_normalisation():
    w = normalize_weights({"xnli": 2.0, "gsm8k_platinum_cot": 2.0}, TASKS)
    assert abs(sum(w.values()) - 1.0) < 1e-12
    assert abs(w["xnli"] - 0.5) < 1e-12 and w["mbpp"] == 0.0


def test_uniform_per_step():
    assert abs(uniform_per_step(2.8, 28) - 0.1) < 1e-12
    assert uniform_per_step(2.8, 0) == 2.8


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"[ok] {fn.__name__}")
    print(f"[reward] {len(fns)} tests passed")
