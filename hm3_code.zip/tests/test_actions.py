"""Unit tests for the action space / feasibility logic (numpy only)."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from hm3.actions import (
    ModelLayerPool,
    PathConstraints,
    alignment_sites,
    decode_path,
    feasible_mask,
    flat_to_pair,
    pair_to_flat,
    transition_feasible,
    validate_path,
)


def homogeneous_pool():
    return ModelLayerPool(
        names=["instruct", "math", "coder", "upper_dare_ties"],
        num_layers=[28, 28, 28, 28],
        hidden_dims=[1536, 1536, 1536, 1536],
    )


def heterogeneous_pool():
    return ModelLayerPool(
        names=["qwen-1.5b", "llama-7b"],
        num_layers=[28, 32],
        hidden_dims=[1536, 4096],
    )


def test_flat_index_roundtrip():
    for m in range(4):
        for l in range(28):
            flat = pair_to_flat(m, l, 28)
            assert flat_to_pair(flat, 28) == (m, l)


def test_action_space_has_stop():
    pool = homogeneous_pool()
    assert pool.num_actions == 4 * 28 + 1
    assert pool.stop_index == 112
    assert pool.is_stop(112) and not pool.is_stop(0)


def test_free_layer_choice_not_ordered():
    """A3: any (m, l) is selectable at any step - not just the t-th layer."""
    pool = homogeneous_pool()
    cons = PathConstraints(max_path_len=28, min_path_len=1, no_repeat_actions=False)
    # step 0 can pick layer 17 of model 2
    assert transition_feasible(pool, [], pair_to_flat(2, 17, 28), cons)
    # after that, step 1 can pick layer 3 of model 0
    path = [pair_to_flat(2, 17, 28)]
    assert transition_feasible(pool, path, pair_to_flat(0, 3, 28), cons)


def test_stop_respects_min_path_len():
    pool = homogeneous_pool()
    cons = PathConstraints(max_path_len=28, min_path_len=3)
    pool_stop = pool.stop_index
    assert not transition_feasible(pool, [0], pool_stop, cons)
    assert transition_feasible(pool, [0, 1, 2], pool_stop, cons)


def test_length_constraint_bounds_the_path():
    pool = homogeneous_pool()
    cons = PathConstraints(max_path_len=4, min_path_len=1, no_repeat_actions=False)
    mask = feasible_mask(pool, [0, 1, 2, 3], cons)
    assert not mask.any(), "no action may be appended once T_max is reached"


def test_no_repeat_blocks_reusing_a_pair():
    pool = homogeneous_pool()
    cons = PathConstraints(max_path_len=28, min_path_len=1, no_repeat_actions=True)
    a = pair_to_flat(1, 5, 28)
    assert not transition_feasible(pool, [a], a, cons)


def test_dimension_constraint_masks_cross_width_jumps_without_alignment():
    pool = heterogeneous_pool()
    strict = PathConstraints(max_path_len=32, min_path_len=1, allow_alignment=False)
    relaxed = PathConstraints(max_path_len=32, min_path_len=1, allow_alignment=True)
    first = pair_to_flat(0, 3, pool.max_layers)
    second = pair_to_flat(1, 4, pool.max_layers)
    assert not transition_feasible(pool, [first], second, strict)
    assert transition_feasible(pool, [first], second, relaxed)


def test_alignment_sites_modes():
    pool = homogeneous_pool()
    path = [
        pair_to_flat(0, 0, 28),
        pair_to_flat(0, 1, 28),
        pair_to_flat(2, 2, 28),
        pair_to_flat(2, 3, 28),
    ]
    assert alignment_sites(path, pool, "never") == []
    assert alignment_sites(path, pool, "model-change") == [2]
    assert alignment_sites(path, pool, "always") == [1, 2, 3]
    assert alignment_sites(path, pool, "dim-mismatch") == []


def test_validate_path_accepts_and_rejects():
    pool = homogeneous_pool()
    cons = PathConstraints(max_path_len=28, min_path_len=2)
    good = [pair_to_flat(1, 0, 28), pair_to_flat(3, 1, 28)]
    pairs = validate_path(good, pool, cons)
    assert pairs == [(1, 0), (3, 1)]
    assert decode_path(good, 28) == pairs
    try:
        validate_path([good[0]], pool, cons)
    except ValueError as exc:
        assert "length constraint" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected a length-constraint violation")
    try:
        validate_path([good[0], good[0]], pool, cons)
    except ValueError as exc:
        assert "reuses" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected a repeat violation")


def test_feasible_mask_matches_elementwise_checks():
    pool = homogeneous_pool()
    cons = PathConstraints(max_path_len=28, min_path_len=2, no_repeat_actions=True)
    path = [pair_to_flat(0, 0, 28)]
    mask = feasible_mask(pool, path, cons)
    for a in range(pool.num_actions):
        assert bool(mask[a]) == transition_feasible(pool, path, a, cons)
    # every (m, l) pair except the one already used; STOP is not allowed yet
    # because min_path_len == 2 and the path currently has length 1.
    assert mask.sum() == pool.num_models * pool.max_layers - 1
    assert not mask[pool.stop_index]


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"[ok] {fn.__name__}")
    print(f"[actions] {len(fns)} tests passed")
