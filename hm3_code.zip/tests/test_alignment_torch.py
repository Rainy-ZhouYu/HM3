"""A6: does the low-rank term really reduce the covariance mismatch?

Compares three maps on synthetic activations whose means, variances *and*
correlations differ between source and target:

    diag            : AlignmentMLP(rank=0)              (diagonal only)
    diag+lowrank    : AlignmentMLP(rank=R)
    oracle          : the exact affine map applied to the source

Requires torch; prints SKIP when torch is unavailable so the numpy-only test
runner still passes.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

try:
    import torch
except ImportError:  # pragma: no cover - CPU-only machines
    torch = None

from hm3.reporting import moment_report


def _make_data(seed: int = 0, n: int = 2048, d: int = 64, rank: int = 8):
    rng = np.random.default_rng(seed)
    # correlated source: low-rank plus noise
    basis = rng.normal(size=(d, rank))
    latent = rng.normal(size=(n, rank)) * 3.0
    src = latent @ basis.T + rng.normal(size=(n, d)) * 0.5 + 0.7
    # target: same latent factors but different mixing and scale
    basis2 = rng.normal(size=(d, rank))
    tgt = (latent @ basis2.T) * 0.4 - 0.3 + rng.normal(size=(n, d)) * 0.2
    return src.astype(np.float32), tgt.astype(np.float32)


def _report(rank: int, src, tgt, steps: int = 300):
    from hm3.alignment import AlignmentMLP, ActivationStats, fit_alignment

    d = src.shape[1]
    stats = ActivationStats(
        mean=src.mean(axis=0)[None, :].repeat(2, axis=0),
        std=(src.std(axis=0) + 1e-3)[None, :].repeat(2, axis=0),
        num_layers=1,
    )
    aligner = AlignmentMLP(stats, hidden_dim=32, max_layers=1, num_models=2, rank=rank)
    fit = fit_alignment(aligner, 0, 1, torch.as_tensor(src), torch.as_tensor(tgt), steps=steps, lr=5e-3)

    def align(z):
        with torch.no_grad():
            zt = torch.as_tensor(np.asarray(z, dtype=np.float32))
            idx = torch.zeros(zt.shape[0], dtype=torch.long)
            out = aligner.transform(zt, idx, torch.ones_like(idx), idx)
        return out.numpy()

    moments = moment_report(src, tgt, align_fn=align)
    return fit, moments


def test_low_rank_reduces_covariance_mismatch():
    if torch is None:  # pragma: no cover
        print("SKIP test_low_rank_reduces_covariance_mismatch (no torch)")
        return
    src, tgt = _make_data()
    fit_diag, mom_diag = _report(0, src, tgt)
    fit_lr, mom_lr = _report(16, src, tgt)
    print(f"  diag     : coral {fit_diag.coral:12.4f}  cov_fro {mom_diag.cov_fro_after:10.4f}")
    print(f"  diag+lr16: coral {fit_lr.coral:12.4f}  cov_fro {mom_lr.cov_fro_after:10.4f}")
    assert mom_lr.cov_fro_after < mom_diag.cov_fro_after, (
        "low-rank term did not improve the covariance mismatch",
        mom_diag.cov_fro_after,
        mom_lr.cov_fro_after,
    )
    assert fit_lr.coral < fit_diag.coral


def test_low_rank_keeps_first_moment():
    if torch is None:  # pragma: no cover
        print("SKIP test_low_rank_keeps_first_moment (no torch)")
        return
    src, tgt = _make_data(seed=1)
    _, mom = _report(8, src, tgt)
    assert mom.mean_l2_after < mom.mean_l2_before
    assert mom.mean_l2_after < 0.5, mom.mean_l2_after  # roughly matched


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"[ok] {fn.__name__}")
    print(f"[alignment] {len(fns)} tests passed")
