"""Unit tests for Pareto / hypervolume utilities (numpy only)."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from hm3.metrics import (
    dominance_matrix,
    hypervolume_max,
    ideal_point_from_scores,
    pareto_dominates,
    pareto_front,
    pareto_front_indices,
    pareto_report,
    reference_point,
)


def test_hypervolume_2d_analytic():
    # union of [0,3]x[0,1] and [0,1]x[0,3] = 3 + 3 - 1 = 5
    assert abs(hypervolume_max([[3, 1], [1, 3]], [0, 0]) - 5.0) < 1e-9


def test_hypervolume_single_point_and_empty():
    assert abs(hypervolume_max([[0.5, 0.5, 0.5]], [0, 0, 0]) - 0.125) < 1e-9
    assert hypervolume_max([], [0, 0]) == 0.0


def test_hypervolume_dominated_point_does_not_change_it():
    base = hypervolume_max([[0.9, 0.9]], [0, 0])
    with_dominated = hypervolume_max([[0.9, 0.9], [0.2, 0.2]], [0, 0])
    assert abs(base - with_dominated) < 1e-12


def test_hypervolume_matches_monte_carlo_estimate():
    rng = np.random.default_rng(0)
    pts = rng.uniform(0.1, 0.9, size=(6, 2))
    ref = np.array([0.0, 0.0])
    hv = hypervolume_max(pts, ref)
    n = 400_000
    samples = rng.uniform(0.0, 1.0, size=(n, 2))
    covered = np.zeros(n, dtype=bool)
    for p in pts:
        covered |= np.all(samples <= p, axis=1)
    mc = covered.mean()
    assert abs(hv - mc) < 0.02, (hv, mc)


def test_dominance_and_front():
    pts = [[0.5, 0.5], [0.4, 0.4], [0.6, 0.3], [0.3, 0.6]]
    assert pareto_dominates([0.5, 0.5], [0.4, 0.4])
    assert not pareto_dominates([0.5, 0.5], [0.6, 0.3])
    matrix = dominance_matrix(pts)
    assert matrix[0, 1] and not matrix[1, 0]
    front = pareto_front_indices(pts)
    assert 1 not in front
    assert set(front) == {0, 2, 3}
    assert pareto_front(pts).shape == (3, 2)


def test_reference_point_and_report():
    pts = [[0.5, 0.5], [0.7, 0.2], [0.1, 0.1]]
    ref = reference_point(pts, margin=0.1)
    assert np.allclose(ref, [0.0, 0.0])
    report = pareto_report(pts, margin=0.1)
    assert report.indices == [0, 1]
    assert report.dominated == [2]
    expected = hypervolume_max([[0.5, 0.5], [0.7, 0.2]], ref)
    assert abs(report.hypervolume - expected) < 1e-12


def test_ideal_point_is_the_best_observed_per_task():
    scores = {
        "instruct": {"xnli": 0.41, "gsm8k_platinum_cot": 0.14, "mbpp": 0.40},
        "math": {"xnli": 0.35, "gsm8k_platinum_cot": 0.33, "mbpp": 0.44},
        "coder": {"xnli": 0.42, "gsm8k_platinum_cot": 0.16, "mbpp": 0.52},
        "upper": {"xnli": 0.38, "gsm8k_platinum_cot": 0.25, "mbpp": 0.31},
    }
    ideal = ideal_point_from_scores(scores, ["xnli", "gsm8k_platinum_cot", "mbpp"])
    assert ideal == {"xnli": 0.42, "gsm8k_platinum_cot": 0.33, "mbpp": 0.52}


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"[ok] {fn.__name__}")
    print(f"[metrics] {len(fns)} tests passed")
