"""End-to-end smoke test for the A-group rework.

Builds three tiny randomly initialised Qwen2 models (no downloads), runs the
full architecture-level loop (Wolpertinger + GRU state + variable path length +
alignment MLP) against a deterministic synthetic scorer, and asserts that every
A-group behaviour is actually exercised:

    A1  Wolpertinger neighbourhood is used and every sampled action is feasible
    A2  the GRU trajectory encoder sees the full prefix (perturbation check)
    A3  layer indices are free (some step picks l != t)
    A4  paths have variable length (STOP is used)
    A5  reward equals sum_k lambda_k f_k - beta * T
    A6  the alignment MLP reduces the Deep-CORAL + mean loss

Usage:
    python tools/smoke_test_tiny.py --device cuda --iters 6 --episodes 4
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Dict, List, Sequence

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from transformers import AutoConfig, AutoModelForCausalLM

from hm3.actions import ModelLayerPool, PathConstraints, decode_path, feasible_mask
from hm3.alignment import AlignmentMLP, ActivationStats, deep_coral_loss, fit_alignment, mean_alignment_loss
from hm3.assemble import build_merged_model
from hm3.env import LayerPathEnv
from hm3.metrics import pareto_report
from hm3.policy import ActorCritic, PolicyConfig
from hm3.ppo import PPOAgent, PPOConfig
from hm3.reward import RewardConfig, RewardFn, weighted_sum_reward
from hm3.signatures import build_signature_table
from hm3.wolpertinger import ActionEmbedding, WolpertingerConfig, WolpertingerMapper


TASKS = ["translation", "math", "code"]


def make_tiny_models(num_models: int = 3, layers: int = 6, hidden: int = 64, vocab: int = 128):
    config = AutoConfig.for_model(
        "qwen2",
        hidden_size=hidden,
        num_hidden_layers=layers,
        num_attention_heads=4,
        num_key_value_heads=2,
        intermediate_size=hidden * 2,
        vocab_size=vocab,
        max_position_embeddings=64,
        tie_word_embeddings=False,
    )
    torch.manual_seed(0)
    return [AutoModelForCausalLM.from_config(config) for _ in range(num_models)], config


def make_synthetic_scorer(pool: ModelLayerPool, tasks: Sequence[str], seed: int = 0):
    """Deterministic 'benchmark': each task prefers one source model."""
    rng = np.random.default_rng(seed)
    preference = {}
    for k, task in enumerate(tasks):
        pref = np.zeros(pool.num_models)
        pref[k % pool.num_models] = 1.0
        pref[(k + 1) % pool.num_models] = 0.4
        preference[task] = pref / pref.sum()
    calls = {"n": 0}

    def _score(path: Sequence[int]) -> Dict[str, float]:
        calls["n"] += 1
        pairs = decode_path(path, pool.max_layers)
        scores: Dict[str, float] = {}
        for task in tasks:
            pref = preference[task]
            value = 0.0
            for m, _l in pairs:
                value += pref[m]
            value /= max(1, len(pairs))
            # deterministic "noise" so that ties are broken consistently
            jitter = 0.01 * float(np.sin(0.37 * sum(path) + 1.7 * len(path)))
            scores[task] = float(np.clip(value + jitter, 0.0, 1.0))
        return scores

    return _score, preference, calls


def check_alignment(device) -> Dict[str, float]:
    """A6: the analytic init already helps; the fitted MLP improves it further."""
    torch.manual_seed(0)
    dim, slots, layers = 16, 12, 4
    mean = torch.randn(slots, dim) * 0.5
    std = torch.rand(slots, dim) * 0.8 + 0.2
    stats = ActivationStats(mean=mean.numpy(), std=std.numpy(), num_layers=layers)
    aligner = AlignmentMLP(stats, hidden_dim=32, max_layers=layers, num_models=slots // layers).to(device)
    src_base = torch.randn(256, dim, device=device) * 2.0 + 0.7
    tgt_base = torch.randn(256, dim, device=device) * 0.5 - 0.3
    report = fit_alignment(
        aligner,
        src_slot=0,
        dst_slot=1,
        src_acts=src_base,
        tgt_acts=tgt_base,
        steps=300,
        lr=5e-3,
    )
    d = report.as_dict()
    assert d["coral"] <= d["initial_coral"] + 1e-6, d
    assert d["mean_loss"] <= d["initial_mean_loss"] + 1e-6, d
    return d


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--iters", type=int, default=6)
    ap.add_argument("--episodes", type=int, default=4)
    ap.add_argument("--layers", type=int, default=6)
    ap.add_argument("--max-path-len", type=int, default=4)
    ap.add_argument("--min-path-len", type=int, default=1)
    ap.add_argument("--budget", type=int, default=64)
    ap.add_argument("--out", default="")
    args = ap.parse_args()
    device = torch.device(args.device)

    models, config = make_tiny_models(layers=args.layers)
    pool = ModelLayerPool(
        names=["m0", "m1", "m2"],
        num_layers=[args.layers] * 3,
        hidden_dims=[config.hidden_size] * 3,
    )
    constraints = PathConstraints(
        max_path_len=int(args.max_path_len),
        min_path_len=int(args.min_path_len),
        allow_alignment=True,
        no_repeat_actions=True,
    )
    scorer, preference, calls = make_synthetic_scorer(pool, TASKS)
    weights = {"translation": 0.5, "math": 0.3, "code": 0.2}
    reward_fn = RewardFn(RewardConfig(mode="weighted_sum", beta=0.01), TASKS)
    env = LayerPathEnv(pool, constraints, scorer, reward_fn, weights, cache_size=4096)

    # ---------------------------------------------------------------- A5 check
    probe = [0, pool.max_layers + 1]
    scores = scorer(probe)
    bd = reward_fn(scores, weights, path_len=len(probe))
    expected = weighted_sum_reward(
        [scores[t] for t in TASKS], [weights[t] for t in TASKS], len(probe), beta=0.01
    )
    assert abs(bd.reward - expected) < 1e-9, (bd.reward, expected)
    print(f"[reward] weighted-sum reward = {bd.reward:.6f} == {expected:.6f}")

    # ---------------------------------------------------------------- A6 check
    fit_report = check_alignment(device)
    print(f"[alignment] coral {fit_report['initial_coral']:.5f} -> {fit_report['coral']:.5f}, "
          f"mean {fit_report['initial_mean_loss']:.5f} -> {fit_report['mean_loss']:.5f}")

    # ---------------------------------------------------------- A1/A2/A3 setup
    signature_table, sig_dim = build_signature_table(models, pool.max_layers, proj_dim=16)
    net = ActorCritic(
        PolicyConfig(
            num_models=pool.num_models,
            max_layers=pool.max_layers,
            signature_dim=sig_dim,
            hidden_dim=64,
            token_dim=32,
            action_dim=32,
            gru_layers=1,
        )
    )
    net.set_signature_table(signature_table)
    embedding = ActionEmbedding(
        num_actions=pool.num_actions, dim=32, num_models=pool.num_models, max_layers=pool.max_layers
    )
    mapper = WolpertingerMapper(
        embedding, WolpertingerConfig(k=8, tau=0.2, q_tau=0.2, score_mode="mixed")
    )
    agent = PPOAgent(
        net=net,
        mapper=mapper,
        pool=pool,
        constraints=constraints,
        cfg=PPOConfig(
            gamma=0.99,
            lam=0.95,
            lr=3e-3,
            update_epochs=2,
            minibatch_episodes=2,
            ent_coef=0.02,
            eps_start=1.0,
            eps_end=0.1,
            eps_decay_iters=max(1, args.iters // 2),
            seed=7,
        ),
        device=device,
    )
    print(f"[init] policy params={net.count_parameters():,}")

    lengths: List[int] = []
    off_diagonal = 0
    rewards: List[float] = []
    feasible_violations = 0
    for it in range(1, int(args.iters) + 1):
        episodes = agent.collect_episodes(env, int(args.episodes))
        for ep in episodes:
            lengths.append(len(ep.path))
            rewards.append(ep.reward)
            for t, action in enumerate(ep.path):
                m, l = decode_path([action], pool.max_layers)[0]
                if l != t:
                    off_diagonal += 1
                mask = feasible_mask(pool, ep.path[:t], constraints)
                if not mask[action]:
                    feasible_violations += 1
        agent.compute_gae(episodes)
        stats = agent.update(episodes)
        print(
            f"[iter {it}] best={max(e.reward for e in episodes):.5f} "
            f"avg={np.mean([e.reward for e in episodes]):.5f} "
            f"pi={stats.get('policy_loss', 0):+.4f} v={stats.get('value_loss', 0):.4f} "
            f"H={stats.get('entropy', 0):.4f} kl={stats.get('approx_kl', 0):+.5f}"
        )

    greedy = agent.greedy_rollout(env)
    print(f"[greedy] path={greedy.path} length={len(greedy.path)} reward={greedy.reward:.6f}")
    print(f"[path-length] observed: {sorted(set(lengths))} (min={min(lengths)}, max={max(lengths)})")
    print(f"[action-space] steps with l != t: {off_diagonal}")
    print(f"[feasibility] violations: {feasible_violations}; scorer calls={calls['n']}")
    assert feasible_violations == 0, "an infeasible action was executed"
    assert off_diagonal > 0, "layer indices are still forced to equal the step index (A3 not fixed)"
    assert len(set(lengths)) > 1, "path length never varied (A4 not fixed)"
    assert max(lengths) <= constraints.max_path_len

    # ------------------------------------------------------- assembly check
    merged = build_merged_model(models, pool, greedy.path)
    assert merged.config.num_hidden_layers == len(greedy.path)
    ids = torch.randint(0, config.vocab_size, (1, 8))
    with torch.no_grad():
        out = merged(ids)
    assert out.logits.shape[0] == 1
    print(f"[assemble] ok: depth={merged.config.num_hidden_layers}, logits={tuple(out.logits.shape)}")

    # ---------------------------------------------------- multi-objective check
    points = []
    for ep in [greedy]:
        row = [ep.scores.get(t) for t in TASKS]
        if all(v is not None for v in row):
            points.append([float(v) for v in row])
    points.append([0.5, 0.4, 0.3])
    report = pareto_report(points, margin=0.05)
    print(f"[pareto] HV={report.hypervolume:.6f} front={report.indices}")
    assert report.hypervolume >= 0.0

    if args.out:
        os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(
                {
                    "lengths": lengths,
                    "rewards": rewards,
                    "off_diagonal_steps": off_diagonal,
                    "greedy_path": greedy.path,
                    "alignment": fit_report,
                    "hypervolume": report.hypervolume,
                },
                fh,
                indent=2,
            )
    print("SMOKE TEST PASSED")


if __name__ == "__main__":
    main()
