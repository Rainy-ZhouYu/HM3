"""Isolate the 'later evaluation in the same process' failure.

Scores several assembled models in one process, alternating between reusing a
single ``LmEvalScorer`` and creating a fresh one, to find out which of the two
triggers the causal-mask mismatch seen during a training run.
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from hm3.actions import ModelLayerPool
from hm3.alignment import AlignmentMLP, collect_activation_stats
from hm3.assemble import build_merged_model
from hm3.scoring import LmEvalScorer


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Math-1.5B")
    ap.add_argument("--base-model", default="Qwen/Qwen2.5-1.5B")
    ap.add_argument("--extra-model", required=True)
    ap.add_argument("--task", default="gsm8k_platinum_cot")
    ap.add_argument("--limit", type=float, default=0.002)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--batch-size", type=int, default=2)
    ap.add_argument("--paths", default="0,29;56,3;57,30;0,58")
    ap.add_argument("--fit-steps", type=int, default=0, help="fit the aligner for N steps first")
    args = ap.parse_args()

    device = torch.device(args.device)
    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    model_paths = [p.strip() for p in args.models.split(",")] + [args.extra_model]
    models = [
        AutoModelForCausalLM.from_pretrained(p, dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()
        for p in model_paths
    ]
    pool = ModelLayerPool(
        names=[f"m{i}" for i in range(len(models))],
        num_layers=[int(m.config.num_hidden_layers) for m in models],
        hidden_dims=[int(m.config.hidden_size) for m in models],
    )
    batch = tokenizer("Merging models.", return_tensors="pt", truncation=True, max_length=16)
    batch = {k: v.to(device) for k, v in batch.items()}
    stats = collect_activation_stats(models, batch, pool.max_layers, device)
    aligner = AlignmentMLP(stats, hidden_dim=64, max_layers=pool.max_layers,
                           num_models=pool.num_models).to(device)
    if args.fit_steps > 0:
        from hm3.alignment import fit_alignment

        with torch.no_grad():
            acts = []
            for model in models:
                model.to(device)
                out = model(**batch, output_hidden_states=True)
                acts.append(
                    torch.stack([h.float() for h in out.hidden_states[1 : pool.max_layers + 1]]).cpu()
                )
                model.to("cpu")
        src = acts[0][0].reshape(-1, stats.mean.shape[1])
        tgt = acts[1][1].reshape(-1, stats.mean.shape[1])
        rep = fit_alignment(aligner, stats.slot(0, 0), stats.slot(1, 1), src, tgt,
                            steps=int(args.fit_steps))
        print(f"[fit] coral {rep.initial_coral:.4f} -> {rep.coral:.4f}", flush=True)

    shared = LmEvalScorer(tasks=[args.task], limit=args.limit,
                          batch_size=args.batch_size, device=args.device)
    paths = [[int(x) for x in chunk.split(",") if x.strip()] for chunk in args.paths.split(";")]
    scenarios = ["shared" if i % 2 == 0 else "fresh" for i in range(len(paths))]

    for path, scenario in zip(paths, scenarios):
        scorer = shared if scenario == "shared" else LmEvalScorer(
            tasks=[args.task], limit=args.limit, batch_size=args.batch_size, device=args.device
        )
        label = f"{scenario} scorer, path={path}"
        try:
            model = build_merged_model(models, pool, path, aligner, "always").to(device)
            result = scorer.evaluate_in_memory(model, tokenizer)
            print(f"[PASS] {label}: {result.scores}", flush=True)
            del model
            torch.cuda.empty_cache()
        except Exception as exc:  # noqa: BLE001
            print(f"[FAIL] {label}: {type(exc).__name__}: {str(exc)[:160]}", flush=True)
            torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
