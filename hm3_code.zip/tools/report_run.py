"""Build the figures / summary for one HM3 run directory.

    python tools/report_run.py --run-dir runs/my_run

Produces ``<run-dir>/report/`` with per-subproblem reward curves, a Pareto plot
and a ``summary.json``.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hm3.reporting import summarize_run


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--out-dir", default="")
    args = ap.parse_args()
    summary = summarize_run(args.run_dir, args.out_dir or None)
    print(json.dumps({k: v for k, v in summary.items() if k != "figures"}, ensure_ascii=False, indent=2))
    for fig in summary["figures"]:
        print("figure:", fig)


if __name__ == "__main__":
    main()
