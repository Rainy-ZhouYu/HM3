"""Verify the two code paths that a search-only run does not touch.

1. parameter-level merge through mergekit  -> ``merge_upper.run_parameter_merges``
2. alignment MLP on real hidden states -> activation stats,
   merged-model assembly with ``AlignmentWrapper`` and a real forward pass

Both are exercised on real cached Qwen models but with a 2-layer path, so the
test costs a few minutes instead of hours.

    python tools/check_real_paths.py --models Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Math-1.5B
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from hm3.actions import ModelLayerPool, PathConstraints, alignment_sites, feasible_mask
from hm3.alignment import AlignmentMLP, AlignmentWrapper, collect_activation_stats, fit_alignment
from hm3.assemble import build_merged_model, save_merged_model
from hm3.merge_upper import run_parameter_merges, successful_paths
from hm3.reporting import moment_report, plot_moment_report
from hm3.weights import build_merge_weight_plan


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Math-1.5B")
    ap.add_argument("--base-model", default="Qwen/Qwen2.5-1.5B")
    ap.add_argument("--out-root", default="runs/check_real_paths")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--dtype", default="bfloat16")
    ap.add_argument("--alignment-steps", type=int, default=50)
    ap.add_argument("--alignment-rank", type=int, default=0, help="0 = diagonal only, e.g. 16/32 for low-rank")
    ap.add_argument("--skip-merge", action="store_true")
    args = ap.parse_args()

    models = [m.strip() for m in args.models.split(",") if m.strip()]
    os.makedirs(args.out_root, exist_ok=True)
    dtype = getattr(torch, args.dtype)
    report = {}

    # ------------------------------------------------------- 1) parameter merge
    if not args.skip_merge:
        t0 = time.time()
        plan = build_merge_weight_plan(
            tasks=["xnli", "gsm8k_platinum_cot"],
            task_weights={"xnli": 0.7, "gsm8k_platinum_cot": 0.3},
            models=models,
            task_to_model={"xnli": 0, "gsm8k_platinum_cot": 1},
        )
        result = run_parameter_merges(
            plan=plan,
            merge_methods=["dare_ties"],
            output_root=os.path.join(args.out_root, "upper_pool"),
            setting_dir=os.path.join(args.out_root, "setting"),
            base_model=args.base_model,
            density=1.0,
            combination_sizes=[2],
        )
        index = result["index"]
        ok = [r for r in index["runs"] if r["status"] == "success"]
        print(f"[merge] model_weights={index['model_weights']} runs={len(index['runs'])} ok={len(ok)} "
              f"({time.time() - t0:.0f}s)", flush=True)
        for run in index["runs"]:
            print(f"[merge] {run['status']}: {run['out_path']}")
        report["merge"] = {
            "index_path": result["index_path"],
            "model_weights": index["model_weights"],
            "statuses": [r["status"] for r in index["runs"]],
            "merged_paths": [r["out_path"] for r in ok],
        }
        extra_paths = [r["out_path"] for r in ok]
    else:
        extra_paths = []

    # ------------------------------------------------- 2) real alignment path
    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    loaded = []
    for path in extra_paths + models:
        model = AutoModelForCausalLM.from_pretrained(path, dtype=dtype, low_cpu_mem_usage=True)
        model.eval()
        loaded.append(model)
    print(f"[load] {len(loaded)} models (incl. {len(extra_paths)} merged)", flush=True)

    pool = ModelLayerPool(
        names=[os.path.basename(p.rstrip("/")) for p in extra_paths + models],
        num_layers=[int(m.config.num_hidden_layers) for m in loaded],
        hidden_dims=[int(m.config.hidden_size) for m in loaded],
    )
    device = torch.device(args.device)
    batch = tokenizer(
        "Model merging combines several fine-tuned models into one.",
        return_tensors="pt",
        truncation=True,
        max_length=32,
    )
    batch = {k: v.to(device) for k, v in batch.items()}

    t0 = time.time()
    stats = collect_activation_stats(loaded, batch, pool.max_layers, device)
    print(f"[alignment] stats collected for {stats.mean.shape} in {time.time() - t0:.0f}s", flush=True)
    aligner = AlignmentMLP(
        stats,
        hidden_dim=64,
        max_layers=pool.max_layers,
        num_models=pool.num_models,
        rank=int(args.alignment_rank),
    ).to(device)

    # ---- real activations of the first junction (model 0 layer 0 -> model 1 layer 1)
    acts = []
    with torch.no_grad():
        for model in loaded:
            model.to(device)
            out = model(**batch, output_hidden_states=True)
            acts.append(
                torch.stack([h.float() for h in out.hidden_states[1 : pool.max_layers + 1]])
                .reshape(pool.max_layers, -1, stats.mean.shape[1])
                .cpu()
            )
            model.to("cpu")
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
    src_acts = acts[0][0]
    tgt_acts = acts[1][1]
    fit = fit_alignment(aligner, src_slot=stats.slot(0, 0), dst_slot=stats.slot(1, 1),
                        src_acts=src_acts, tgt_acts=tgt_acts, steps=int(args.alignment_steps))
    print(f"[alignment] fit: coral {fit.initial_coral:.5f} -> {fit.coral:.5f}, "
          f"mean {fit.initial_mean:.5f} -> {fit.mean:.5f}", flush=True)

    def _align(z):
        zt = torch.as_tensor(z, dtype=torch.float32, device=device)
        idx = torch.zeros(zt.shape[0], dtype=torch.long, device=device)
        with torch.no_grad():
            mapped = aligner.transform(
                zt,
                torch.full_like(idx, stats.slot(0, 0)),
                torch.full_like(idx, stats.slot(1, 1)),
                idx,
            )
        return mapped.cpu().numpy()

    moments = moment_report(src_acts.numpy(), tgt_acts.numpy(), align_fn=_align)
    print(f"[alignment] moments: mean_l2 {moments.mean_l2_before:.4f} -> {moments.mean_l2_after:.4f}, "
          f"cov_fro {moments.cov_fro_before:.4f} -> {moments.cov_fro_after:.4f}, "
          f"var_ratio {moments.variance_ratio_before:.4f} -> {moments.variance_ratio_after:.4f}",
          flush=True)
    plot_moment_report({"junction 0:0 -> 1:1": moments},
                       os.path.join(args.out_root, "alignment_moments.png"))
    report["alignment"] = {**fit.as_dict(), **moments.as_dict(), **moments.improvement()}

    # --------------------------------------------------- 3) assembly + forward
    path = [0, pool.max_layers + 1]     # model0:L0 then model1:L1  (2 layers)
    constraints = PathConstraints(max_path_len=4, min_path_len=1, allow_alignment=True)
    print(f"[path] feasible={[bool(x) for x in feasible_mask(pool, [], constraints)][:3]}...  "
          f"alignment sites={alignment_sites(path, pool, 'always')}", flush=True)
    merged = build_merged_model(loaded, pool, path, aligner, alignment_mode="always").to(device)
    print(f"[assemble] depth={merged.config.num_hidden_layers} "
          f"types={[type(merged.model.layers[i]).__name__ for i in range(len(merged.model.layers))]}", flush=True)
    ids = batch["input_ids"]
    with torch.no_grad():
        out = merged(ids)
    print(f"[forward] logits={tuple(out.logits.shape)} finite={bool(torch.isfinite(out.logits).all())}", flush=True)
    assert torch.isfinite(out.logits).all(), "non-finite logits from the aligned merged model"

    saved = save_merged_model(merged, os.path.join(args.out_root, "merged_2layer"),
                              tokenizer=tokenizer, path=path, pool=pool, dtype=dtype)
    print(f"[save] {saved}", flush=True)
    report["assembly"] = {"depth": int(merged.config.num_hidden_layers), "path": path,
                          "layer_types": [type(m).__name__ for m in merged.model.layers]}

    with open(os.path.join(args.out_root, "check_report.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)
    print("CHECK PASSED")


if __name__ == "__main__":
    main()
