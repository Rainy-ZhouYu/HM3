"""Diagnose in-memory lm-eval scoring of an assembled model.

Tests the cross product of
    alignment  : on / off
    attention  : sdpa / eager
    batch size : 1 / 2

on a real 2-layer assembled Qwen model, so we can pick the configuration that
actually works on the GPU instead of guessing.

    python tools/diag_eval.py --task gsm8k_platinum_cot
"""

from __future__ import annotations

import argparse
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from hm3.actions import ModelLayerPool
from hm3.alignment import AlignmentMLP, ActivationStats, collect_activation_stats
from hm3.assemble import build_merged_model
from hm3.scoring import LmEvalScorer


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Math-1.5B")
    ap.add_argument("--base-model", default="Qwen/Qwen2.5-1.5B")
    ap.add_argument("--task", default="gsm8k_platinum_cot")
    ap.add_argument("--limit", type=float, default=0.001)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--path", default="0,29")
    ap.add_argument(
        "--extra-model",
        default="",
        help="optional third candidate (e.g. the parameter-level merged model) appended to the pool",
    )
    ap.add_argument("--paths", default="", help="semicolon separated list of paths, overrides --path")
    ap.add_argument("--attention", default="eager,sdpa")
    ap.add_argument("--batch-sizes", default="2")
    ap.add_argument(
        "--repeat-random",
        type=int,
        default=0,
        help="instead of the matrix, run N sequential evaluations with random 2-layer paths "
        "(reproduces the training-loop pattern)",
    )
    args = ap.parse_args()

    device = torch.device(args.device)
    paths = [int(x) for x in args.path.split(",")]
    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    model_paths = [p.strip() for p in args.models.split(",")]
    if args.extra_model:
        model_paths.append(args.extra_model.strip())
    models = [
        AutoModelForCausalLM.from_pretrained(p.strip(), dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()
        for p in model_paths
    ]
    pool = ModelLayerPool(
        names=[f"m{i}" for i in range(len(models))],
        num_layers=[int(m.config.num_hidden_layers) for m in models],
        hidden_dims=[int(m.config.hidden_size) for m in models],
    )
    batch = tokenizer("Merging models.", return_tensors="pt", truncation=True, max_length=16)
    batch = {k: v.to(device) for k, v in batch.items()}
    stats = collect_activation_stats(models, batch, pool.max_layers, device)
    aligner = AlignmentMLP(stats, hidden_dim=64, max_layers=pool.max_layers,
                           num_models=pool.num_models).to(device)

    results = []
    attentions = [a.strip() for a in args.attention.split(",") if a.strip()]
    batch_sizes = [int(b) for b in args.batch_sizes.split(",") if b.strip()]
    if args.repeat_random:
        import random

        rng = random.Random(0)
        for i in range(int(args.repeat_random)):
            path = [
                rng.randrange(pool.num_models) * pool.max_layers + rng.randrange(pool.max_layers)
                for _ in range(2)
            ]
            label = f"random#{i} path={path}"
            try:
                model = build_merged_model(
                    models, pool, path, aligner, "always", attn_implementation="eager"
                ).to(device)
                scorer = LmEvalScorer(
                    tasks=[args.task], limit=args.limit, batch_size=batch_sizes[0],
                    device=args.device,
                )
                result = scorer.evaluate_in_memory(model, tokenizer)
                print(f"[PASS] {label}: {result.scores}", flush=True)
                results.append((label, True, str(result.scores)))
                del model
                torch.cuda.empty_cache()
            except Exception as exc:  # noqa: BLE001
                print(f"[FAIL] {label}: {type(exc).__name__}: {str(exc)[:200]}", flush=True)
                results.append((label, False, str(exc)[:200]))
                torch.cuda.empty_cache()
        print("\n=== summary ===")
        for label, ok, msg in results:
            print(f"{'PASS' if ok else 'FAIL'}  {label}")
        return

    if args.paths:
        path_list = [[int(x) for x in chunk.split(",") if x.strip()] for chunk in args.paths.split(";")]
    else:
        path_list = [paths]
    for path in path_list:
        for use_align in (False, True):
            for attn in attentions:
                for bs in batch_sizes:
                    label = f"path={path} align={int(use_align)} attn={attn} bs={bs}"
                    try:
                        model = build_merged_model(
                            models, pool, path,
                            aligner if use_align else None,
                            "always" if use_align else "never",
                            attn_implementation=attn,
                        ).to(device)
                        scorer = LmEvalScorer(
                            tasks=[args.task], limit=args.limit, batch_size=bs,
                            device=args.device,
                        )
                        result = scorer.evaluate_in_memory(model, tokenizer)
                        msg = f"OK scores={result.scores}"
                        ok = True
                        del model
                        torch.cuda.empty_cache()
                    except Exception as exc:  # noqa: BLE001
                        msg = f"{type(exc).__name__}: {str(exc)[:120]}"
                        ok = False
                        torch.cuda.empty_cache()
                    results.append((label, ok, msg))
                    print(f"[{ 'PASS' if ok else 'FAIL' }] {label}: {msg}", flush=True)

    print("\n=== summary ===")
    for label, ok, msg in results:
        print(f"{'PASS' if ok else 'FAIL'}  {label}")


if __name__ == "__main__":
    main()
