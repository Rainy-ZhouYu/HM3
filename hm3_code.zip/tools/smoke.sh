#!/usr/bin/env bash
# HM3 one-shot smoke test.
#
#   STAGES=units,tiny,real  bash tools/smoke.sh
#
# Stages
#   units : numpy unit tests (no GPU, no downloads)
#   tiny  : tiny random models + synthetic scorer, full PPO loop on GPU
#   real  : real Qwen candidates, 1 preference vector, 1 iteration,
#           parameter merge skipped, alignment fitted with few steps
#
# Environment knobs
#   PY            python interpreter (default: the model_merge_v2 env)
#   GPU           which physical GPU to use (default: 0)
#   RUN_ROOT      where the real-stage run is written
#   STAGES        comma separated subset of units,tiny,real
set -euo pipefail

cd "$(dirname "$0")/.."
PY="${PY:-python}"
GPU="${GPU:-0}"
RUN_ROOT="${RUN_ROOT:-runs/smoke_$(date +%Y%m%d-%H%M%S)}"
STAGES="${STAGES:-units,tiny,real}"
TASK="${TASK:-gsm8k_platinum_cot}"
TINY_ITERS="${TINY_ITERS:-6}"
REAL_ITERS="${REAL_ITERS:-1}"

want() { [[ ",${STAGES}," == *",$1,"* ]]; }
hr() { printf '\n=== %s ===\n' "$1"; }

echo "python : ${PY}"
echo "gpu    : ${GPU}"
echo "stages : ${STAGES}"
echo "run    : ${RUN_ROOT}"

if want units; then
  hr "units: numpy unit tests"
  for t in tests/*.py; do
    echo "-- $t"
    "${PY}" "$t"
  done
fi

if want tiny; then
  hr "tiny: end-to-end on tiny random models"
  CUDA_VISIBLE_DEVICES="${GPU}" "${PY}" -u tools/smoke_test_tiny.py \
    --device cuda --iters "${TINY_ITERS}" --episodes 4 \
    --out "${RUN_ROOT}/tiny_smoke.json"
fi

if want real; then
  hr "real: Qwen candidates, 1 subproblem, ${REAL_ITERS} iteration(s)"
  CUDA_VISIBLE_DEVICES="${GPU}" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 "${PY}" -u -m hm3.train \
    --candidates Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Math-1.5B \
    --base-model Qwen/Qwen2.5-1.5B \
    --tasks "${TASK}" \
    --task-to-model "${TASK}=0" \
    --subproblems 1 --max-iters "${REAL_ITERS}" --episodes-per-iter 1 \
    --update-epochs 1 --minibatch-episodes 1 \
    --max-path-len 2 --min-path-len 1 \
    --search-limit 0.002 --batch-size 1 \
    --alignment-mode always --fit-alignment --alignment-steps 5 \
    --skip-parameter-merge \
    --wolp-k 8 --reward-mode weighted_sum --train-mode online \
    --output-root "${RUN_ROOT}" --run-name real_smoke
  hr "real: report"
  "${PY}" tools/report_run.py --run-dir "${RUN_ROOT}/real_smoke"
fi

hr "SMOKE OK"
