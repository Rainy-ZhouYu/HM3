"""Compare the three training recipes on the same tiny task.

Runs the tiny synthetic setup for each mode (``online`` / ``prior_bc`` /
``replay``) and draws the reward curves next to each other.  Uses the same
environment as the smoke test, so it needs no model downloads.

    python tools/compare_modes.py --iters 12 --episodes 4 --out runs/compare_modes
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import torch

from hm3.actions import ModelLayerPool, PathConstraints
from hm3.env import LayerPathEnv
from hm3.policy import ActorCritic, PolicyConfig
from hm3.ppo import PPOAgent, PPOConfig, Episode
from hm3.reporting import plot_episode_rewards
from hm3.reward import RewardConfig, RewardFn
from hm3.signatures import build_signature_table
from hm3.wolpertinger import ActionEmbedding, WolpertingerConfig, WolpertingerMapper
from tools.smoke_test_tiny import TASKS, make_synthetic_scorer, make_tiny_models


def build(args):
    models, config = make_tiny_models(layers=args.layers)
    pool = ModelLayerPool(
        names=["m0", "m1", "m2"],
        num_layers=[args.layers] * 3,
        hidden_dims=[config.hidden_size] * 3,
    )
    constraints = PathConstraints(max_path_len=args.max_path_len, min_path_len=1)
    scorer, _pref, calls = make_synthetic_scorer(pool, TASKS)
    weights = {"translation": 0.5, "math": 0.3, "code": 0.2}
    reward_fn = RewardFn(RewardConfig(mode="weighted_sum", beta=0.01), TASKS)
    env = LayerPathEnv(pool, constraints, scorer, reward_fn, weights)
    signature_table, sig_dim = build_signature_table(models, pool.max_layers, proj_dim=16)
    net = ActorCritic(
        PolicyConfig(
            num_models=pool.num_models, max_layers=pool.max_layers, signature_dim=sig_dim,
            hidden_dim=64, token_dim=32, action_dim=32,
        )
    )
    net.set_signature_table(signature_table)
    embedding = ActionEmbedding(
        num_actions=pool.num_actions, dim=32, num_models=pool.num_models, max_layers=pool.max_layers
    )
    mapper = WolpertingerMapper(embedding, WolpertingerConfig(k=8, tau=0.2, q_tau=0.2))
    agent = PPOAgent(
        net=net, mapper=mapper, pool=pool, constraints=constraints,
        cfg=PPOConfig(lr=3e-3, update_epochs=2, minibatch_episodes=2, ent_coef=0.02,
                      eps_start=1.0, eps_end=0.1, eps_decay_iters=max(1, args.iters // 2), seed=7,
                      target_kl=0.0),
        device=torch.device(args.device),
    )
    return agent, env, pool, constraints, scorer, reward_fn, weights, models


def run_mode(args, mode: str):
    agent, env, pool, constraints, scorer, reward_fn, weights, models = build(args)
    prior_reward = None
    if mode in ("prior_bc", "replay"):
        priors = []
        for m in range(pool.num_models):
            pure = [m * pool.max_layers + l for l in range(pool.num_layers[m])][: constraints.max_path_len]
            scores = scorer(pure)
            breakdown = reward_fn(scores, weights, len(pure))
            priors.append(
                Episode(
                    actions=list(pure), path=list(pure), stopped=False,
                    reward=float(breakdown.reward),
                    scores={k: float(v) for k, v in scores.items() if v is not None},
                    z=np.zeros((len(pure), 32), dtype=np.float32),
                    logp=np.zeros(len(pure), dtype=np.float32),
                    values=np.zeros(len(pure), dtype=np.float32),
                    source="prior",
                )
            )
        if mode == "prior_bc":
            agent.behavior_clone(priors, epochs=args.bc_epochs)
        if mode == "replay":
            agent.cfg.replay_ratio = float(args.replay_ratio)
            agent.cfg.replay_value_coef = 1.0
            agent.cfg.replay_bc_coef = float(args.replay_bc_coef)
            agent.set_prior_replay(priors)
        prior_reward = max(ep.reward for ep in priors)
    rewards, kls = [], []
    n_replay = 0.0
    for _ in range(int(args.iters)):
        episodes = agent.collect_episodes(env, int(args.episodes))
        agent.compute_gae(episodes)
        stats = agent.update(episodes)
        rewards.extend(float(ep.reward) for ep in episodes)
        kls.append(float(stats.get("approx_kl", 0.0)))
        n_replay = float(stats.get("n_replay", n_replay))
    return rewards, kls, prior_reward, agent.greedy_rollout(env).reward, n_replay


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--iters", type=int, default=12)
    ap.add_argument("--episodes", type=int, default=4)
    ap.add_argument("--layers", type=int, default=6)
    ap.add_argument("--max-path-len", type=int, default=4)
    ap.add_argument("--bc-epochs", type=int, default=50)
    ap.add_argument("--replay-ratio", type=float, default=0.5)
    ap.add_argument("--replay-bc-coef", type=float, default=1.0)
    ap.add_argument("--modes", default="online,prior_bc,replay")
    ap.add_argument("--out", default="runs/compare_modes")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    results = {}
    for mode in [m.strip() for m in args.modes.split(",") if m.strip()]:
        rewards, kls, prior_reward, greedy, n_replay = run_mode(args, mode)
        results[mode] = {
            "rewards": rewards,
            "mean_kl": float(np.mean(kls)) if kls else 0.0,
            "best": float(np.max(rewards)) if rewards else float("-inf"),
            "final_greedy": float(greedy),
            "prior_reward": prior_reward,
            "first_iter_policy_kl": kls[0] if kls else 0.0,
            "prior_replayed_per_update": n_replay,
        }
        print(f"[{mode:9s}] best={results[mode]['best']:.5f} greedy={greedy:.5f} "
              f"mean_kl={results[mode]['mean_kl']:+.4f} prior={prior_reward} "
              f"replay/update={n_replay:.1f}")

    fig = plot_episode_rewards(
        {mode: results[mode]["rewards"] for mode in results},
        os.path.join(args.out, "mode_comparison.png"),
        title="HM3 architecture search: training recipes",
        xlabel="episode",
        ylabel="reward",
    )
    with open(os.path.join(args.out, "comparison.json"), "w", encoding="utf-8") as fh:
        json.dump(results, fh, ensure_ascii=False, indent=2)
    print("figure:", fig)


if __name__ == "__main__":
    main()
