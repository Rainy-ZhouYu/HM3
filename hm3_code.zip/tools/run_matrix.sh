#!/usr/bin/env bash
# Launch sharded HM3 subproblems, one process per (preference-vector index, GPU).
#
#   PAIRS="0:0 1:1 2:2" MODE=online ITERS=35 bash tools/run_matrix.sh
#
# PAIRS entries are "<subproblem-index>:<gpu>".  Each process solves exactly one
# preference vector (the subproblems are independent, so they can be solved in
# parallel), writes its own run directory, and afterwards
# tools/merge_pareto.py pools the solutions.
#
# Environment knobs
#   PAIRS    required, e.g. "0:0 1:1 2:2"
#   MODE     online | prior_bc           (default online)
#   ITERS    search iterations          (default 35)
#   PREFIX   run-name prefix            (default matrix_<MODE>)
#   TASKS    objective list             (default xnli_en,gsm8k_platinum_cot,mathqa)
#   L        28 (fixed: one source layer per position, full depth)
set -euo pipefail

cd "$(dirname "$0")/.."
PY="${PY:-python}"
PAIRS="${PAIRS:?set PAIRS=\"0:0 1:1 ...\"}"
MODE="${MODE:-online}"
ITERS="${ITERS:-35}"
PREFIX="${PREFIX:-matrix_${MODE}}"
TASKS="${TASKS:-xnli_en,gsm8k_platinum_cot,mathqa}"
TASK_MAP="${TASK_MAP:-xnli_en=0,gsm8k_platinum_cot=2,mathqa=2}"

if [[ "${MODE}" == "prior_bc" ]]; then
  MODE_FLAGS="--train-mode prior_bc --prior-bc-epochs 30"
else
  MODE_FLAGS="--train-mode online"
fi

echo "mode=${MODE} iters=${ITERS} tasks=${TASKS}"
mkdir -p logs
for pair in ${PAIRS}; do
  idx="${pair%%:*}"
  gpu="${pair##*:}"
  name="${PREFIX}_s${idx}"
  rm -rf "runs/${name}"
  echo "launch ${name} on GPU ${gpu}"
  nohup env CUDA_VISIBLE_DEVICES="${gpu}" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 "${PY}" -u -m hm3.train \
    --candidates Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Coder-1.5B,Qwen/Qwen2.5-Math-1.5B \
    --base-model Qwen/Qwen2.5-1.5B \
    --tasks "${TASKS}" --task-to-model "${TASK_MAP}" \
    --subproblems 5 --subproblem-indices "${idx}" \
    --max-iters "${ITERS}" --episodes-per-iter 1 --update-epochs 2 --minibatch-episodes 1 \
    --min-path-len 28 --max-path-len 28 \
    --search-limit 0.005 --batch-size 1 \
    --alignment-mode always --fit-alignment --alignment-steps 10 \
    --merge-methods dare_ties --merge-combination-sizes 3 --density 1.0 \
    --wolp-k 16 --reward-mode weighted_sum \
    ${MODE_FLAGS} \
    --output-root runs --run-name "${name}" \
    > "logs/${name}.log" 2>&1 &
  echo "  pid=$!"
done
wait
echo "all shards finished"
