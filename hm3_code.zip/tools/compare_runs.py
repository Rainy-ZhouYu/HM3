"""Compare several HM3 runs: reward curves + solution table + one figure.

    python tools/compare_runs.py --runs runs/pilot_a_align runs/pilot_b_noalign \
        --labels align=always align=never --out runs/pilot_compare.png
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hm3.reporting import load_episodes, plot_episode_rewards, running_best


def collect(run_dir: str):
    episodes = []
    for name in sorted(os.listdir(run_dir)):
        sub = os.path.join(run_dir, name)
        if name.startswith("pref_") and os.path.isdir(sub):
            episodes.extend(load_episodes(os.path.join(sub, "episodes.jsonl")))
    rewards = [float(e.get("reward", 0.0)) for e in episodes]
    solutions = []
    for name in sorted(os.listdir(run_dir)):
        path = os.path.join(run_dir, name, "solution.json")
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as fh:
                solutions.append(json.load(fh))
    return rewards, solutions


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", nargs="+", required=True)
    ap.add_argument("--labels", nargs="*", default=None)
    ap.add_argument("--out", default="runs/run_compare.png")
    ap.add_argument("--title", default="HM3 architecture search")
    args = ap.parse_args()

    labels = args.labels or [os.path.basename(r.rstrip("/")) for r in args.runs]
    series = {}
    print(f"{'run':<28} {'episodes':>8} {'best':>8} {'greedy':>8}  best scores")
    for run_dir, label in zip(args.runs, labels):
        rewards, solutions = collect(run_dir)
        if not rewards:
            print(f"{label:<28} (no episodes)")
            continue
        best = max(s["best_reward"] for s in solutions) if solutions else max(rewards)
        greedy = solutions[0].get("greedy_reward") if solutions else None
        scores = solutions[0].get("best_scores", {}) if solutions else {}
        series[label] = rewards
        greedy_txt = "-" if greedy is None else f"{greedy:.4f}"
        print(
            f"{label:<28} {len(rewards):>8} {best:>8.4f} {greedy_txt:>8}  "
            + ", ".join(f"{k}={v:.4f}" for k, v in scores.items())
        )

    if series:
        fig = plot_episode_rewards(
            series, args.out, title=args.title, xlabel="episode", ylabel="reward"
        )
        print("figure:", fig)


if __name__ == "__main__":
    main()
