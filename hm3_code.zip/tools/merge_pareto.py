"""Pool the solutions of several (sharded) run directories into one Pareto report.

When the N preference vectors are solved in parallel with ``--subproblem-indices``
each process only knows its own subproblem, so the multi-objective bookkeeping
(dominance + hypervolume) has to be done afterwards across the run directories:

    python tools/merge_pareto.py --runs runs/shard_0 runs/shard_1 runs/shard_2 \
        --out runs/pareto_shards

Writes ``pareto.json`` and, for 2D/3D objective spaces, a figure.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hm3.metrics import pareto_front_indices, pareto_report
from hm3.reporting import plot_pareto


def collect_solutions(run_dirs):
    solutions = []
    tasks = None
    for run_dir in run_dirs:
        manifest_path = os.path.join(run_dir, "manifest.json")
        if os.path.isfile(manifest_path):
            with open(manifest_path, "r", encoding="utf-8") as fh:
                manifest = json.load(fh)
            tasks = tasks or manifest.get("tasks")
        for name in sorted(os.listdir(run_dir)):
            sub_dir = os.path.join(run_dir, name)
            if not (name.startswith("pref_") and os.path.isdir(sub_dir)):
                continue
            path = os.path.join(sub_dir, "solution.json")
            if not os.path.isfile(path):
                continue
            with open(path, "r", encoding="utf-8") as fh:
                solution = json.load(fh)
            solution["_run_dir"] = run_dir
            solution["_label"] = f"{os.path.basename(run_dir.rstrip('/'))}:{name}"
            solutions.append(solution)
    return solutions, tasks or []


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", nargs="+", required=True)
    ap.add_argument("--tasks", default="", help="override the objective order")
    ap.add_argument("--margin", type=float, default=0.05)
    ap.add_argument("--out", default="runs/pareto_shards")
    args = ap.parse_args()

    solutions, tasks = collect_solutions(args.runs)
    if args.tasks:
        tasks = [t.strip() for t in args.tasks.split(",") if t.strip()]
    if not solutions:
        raise SystemExit("no solution.json found in the given run directories")

    points, labels, rows = [], [], []
    for solution in solutions:
        scores = solution.get("best_scores") or {}
        row = [scores.get(task) for task in tasks]
        if any(v is None for v in row):
            print(f"[skip] {solution['_label']}: missing {[t for t, v in zip(tasks, row) if v is None]}")
            continue
        points.append([float(v) for v in row])
        labels.append(solution["_label"])
        rows.append(
            {
                "label": solution["_label"],
                "lambda": solution.get("lambda"),
                "best_reward": solution.get("best_reward"),
                "best_scores": {t: float(v) for t, v in zip(tasks, row)},
                "path_length": solution.get("path_length"),
            }
        )

    if len(points) < 1:
        raise SystemExit("no complete solution to compare")

    report = pareto_report(points, margin=float(args.margin))
    front = pareto_front_indices(points)
    payload = {
        "tasks": tasks,
        "solutions": rows,
        "points": points,
        "labels": labels,
        "pareto_indices": report.indices,
        "hypervolume": report.hypervolume,
        "reference_point": report.reference,
        "hv_margin": float(args.margin),
        "pareto_labels": [labels[i] for i in front],
    }
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "pareto.json"), "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)

    print(f"{len(points)} solution(s), {len(front)} non-dominated")
    for row in rows:
        print(f"  {row['label']:<24} reward={row['best_reward']:.4f} "
              + " ".join(f"{k}={v:.4f}" for k, v in row["best_scores"].items()))
    print(f"HV={report.hypervolume:.6f}  reference={[round(x, 4) for x in report.reference]}")

    if len(tasks) in (2, 3):
        try:
            fig = plot_pareto(
                points,
                tasks,
                os.path.join(args.out, "pareto.png"),
                hv=report.hypervolume,
                reference=report.reference,
                labels=labels,
            )
            print("figure:", fig)
        except Exception as exc:  # pragma: no cover - figure is optional
            print("figure skipped:", exc)


if __name__ == "__main__":
    main()
