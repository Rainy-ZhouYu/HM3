# HM3 v1.0 —— 层级模型合并（架构级搜索）

把多个同源微调模型合并成一个模型：先在参数级用 mergekit 合并出一个候选，再在架构级搜索一条
"推理路径"（每一层从哪个候选模型取）。支持多目标偏好：每个偏好向量解一个子问题，最终得到一组解。

代码分三层：

* `hm3/` —— 库（搜索环境、策略/PPO、奖励、对齐层、合并、评测封装、指标、报告）
* `tools/` —— 命令行工具与一键脚本（自检、跑搜索、出图、对比、诊断）
* `tests/` —— 单元测试

---

## 1. 环境

已验证的组合：

| 组件 | 版本 |
|---|---|
| Python | 3.10 |
| torch | 2.7.1+cu126 |
| transformers | 4.56.1 |
| mergekit | 随环境安装 |
| lm_eval | 0.4.9 |
| numpy / matplotlib | 随环境安装 |

需要的第三方包：`torch transformers mergekit lm_eval numpy matplotlib pyyaml huggingface_hub`。

可用 `pip install -r requirements.txt` 一键安装。

现成环境（请改成你自己的 Python 解释器，需装有 torch / transformers / mergekit / lm_eval）：

```bash
PY=python   # 例如 /path/to/your/conda/env/bin/python
```

离线跑时建议设 `HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1`（模型与数据集都走本地缓存）。
合并步骤即使传 HF repo id 也能离线跑：代码会先用 `local_files_only` 把它解析成本地快照路径。

---

## 2. 30 秒自检

```bash
export PY=python   # 改成你的解释器路径
for t in tests/*.py; do $PY $t; done
```

单元测试约 1 分钟，不需要 GPU。三档一键自检（单元测试 / tiny 端到端 / 真实模型最小跑）：

```bash
GPU=2 RUN_ROOT=runs/smoke bash tools/smoke.sh
STAGES=units,tiny GPU=2 bash tools/smoke.sh
```

| 档 | 内容 | 耗时 |
|---|---|---|
| `units` | 6 个测试文件（numpy + 一个 torch 测试） | 小于 1 分钟 |
| `tiny` | 随机小模型 + 合成打分，跑完整 PPO 循环 | 3 到 5 分钟 |
| `real` | 真实 Qwen 候选、1 个偏好向量、1 轮、跳过参数合并 | 5 到 8 分钟 |

成功标志：输出结尾是 `=== SMOKE OK ===`。

---

## 3. 跑一次搜索

```bash
CUDA_VISIBLE_DEVICES=2 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 $PY -u -m hm3.train \
  --candidates Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Coder-1.5B,Qwen/Qwen2.5-Math-1.5B \
  --base-model Qwen/Qwen2.5-1.5B \
  --tasks xnli_en,gsm8k_platinum_cot,mathqa \
  --task-to-model xnli_en=0,gsm8k_platinum_cot=2,mathqa=2 \
  --subproblems 1 --max-iters 35 --episodes-per-iter 1 \
  --min-path-len 28 --max-path-len 28 \
  --search-limit 0.005 --batch-size 1 \
  --alignment-mode always --fit-alignment --alignment-steps 10 \
  --merge-methods dare_ties --merge-combination-sizes 3 \
  --wolp-k 16 --reward-mode weighted_sum \
  --output-root runs --run-name my_run
```

看结果：

```bash
$PY tools/report_run.py --run-dir runs/my_run
cat runs/my_run/pref_000/solution.json
```

全部参数：`$PY -m hm3.train --help`

---

## 4. 常用 flag

| flag | 作用 |
|---|---|
| `--candidates` | 待合并的微调模型（逗号分隔，HF id 或本地路径都行） |
| `--base-model` | 残差基准模型（本身不进入候选池） |
| `--tasks` / `--task-to-model` | 目标与"任务到模型"的权重映射（必须显式给出） |
| `--min-path-len` / `--max-path-len` | 推理路径长度范围；等于层数时每个位置都会取一层 |
| `--ordered-actions` | 第 t 个位置只允许取某模型的第 t 层（结构化搜索，空间小得多） |
| `--alignment-mode` | `never / dim-mismatch / model-change / always`，拼接处插不插对齐层 |
| `--alignment-rank` | 对齐层是否加低秩修正（0 表示只做对角仿射） |
| `--reward-mode` | `weighted_sum`（默认，加权和减长度惩罚）/ `tchebycheff` / `legacy` |
| `--merge-methods` / `--density` | 参数级合并方法与稀疏度（DARE-Ties 等） |
| `--wolp-k` / `--wolp-score` | Wolpertinger 邻域大小与打分方式（默认 `mixed`） |
| `--train-mode prior_bc` | 额外用 K+1 条纯模型路径做行为克隆预热 |
| `--replay-ratio` / `--replay-bc-coef` | 把先验轨迹放进 replay buffer 参与更新（默认关闭） |
| `--eval-best` | 训练结束后用全量 benchmark 重测最优模型（很慢） |
| `--reuse-tasks` | 复用 lm-eval task 对象，省掉每次评估重读数据集 |

---

## 5. 多卡：每个偏好向量一个进程

```bash
PAIRS="0:0 1:1 2:2 3:3 4:4" MODE=online ITERS=35 PREFIX=matrix bash tools/run_matrix.sh
```

`PAIRS` 是 `<子问题下标>:<GPU>` 列表。跑完后把各进程的解汇总成 Pareto 前沿与 HV：

```bash
$PY tools/merge_pareto.py --runs runs/matrix_s0 runs/matrix_s1 runs/matrix_s2 runs/matrix_s3 runs/matrix_s4 \
  --tasks xnli_en,gsm8k_platinum_cot,mathqa --out runs/pareto
```

---

## 6. 输出目录

```text
runs/<run-name>/
  manifest.json          运行参数、候选池、偏好向量、每个子问题的合并权重与最优解
  preference_vectors.csv Dirichlet 采样的偏好向量
  alignment_fit.json     对齐层拟合前后的损失
  raw_evals/             每个被评估模型的 lm-eval 原始结果
  pref_000/
    upper_pool/          参数级合并产物 + merge_runs_*.json（含权重映射）
    path_evals/          每个候选路径的得分
    episodes.jsonl       每轮 episode（奖励、路径长度、来源）
    prior_dump.jsonl     K+1 条纯模型路径（用到先验或回放时）
    policy.pt            策略网络
    merged_model/        最优路径拼装出的模型 + path.json（含每层来源）
    solution.json        最优路径、奖励、逐任务分数、贪心结果
  report/                出图与 summary.json
```

---

## 7. 工具一览

| 工具 | 用途 |
|---|---|
| `tools/smoke.sh` | 一键自检（units / tiny / real 三档） |
| `tools/run_matrix.sh` | 多卡分片启动搜索 |
| `tools/report_run.py` | 单个 run 出图与汇总 |
| `tools/compare_runs.py` | 多个 run 的收敛曲线对比 |
| `tools/merge_pareto.py` | 跨分片汇总 Pareto 前沿与 HV |
| `tools/check_real_paths.py` | 验证合并、对齐、拼装、前向，并报告对齐前后的矩差异 |
| `tools/compare_modes.py` | tiny 环境下对比 online / prior_bc / replay 三种训练模式 |
| `tools/smoke_test_tiny.py` | tiny 端到端冒烟测试 |
| `tools/diag_eval.py` 与 `tools/diag_sequence.py` | 评测链路诊断（对齐、注意力后端、批大小、共享 scorer） |

理想点 z* 的测量入口：

```bash
$PY -m hm3.ideal_point --models Qwen/Qwen2.5-1.5B-Instruct,Qwen/Qwen2.5-Coder-1.5B \
  --tasks xnli_en,mathqa --limit 0.01 --out runs/ideal.json
```

---

## 8. 运行时注意事项

1. **拼装模型的评测**会自动使用 `attn=eager`、生成阶段 `use_cache=False`、`batch_size=1`。
   多 checkpoint 拼装的模型在开启 KV cache 时会出现缓存长度与因果掩码不一致，禁用缓存是绕开方式。
2. **对齐层的统计表必须覆盖整个候选池**（包含参数级合并模型），否则会取到越界 slot。
3. **`mbpp`** 是代码执行类任务，离线环境下需要额外开关（例如允许代码执行的环境变量）；
   **`xnli`** 是 15 种语言的 group，加载很慢，搜索期建议用单语言的 `xnli_en`。
4. **`gsm8k_platinum_cot` 是生成式任务**，是常见三个任务里最慢的一个；只做搜索时可以先用别的任务，
   最后再用 `--eval-best` 补全量评测。
5. **路径长度**：`--min-path-len` 小于 `--max-path-len` 时，拼出来的模型深度会随路径变化；
   两者都设成层数就是"逐层选来源"。
6. 每个候选路径的评测结果按路径签名缓存，同一次运行内不会重复评估。
7. 训练配方：`--train-mode` 支持 `online`（只用在线轨迹，默认）和 `prior_bc`（额外用 K+1 条纯模型路径做
   行为克隆预热）；`replay` 不是独立的 train-mode，而是通过 `--replay-ratio`（默认 0）把先验轨迹放进 replay
   buffer 参与 PPO 更新。奖励模式 `weighted_sum` 是加权和减长度惩罚，
   另有 `tchebycheff` 与 `legacy` 两种可选。
